function calculateBalanceI() {
	var tab = document.getElementById('scheduleI');
	var rowcount = tab.rows.length;
	var totalTotAmountAccumlated = 0,totalTotAmountAppliedPreviousYear=0,totalTotAmountInvested=0,totalTotAmountAppliedDuringYear=0,totalTotBalanceAmount=0,totalTotAmountDeemedUs11=0;
	var totAmountAccumlated = document.getElementsByName('itr7.itrScheduleI.totAmountAccumlated')[0];
	var totAmountAppliedPreviousYear = document.getElementsByName('itr7.itrScheduleI.totAmountAppliedPreviousYear')[0];
	var totAmountInvested = document.getElementsByName('itr7.itrScheduleI.totAmountInvested')[0];
	var totAmountAppliedDuringYear = document.getElementsByName('itr7.itrScheduleI.totAmountAppliedDuringYear')[0];
	var totBalanceAmount = document.getElementsByName('itr7.itrScheduleI.totBalanceAmount')[0];
	var totAmountDeemedUs11 = document.getElementsByName('itr7.itrScheduleI.totAmountDeemedUs11')[0];
	
	for(var i=0;i<rowcount - 4;i++) {
		var amountAccumlated = document.getElementsByName('itr7.itrScheduleI.scheduleI['+i+'].amountAccumlated')[0].value;
		var amountAppliedPreviousYear = document.getElementsByName('itr7.itrScheduleI.scheduleI['+i+'].amountAppliedPreviousYear')[0].value;
		var amountAppliedDuringYear = document.getElementsByName('itr7.itrScheduleI.scheduleI['+i+'].amountAppliedDuringYear')[0].value;
		var balanceAmount = document.getElementsByName('itr7.itrScheduleI.scheduleI['+i+'].balanceAmount')[0];
		var amountInvested = document.getElementsByName('itr7.itrScheduleI.scheduleI['+i+'].amountInvested')[0].value;
		var amountDeemedUs11 = document.getElementsByName('itr7.itrScheduleI.scheduleI['+i+'].amountDeemedUs11')[0].value;
		balanceAmount.value = zeroOrMore(parseInt(coalesce(amountAccumlated),10) -parseInt(coalesce(amountAppliedPreviousYear),10)  -parseInt(coalesce(amountAppliedDuringYear),10));
		totalTotAmountAccumlated = parseInt(coalesce(totalTotAmountAccumlated),10) + parseInt(coalesce(amountAccumlated),10);
		totalTotAmountAppliedPreviousYear = parseInt(coalesce(totalTotAmountAppliedPreviousYear),10) + parseInt(coalesce(amountAppliedPreviousYear),10);
		totalTotAmountInvested = parseInt(coalesce(totalTotAmountInvested),10) + parseInt(coalesce(amountInvested),10);
		totalTotAmountAppliedDuringYear = parseInt(coalesce(totalTotAmountAppliedDuringYear),10) + parseInt(coalesce(amountAppliedDuringYear),10);
		totalTotBalanceAmount= parseInt(coalesce(totalTotBalanceAmount),10) + parseInt(coalesce(balanceAmount.value),10);
		totalTotAmountDeemedUs11=parseInt(coalesce(totalTotAmountDeemedUs11),10) + parseInt(coalesce(amountDeemedUs11),10);
	}
	
	totAmountAccumlated.value = parseInt(totalTotAmountAccumlated);
	totAmountAppliedPreviousYear.value = parseInt(totalTotAmountAppliedPreviousYear);
	totAmountInvested.value = parseInt(totalTotAmountInvested);
	totAmountAppliedDuringYear.value = parseInt(totalTotAmountAppliedDuringYear);
	totBalanceAmount.value=parseInt(totalTotBalanceAmount);
	totAmountDeemedUs11.value=parseInt(totalTotAmountDeemedUs11);
}

function disableOS(){
	var osVal=document.getElementsByName('itr7.scheduleOS.incFromOtherSourcesFlag')[0].value;
	if(osVal=='Y'){
		var inputTags=document.getElementById('scheduleOS').getElementsByTagName('input');
		var tagLength=inputTags.length;
		for(var i=0;i<tagLength;i++){
			inputTags.item(i).disabled=false;
		}
	}else{
		var inputTags=document.getElementById('scheduleOS').getElementsByTagName('input');
		var tagLength=inputTags.length;
		for(var i=0;i<tagLength;i++){
			inputTags.item(i).disabled=true;
			inputTags.item(i).value="";
		}
	}
}


function schedueOsCalc(osmap){
	
	//var simap = initMapForSI(cgosIncome);
	
	var othersGross = document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGross')[0];
	othersGross.value = calculateOSGross(osmap);
	
	var totalOSGross = document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.totalOSGross')[0];
	totalOSGross.value = eval(
			parseInt(coalesceSetRet('itr7.scheduleOS.incOthThanOwnRaceHorse.dividendGross'),10)
			+ parseInt(coalesceSetRet('itr7.scheduleOS.incOthThanOwnRaceHorse.interestGross'),10)
			+ parseInt(coalesceSetRet('itr7.scheduleOS.incOthThanOwnRaceHorse.rentFromMachPlantBldgs'),10)
			+ parseInt(coalesceSetRet('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGross'),10)
		);
	
	var totalOSGrossChargblSplRate = document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.incChargblSplRateOS.totalOSGrossChargblSplRate')[0];
	totalOSGrossChargblSplRate.value = eval(
			parseInt(coalesceSetRet('itr7.scheduleOS.incOthThanOwnRaceHorse.incChargblSplRateOS.winningFrmLotteries'),10)
			+ parseInt(coalesceSetRet('itr7.scheduleOS.incOthThanOwnRaceHorse.incChargblSplRateOS.secXIIOth'),10)
		);
	
	var grossAmtChargblNormalRate = document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.grossAmtChargblNormalRate')[0];
	grossAmtChargblNormalRate.value = eval(
			parseInt(totalOSGross.value,10)
			- parseInt(totalOSGrossChargblSplRate.value,10)
		);
	
	var totDeductions = document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.deductions.totDeductions')[0];
	totDeductions.value = eval(
			parseInt(coalesceSetRet('itr7.scheduleOS.incOthThanOwnRaceHorse.deductions.expenses'),10)
			+ parseInt(coalesceSetRet('itr7.scheduleOS.incOthThanOwnRaceHorse.deductions.depreciation'),10)
		);	
	
	var balanceNoRaceHorse = document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.balanceNoRaceHorse')[0];
    
	balanceNoRaceHorse.value = eval(
			parseInt(grossAmtChargblNormalRate.value,10)
			- parseInt(totDeductions.value,10)
		);
                    
	var totOthSrcNoRaceHorse = document.getElementsByName('itr7.scheduleOS.totOthSrcNoRaceHorse')[0];
	var IncmOthrSrc = document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.balanceNoRaceHorse')[0];
     
	totOthSrcNoRaceHorse.value = eval(
			parseInt(totalOSGrossChargblSplRate.value,10)
			+ parseInt(zeroOrMore(parseInt(IncmOthrSrc.value,10)))
		);
	
	var balanceOwnRaceHorse = document.getElementsByName('itr7.scheduleOS.incFromOwnHorse.balanceOwnRaceHorse')[0];
	balanceOwnRaceHorse.value = eval(
			parseInt(coalesceSetRet('itr7.scheduleOS.incFromOwnHorse.receipts'),10)
			- parseInt(coalesceSetRet('itr7.scheduleOS.incFromOwnHorse.deductSec57'),10)
		);
	
	var incChargeable = document.getElementsByName('itr7.scheduleOS.incChargeableFrmOthSrc')[0];
	incChargeable.value = eval(
			parseInt(totOthSrcNoRaceHorse.value,10)
			+ parseInt(zeroOrMore(parseInt(balanceOwnRaceHorse.value ,10)))
		);
	coalesceSetRet('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls[0].sourceAmount');
	if(!osmap) {
		changeCYLA();
		calculateTiTti();
	}
}



function calculateOSGross(osmap){
	var total = parseInt('0' ,10);
	var tabl = document.getElementById('schduleOsf');
	var allInputTags = tabl.getElementsByTagName('input');
	for(var i = 0; i < allInputTags.length; i++) {
			if (allInputTags[i].name.match("sourceAmount$")) {
					total = eval(parseInt(total ,10) + parseInt(isNVL(allInputTags[i].value) ,10));
			}			
		}
	var allSelects = tabl.getElementsByTagName('SELECT'); 
	var sum = 0;
	for(var i = 0; i < allSelects.length; i++) {	
			var name = allSelects[i].name;
			var index = name.substring(name.indexOf('[')+1, name.indexOf(']'));
			if(allSelects[i].value=='Others'){
				document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls['+ index +'].otherSourceDesc')[0].style.display='';
			}
			else{
				if(osmap) {
					if(allSelects[i].value!='5BB' && allSelects[i].value!='') {
						osmap[allSelects[i].value] = document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls['+ i +'].sourceAmount')[0];
					}
				}
							
				document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls['+ index +'].otherSourceDesc')[0].style.display='none';
				document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls['+ index +'].otherSourceDesc')[0].value='';
				if(allSelects[i].value=='5BB'){
					var winningFrmLotteries = document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.incChargblSplRateOS.winningFrmLotteries')[0];
					winningFrmLotteries.value = document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls['+ index +'].sourceAmount')[0].value;
				}
				else{
					sum = parseInt(sum) + parseInt(coalesce(document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls['+ index +'].sourceAmount')[0].value));
				}
			}
	}	
	var secXIIOth = document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.incChargblSplRateOS.secXIIOth')[0];
	secXIIOth.value = sum;

	return total;
}

function scheduleCGCalc(){
	
	{
		var temp='itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.deductSec48';
		document.getElementsByName(temp+'.totalDedn')[0].value=eval(parseInt(document.getElementsByName(temp+'.aquisitCost')[0].value==""?0:document.getElementsByName(temp+'.aquisitCost')[0].value) + parseInt(document.getElementsByName(temp+'.improveCost')[0].value==""?0:document.getElementsByName(temp+'.improveCost')[0].value) + parseInt(document.getElementsByName(temp+'.expOnTrans')[0].value==""?0:document.getElementsByName(temp+'.expOnTrans')[0].value));
	}
	
	{
		document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.balanceCG')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.fullConsideration')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.fullConsideration')[0].value) - parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.deductSec48.totalDedn')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.deductSec48.totalDedn')[0].value));
	}
	
	{
		document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.balCG')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.balanceCG')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.balanceCG')[0].value) + parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.lossSec94Of7Or94Of8')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.lossSec94Of7Or94Of8')[0].value));
	}
	
	{
		document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.deductSec48.totalDedn')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.deductSec48.aquisitCost')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.deductSec48.aquisitCost')[0].value) +  parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.deductSec48.improveCost')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.deductSec48.improveCost')[0].value) + parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.deductSec48.expOnTrans')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.deductSec48.expOnTrans')[0].value));
	}
	
	{
		document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.balanceCG')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.fullConsideration')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.fullConsideration')[0].value) - parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.deductSec48.totalDedn')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.deductSec48.totalDedn')[0].value));
	}
	
	{
		document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.balSCG')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.lossSec94Of7Or94Of8')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.lossSec94Of7Or94Of8')[0].value) + parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.balanceCG')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.balanceCG')[0].value));
	}
        
        var val1=eval(parseInt(coalesce(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0].value)));
        var val2=eval(parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.balCG')[0].value) + 
                    parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.balSCG')[0].value) + 
                    parseInt(coalesce(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.deemedSTCGDeprAsset')[0].value)));
        if(val2>=0 && val1>val2){
            if(val1>0){
            addErrorXHTML(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0], 'Field A4 cannot be greater than (A1e+A2e+A3)',true);
            document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0].value=0;
            }
        }
        if(val2<0){
            document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0].readOnly=true;
            document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0].value=0;
        }else{
            document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0].readOnly=false;
        }
	
	{
		document.getElementsByName('itr7.scheduleCG.shortTermCapGain.totalSTCG')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.balCG')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.balCG')[0].value) + parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.balSCG')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.balSCG')[0].value) + parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.deemedSTCGDeprAsset')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.deemedSTCGDeprAsset')[0].value) - parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0].value));
	}
	
	
	{
		document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.deductSec48.totalDedn')[0].value=eval( parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.deductSec48.aquisitCostIndexed')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.deductSec48.aquisitCostIndexed')[0].value) + parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.deductSec48.improveCostIndexed')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.deductSec48.improveCostIndexed')[0].value)+ parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.deductSec48.expOnTrans')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.deductSec48.expOnTrans')[0].value));
	}
	
	{
		document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.balanceCG')[0].value=eval( parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.fullConsideration')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.fullConsideration')[0].value) - parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.deductSec48.totalDedn')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.deductSec48.totalDedn')[0].value));
	}
        
        var val1d=parseInt(coalesce(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.exemptionUs111A')[0].value));
        var val1c=parseInt(coalesce(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.balanceCG')[0].value));
        
        
        if(val1d!=0 && val1c>=0 && val1d>val1c){
            addErrorXHTML(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.exemptionUs111A')[0], 'B1d should not be greater than B1c',true);
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.exemptionUs111A')[0].value=0;
        }
        
        if(val1c<0){
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.exemptionUs111A')[0].readOnly=true;
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.exemptionUs111A')[0].value=0; 
        }else{
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.exemptionUs111A')[0].readOnly=false;
        }
	
	{
		document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.balLTCGNo112')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.balanceCG')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.balanceCG')[0].value) - parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.exemptionUs111A')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.exemptionUs111A')[0].value));
	}
	
	{
		document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.deductSec48.totalDedn')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.deductSec48.aquisitCostNoIndex')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.deductSec48.aquisitCostNoIndex')[0].value) + parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.deductSec48.improveCostNoIndex')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.deductSec48.improveCostNoIndex')[0].value) + parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.deductSec48.expOnTrans')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.deductSec48.expOnTrans')[0].value));
	}
	
	{
		document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.balanceCG')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.fullConsideration')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.fullConsideration')[0].value) - parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.deductSec48.totalDedn')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.deductSec48.totalDedn')[0].value));
	}
        
        var val2d=parseInt(coalesce(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.exemptionUs111A')[0].value));
        var val2c=parseInt(coalesce(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.balanceCG')[0].value));
        
        
        if(val2d!=0 && val2c>=0 && val2d>val2c){
            addErrorXHTML(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.exemptionUs111A')[0], 'B2d should not be greater than B2c',true);
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.exemptionUs111A')[0].value=0;
        }
        
        if(val2c<0){
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.exemptionUs111A')[0].readOnly=true;
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.exemptionUs111A')[0].value=0; 
        }else{
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.exemptionUs111A')[0].readOnly=false;
        }
	
	{
		document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.balLTCG112')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.balanceCG')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.balanceCG')[0].value) - parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.exemptionUs111A')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.exemptionUs111A')[0].value));
	}
	
	{
		document.getElementsByName('itr7.scheduleCG.longTermCapGain.totalLTCG')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.balLTCG112')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.balLTCG112')[0].value) + parseInt(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.balLTCGNo112')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.balLTCGNo112')[0].value));
	}
	
	{
		document.getElementsByName('itr7.scheduleCG.incChargeableHeadCapGain')[0].value=zeroOrMore(eval(parseInt(zeroOrMore(document.getElementsByName('itr7.scheduleCG.longTermCapGain.totalLTCG')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.longTermCapGain.totalLTCG')[0].value)) + parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.totalSTCG')[0].value==""?0:document.getElementsByName('itr7.scheduleCG.shortTermCapGain.totalSTCG')[0].value)));
	}
	
	
	
	//scheduleSiIncome('scheduleSI');
	changeCYLA();	
	calculateTiTti();
}

function scheduleCGExemptDisable() {
	var val2=eval(parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.balCG')[0].value) + 
                    parseInt(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.balSCG')[0].value) + 
                    parseInt(coalesce(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.deemedSTCGDeprAsset')[0].value)));
 
        if(val2<0){
            document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0].readOnly=true;
            document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0].value=0;
        }else{
            document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0].readOnly=false;
        }
		
	 var val1c=parseInt(coalesce(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.balanceCG')[0].value));
        
       if(val1c<0){
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.exemptionUs111A')[0].readOnly=true;
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.exemptionUs111A')[0].value=0; 
        }else{
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.exemptionUs111A')[0].readOnly=false;
        }
		
		var val2c=parseInt(coalesce(document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.balanceCG')[0].value));
        
		if(val2c<0){
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.exemptionUs111A')[0].readOnly=true;
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.exemptionUs111A')[0].value=0; 
        }else{
            document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.exemptionUs111A')[0].readOnly=false;
        }
}

function scheduleETCalc(){
	document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.totalAfterVoluntaryContribution')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.openingBalance')[0].value==""?0:document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.openingBalance')[0].value) + parseInt(document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.voluntaryContributionDuringYr')[0].value==""?0:document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.voluntaryContributionDuringYr')[0].value));
	
	document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.total')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.amtDistToPoliticalParties')[0].value==""?0:document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.amtDistToPoliticalParties')[0].value) + parseInt(document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.amtSpentOnManagingAffairs')[0].value==""?0:document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.amtSpentOnManagingAffairs')[0].value));
	
	document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.closingBalance')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.totalAfterVoluntaryContribution')[0].value==""?0:document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.totalAfterVoluntaryContribution')[0].value) - parseInt(document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.total')[0].value==""?0:document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.total')[0].value));

	if(document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.closingBalance')[0].value < 0){
		
		document.getElementsByName('itr7.scheduleET.voluntaryContributionDtls.closingBalance')[0].value=parseInt('0',10);
	}

}

function delScheduleHP(){

	if($('#scheduleHPAddRow')[0].parentNode.children.length>44){
		for(var i=0;i<19;i++){
			$('#scheduleHPAddRow')[0].parentNode.deleteRow($('#scheduleHPAddRow')[0].parentNode.children.length-6);
		}
		if($('#scheduleHPAddRow')[0].parentNode.children.length==44){
			$('#delHPButtonId').prop('disabled', true);
		}
	}else if($('#scheduleHPAddRow')[0].parentNode.children.length==44){
		$('#delHPButtonId').prop('disabled', true);
	}
	
	
	($('#scheduleHPLast')[0].children)[0].innerHTML =  parseInt(($('#scheduleHPLast')[0].children)[0].innerHTML) - 1;
	
	
	var totRow=document.getElementById('scheduleHPLast').cells[0].textContent;
	
	var newVal = eval( parseInt(totRow));
	var newText='Total (';
	for(var k=1;k<newVal;k++){
		newText=newText+k+'i +';
	}
	newText=newText+newVal+'a +'+newVal+'b )';
	document.getElementById('scheduleHPLast').cells[0].innerHTML=newVal;
	document.getElementById('scheduleHPLast').nextElementSibling.cells[3].innerHTML=newVal+'a';
	document.getElementById('scheduleHPLast').nextElementSibling.nextElementSibling.cells[2].innerHTML=newVal+'b';
	document.getElementById('scheduleHPLast').nextElementSibling.nextElementSibling.nextElementSibling.cells[2].innerHTML=newVal+'c';
	document.getElementById('scheduleHPLast').nextElementSibling.nextElementSibling.nextElementSibling.cells[1].innerHTML=newText;
	
	scheduleHPCalc();
}

function addScheduleHP(called){
	
	var mainTable = document.getElementById('scheduleHPMain').rows;
	var tobeInsertBefore = document.getElementById('scheduleHPAddRow');
	var flag = false;
	var totRow = document.getElementById('scheduleHPLast').cells[0].textContent;

	var iterate = eval(parseInt(totRow) - 1);
	for ( var i = 0; i < mainTable.length; i++) {
		var cloneNode = mainTable[i].cloneNode(true);
		if (mainTable[i].id == 'scheduleHP1st') {
			flag = true;
			cloneNode.cells[0].innerHTML = totRow;
		}
		if (mainTable[i].id == 'coOwnerTr') {
			cloneNode.getElementsByTagName('table')[0].setAttribute('id',
					'scheduleHP' + totRow);
			cloneNode.getElementsByTagName('img')[0].setAttribute('onclick',
					'addRowToTableSchHp(' + '\'scheduleHP' + totRow
							+ '\',2,1,this);');
			cloneNode.getElementsByTagName('img')[1].setAttribute('onclick',
					'deleteRowTable(' + '\'scheduleHP' + totRow + '\',1,1)');

		}

		if (mainTable[i].id == 'coTenantTr') {
			cloneNode.getElementsByTagName('table')[0].setAttribute('id',
					'scheduleHPTenant' + totRow);
			cloneNode.getElementsByTagName('img')[0].setAttribute('onclick',
					'addRowToTableSchHpTenants(' + '\'scheduleHPTenant'
							+ totRow + '\',2,1,this);');
			cloneNode.getElementsByTagName('img')[1].setAttribute('onclick',
					'deleteRowTable(' + '\'scheduleHPTenant' + totRow
							+ '\',1,1)');
		}

		if (flag) {

			var cellsTot = cloneNode.cells;
			for ( var j = 0; j < cellsTot.length; j++) {
				cloneNode.cells[j].innerHTML = cloneNode.cells[j].innerHTML
						.replace('1a', totRow + 'a')
						.replace('1b', totRow + 'b')
						.replace('1c', totRow + 'c')
						.replace('1d', totRow + 'd')
						.replace('1e', totRow + 'e')
						.replace('1f', totRow + 'f')
						.replace('1g', totRow + 'g')
						.replace('1h', totRow + 'h')
						.replace('1i', totRow + 'i')
						.replace('1j', totRow + 'j').replace('property 1',
								'property ' + totRow).replace('property 1',
								'property ' + totRow);
			}

			var inputTags = cloneNode.getElementsByTagName('input');
			for ( var a = 0; a < inputTags.length; a++) {
				inputTags[a].name = inputTags[a].name.replace('[0]', '['
						+ iterate + ']');
				if (inputTags[a].name.indexOf('coOwnersSNo') == '-1') {
					inputTags[a].value = '';
				}

				if (inputTags[a].name.indexOf('coTenantsSNo') == '-1') {
					inputTags[a].value = '';
				}
				inputTags[a].id = inputTags[a].name.replace(/([\.\[\]])/g, '_')
						.replace(/(__)/g, '_');

				var blurAttr = inputTags[a].getAttribute('onblur');
				if (blurAttr != null) {
					blurAttr = blurAttr + ";";
				} else {
					blurAttr = "";
				}
				inputTags[a].setAttribute('onblur', blurAttr
						+ 'j.blur(this,this.name,this.value);');
			}

			var selectTags = cloneNode.getElementsByTagName('select');
			for ( var a = 0; a < selectTags.length; a++) {
				selectTags[a].name = selectTags[a].name.replace('[0]', '['
						+ iterate + ']');
				selectTags[a].value = '';
				if (selectTags[a].name.indexOf('stateCode') != '-1') {
					selectTags[a].onchange = function() {
						populatePincode('scheduleHP.propertyDetails[' + iterate
								+ '].addressDetail.stateCode',
								'scheduleHP.propertyDetails[' + iterate
										+ '].addressDetail.pinCode');
					};
				}
				selectTags[a].id = selectTags[a].name.replace(/([\.\[\]])/g,
						'_').replace(/(__)/g, '_');

				var blurAttr = selectTags[a].getAttribute('onblur');
				if (blurAttr != null) {
					blurAttr = blurAttr + ";";
				} else {
					blurAttr = "";
				}
				selectTags[a].setAttribute('onblur', blurAttr
						+ 'j.blur(this,this.name,this.value);');
			}

			var textareaTags = cloneNode.getElementsByTagName('textarea');
			for ( var a = 0; a < textareaTags.length; a++) {
				textareaTags[a].name = textareaTags[a].name.replace('[0]', '['
						+ iterate + ']');
				textareaTags[a].value = '';
				textareaTags[a].id = textareaTags[a].name.replace(
						/([\.\[\]])/g, '_').replace(/(__)/g, '_');

				var blurAttr = textareaTags[a].getAttribute('onblur');
				if (blurAttr != null) {
					blurAttr = blurAttr + ";";
				} else {
					blurAttr = "";
				}
				textareaTags[a].setAttribute('onblur', blurAttr
						+ 'j.blur(this,this.name,this.value);');
			}

			document.getElementById('scheduleHPMain')
					.getElementsByTagName('tr')[0].parentNode.insertBefore(
					cloneNode, tobeInsertBefore);
		}
		if (mainTable[i].id == 'scheduleHPEnd') {
			flag = false;
			break;
		}
	}
	var newVal = eval(parseInt(totRow) + 1);
	var newText = 'Total (';
	for ( var k = 1; k < newVal; k++) {
		newText = newText + k + 'j +';
	}
	newText = newText + newVal + 'a +' + newVal + 'b )';
	document.getElementById('scheduleHPLast').cells[0].innerHTML = newVal;
	document.getElementById('scheduleHPLast').nextElementSibling.cells[3].innerHTML = newVal
			+ 'a';
	document.getElementById('scheduleHPLast').nextElementSibling.nextElementSibling.cells[2].innerHTML = newVal
			+ 'b';
	document.getElementById('scheduleHPLast').nextElementSibling.nextElementSibling.nextElementSibling.cells[2].innerHTML = newVal
			+ 'c';
	document.getElementById('scheduleHPLast').nextElementSibling.nextElementSibling.nextElementSibling.cells[1].innerHTML = newText;

	if ($('#scheduleHPAddRow')[0].parentNode.children.length == 44) {
		$('#delHPButtonId').prop('disabled', true);
	} else if ($('#scheduleHPAddRow')[0].parentNode.children.length > 44) {
		$('#delHPButtonId').prop('disabled', false);
	}

	$('#scheduleHPTenant' + eval(parseInt(totRow))).find('[type=\"checkbox\"]')
			.attr('checked', 'checked');
	deleteRowTable('scheduleHPTenant' + eval(parseInt(totRow)), 1, 1);

	document.getElementsByName('scheduleHP.propertyDetails['
			+ (parseInt(totRow) - 1) + '].hpSno')[0].value = totRow;
	var table = document.getElementById('scheduleHPMain');
	modifyRow(table);
	var onchange1 = document.getElementsByName('scheduleHP.propertyDetails['
			+ (parseInt(totRow) - 1) + '].propCoOwnedFlg')[0]
			.getAttribute('onchange');
	var onchange2 = document.getElementsByName('scheduleHP.propertyDetails['
			+ (parseInt(totRow) - 1) + '].ifLetOut')[0]
			.getAttribute('onchange');
	onchange1 = onchange1.substring(0, onchange1.indexOf('('));
	onchange2 = onchange2.substring(0, onchange2.indexOf('('));
	window[onchange1]();
	window[onchange2]();
	checkMaxLengthLimit();
		
}


//to add rows to table sch HP tenants
function addRowToTableSchHpTenants(tableId, noOfRow, last, elem) {

	addRowToTable(tableId, noOfRow, last);
	setSerialNumberTenants(elem, 2);
}

//set serial number tenants
function setSerialNumberTenants(element, header) {
	try {

		var tableId = element.getAttribute('onclick').substring(27,
				element.getAttribute('onclick').lastIndexOf('\''));

		var index = tableId.substring(16);

		index = eval(index - 1);

		var table = document.getElementById(tableId);
		var noOfRows = table.rows.length;

		for ( var i = 0; i < eval(parseInt(noOfRows, 10) - header); i++) {

			document.getElementsByName('scheduleHP.propertyDetails[' + index
					+ '].coTenants[' + i + '].coTenantsSNo')[0].value = i + 1;

		}
	} catch (e) {
		alert('Exception in setSerialNumberTenants method :: ' + e.stack);
	}

}
function scheduleHPCalc(){
	var totHp=eval(parseInt(document.getElementById('scheduleHPLast').cells[0].textContent)-1);
	var total=0;
    var thirtyPercentOfBalanceTemp = 0;
	var thirtyPercentOfBalance = 0; 
	
	for(var i=0;i<totHp;i++){
		
		thirtyPercentOfBalance = document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.thirtyPercentOfBalance')[0]; 
		document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.totalUnrealizedAndTax')[0].value=
		eval(parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.rentNotRealized')[0].value==""?0:coalesceSetRet('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.rentNotRealized')) + parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.localTaxes')[0].value==""?0:coalesceSetRet('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.localTaxes')));
		
		
		document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.balanceALV')[0].value=
		eval(parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.annualLetableValue')[0].value==""?0:document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.annualLetableValue')[0].value) - parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.totalUnrealizedAndTax')[0].value==""?0:coalesceSetRet('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.totalUnrealizedAndTax')));
		
		
      	thirtyPercentOfBalanceTemp = zeroOrMore(coalesce(Math.round(eval(parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.balanceALV')[0].value==""?0:document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.balanceALV')[0].value) * 0.3 ))));
      	if(coalesce(thirtyPercentOfBalance.value) > parseInt(thirtyPercentOfBalanceTemp ,10) ){
			addErrorXHTML(thirtyPercentOfBalance, 'Amount can not be more than 30% of Annual value i.e, '+thirtyPercentOfBalanceTemp+'.',true);
			j.setFieldError(thirtyPercentOfBalance,'Amount can not be more than 30% of Annual value i.e, '+thirtyPercentOfBalanceTemp+'.');
			
		}
		
		document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.totalDeduct')[0].value=
		eval(parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.thirtyPercentOfBalance')[0].value==""?0:document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.thirtyPercentOfBalance')[0].value) + parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.intOnBorwCap')[0].value==""?0:coalesceSetRet('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.intOnBorwCap')));
		
		document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.incomeOfHP')[0].value=
		eval(parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.balanceALV')[0].value==""?0:coalesceSetRet('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.balanceALV')) - parseInt(coalesceSetRet('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.totalDeduct')==""?0:coalesceSetRet('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.totalDeduct')));
		
		total=eval(parseInt(total) + parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.incomeOfHP')[0].value));
              
		
	}
	
	document.getElementsByName('itr7.scheduleHP.totalIncomeChargeableUnHP')[0].value = eval(parseInt(coalesceSetRet('itr7.scheduleHP.rentOfEarlierYrSec25AandAA')==""?0:document.getElementsByName('itr7.scheduleHP.rentOfEarlierYrSec25AandAA')[0].value) + parseInt(document.getElementsByName('itr7.scheduleHP.rentArearsSec25BAfter30PcDeduct')[0].value==""?0:coalesceSetRet('itr7.scheduleHP.rentArearsSec25BAfter30PcDeduct')) + parseInt(total));
	
	changeCYLA();
	calculateTiTti();
}


//To check co-owned
function isCoOwned() {
	var totHp = eval(parseInt(document.getElementById('scheduleHPLast').cells[0].textContent) - 1);

	for ( var i = 0; i < totHp; i++) {
		var tempName = 'itr7.scheduleHP.propertyDetails[' + i + '].propCoOwnedFlg';
		var val = document.getElementsByName(tempName)[0].value;
		var assessePercentShareProp = document
				.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
						+ '].asseseeShareProperty')[0];
		if (val == 'YES') {
			$('#scheduleHP' + eval(parseInt(i) + 1)).find(':input').prop(
					'disabled', false);
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].coOwners[0].coOwnersSNo')[0].value = 1;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].asseseeShareProperty')[0].disabled = false;
			if (assessePercentShareProp.value == 100
					|| assessePercentShareProp.value == 0.0) {
				assessePercentShareProp.value = '0';
			}
		} else {
			$('#scheduleHP' + eval(parseInt(i) + 1))
					.find('[type=\"checkbox\"]').attr('checked', 'checked');
			deleteRowTable('scheduleHP' + eval(parseInt(i) + 1), 1, 1);
			$('#scheduleHP' + eval(parseInt(i) + 1)).find(':input').prop(
					'disabled', true);
			assessePercentShareProp.disabled = true;
			if (val == 'NO') {
				assessePercentShareProp.value = '100';
			} else {
				assessePercentShareProp.value = '0.0';
			}
		}
	}
}


function enableField(src,val,targets){ 
	var srcField = document.getElementsByName(src)[0];
	if(contains(val,srcField.value)){
		for(var i=2;i<arguments.length; i++){	
			var targetField = document.getElementsByName(arguments[i])[0];		
				targetField.disabled= false;
				targetField.readOnly=false;
		}
	}else{
		for(var i=2;i<arguments.length; i++){
			var targetField = document.getElementsByName(arguments[i])[0];		
			if(targetField.type=='select-one'){
				targetField.selectedIndex = 0;
			}else{
				targetField.value='';
			}
			targetField.disabled= true;
			targetField.readOnly=true;
		}	
	}
	
}

function contains(arr, val){
	if(arr.constructor.name=="Array"){
		for(var i=0;i<arr.length; i++){
			if(arr[i]==val){
				return true;
			}
		}
		return false;
	}else{
		return (arr==val);
	}
}

function adjustForm(){
	
	enableField('itr7.partAGEN1.filingStatus.asseseeRepFlg','Y',
			'itr7.partAGEN1.filingStatus.assesseeRep.repName',
			'itr7.partAGEN1.filingStatus.assesseeRep.repAddress',
			'itr7.partAGEN1.filingStatus.assesseeRep.repPAN'
			);

                            
/*	enableField('itr7.partAGEN1.filingStatus.residentialStatus','RES',
		'itr7.partAGEN1.filingStatus.claimUs9090A91Flag'
		);*/	
	enableField('itr7.partAGEN1.filingStatus.residentialStatus','NRI',
		'itr7.partAGEN1.filingStatus.nripe'
		);	
	
	enableField('itr7.partAGEN1.filingStatus.residentialStatus','RES',
			'itr7.partBTTI.assetOutIndiaFlag'
			);
	enableField('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.charitablePurposeOfGeneralPublic','Y',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.activityNature215',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.activityRendering215'
		);

	/*var decider = 'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.activityRendering215';
	if(document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.activityNature215')[0].value=='Y'){
		decider = 'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.activityNature215';
	}*/
	/*enableField(decider ,'Y',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceipts'
		);
		*/
	if(document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs10.exemptionUs10Flag')[0].value=='Y'){	
		$('#otherDetailsUs10II').find(':input').prop('disabled', false);
		$('#otherDetailsUs10II').find('.addbtn').prop('hidden', false);
	}else{
		$('#otherDetailsUs10II').find(':input').prop('disabled', true);
		$('#otherDetailsUs10II').find('.addbtn').prop('hidden', true);	
                $('#otherDetailsUs10II').find(':input').val('');
	}
		
	enableField('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs12A12AA.regUs12A12AA','Y',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs12A12AA.registrationNo',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs12A12AA.commissionerGrantedRegistration',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs12A12AA.dateOfRegistration',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs12A12AA.activityType'
		);	

	enableField('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs35.relevantSec35','Y',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs35.registrationNo',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs35.dateOfApproval',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs35.approvingAuthority',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs35.researchType',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs35.businessActivity'
		);		

	enableField('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs80G.approvalUs80G','Y',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs80G.approvalNo',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs80G.dateOfApproval'
		);		
		
	enableField('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs13A.politicalSection13A','Y',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs13A.registeredFlag',
		'itr7.scheduleLA.booksOfAccMaintained',
		'itr7.scheduleLA.voluntaryContribution',
		'itr7.scheduleLA.accountsAudited',
		'itr7.scheduleLA.reportUs29'
		);
	
	enableField('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs13A.registeredFlag','Y',			
			'itr7.partAGEN2.otherDetailsFor7.otherDetailsUs13A.registrationNoUs29A' 
			);
		
	enableField('itr7.partAGEN2.otherDetailsFor7.otherDetailsET.electoralTrustFlag','Y',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsET.approvalNo',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsET.dateOfApproval',
		'itr7.scheduleET.booksOfAccMaintained',
		'itr7.scheduleET.voluntaryContribution',
		'itr7.scheduleET.recordsMaintainedWithPAN',
		'itr7.scheduleET.accountsAudited',
		'itr7.scheduleET.reportAsPerRule17CA',
		'itr7.scheduleET.voluntaryContributionDtls.openingBalance',
		'itr7.scheduleET.voluntaryContributionDtls.voluntaryContributionDuringYr',
		'itr7.scheduleET.voluntaryContributionDtls.amtDistToPoliticalParties',
		'itr7.scheduleET.voluntaryContributionDtls.amtSpentOnManagingAffairs'
		);
	enableField('itr7.scheduleET.accountsAudited','Y',
			'itr7.scheduleET.auditReportDate'
			);	
	
	enableField('itr7.partAGEN2.otherDetailsFor7.otherDetailsFC.regUnForeignContribution','Y',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsFC.registrationNo',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsFC.dateOfRegistration',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsFC.amtReceivedFromOutSideIndia',
		'itr7.partAGEN2.otherDetailsFor7.otherDetailsFC.purposeOfReceivedAmt'
		);
		
	enableField('itr7.scheduleLA.accountsAudited','Y',			
			'itr7.scheduleLA.auditReportDate' 
			);
	enableField('itr7.scheduleLA.reportUs29','Y',			
			'itr7.scheduleLA.submissionDate' 
			);
		
	removeAuditAllDetails($('[name="itr7.partAGEN2.liableSec44ABflg"]')[0]);
        
         enableField('scheduleTR1.taxPaidOutsideIndFlg','YES',
				'scheduleTR1.amtTaxRefunded',
				'scheduleTR1.assmtYrTaxRelief'
				);
	
	//To enable the text box after selecting the section code "Others" in Audit details
	addOtherSectionDetails();
	adjustOS();
	}

function addOtherSectionDetails() {
	var tab = document.getElementsByClassName('auditDetailsRow');
	for(var j=0;j<tab.length;j++) {
	var allInputTags = tab[j].getElementsByTagName('select');							
			
				if(allInputTags[0].value == 'Others') {
				
					document.getElementsByName('itr7.partAGEN2.auditDetails['+j+'].otherSectionDesc')[0].style.display="";
					document.getElementsByName('itr7.partAGEN2.auditDetails['+j+'].otherSectionDesc')[0].parentNode.parentNode.parentNode.parentNode.rows[0].cells[1].children[0].style.display='';
					document.getElementsByName('itr7.partAGEN2.auditDetails['+j+'].otherSectionDesc')[0].parentNode.parentNode.parentNode.parentNode.rows[0].cells[1].children[1].style.display='';

				} else {
					document.getElementsByName('itr7.partAGEN2.auditDetails['+j+'].otherSectionDesc')[0].value="";
					document.getElementsByName('itr7.partAGEN2.auditDetails['+j+'].otherSectionDesc')[0].style.display="none";
					document.getElementsByName('itr7.partAGEN2.auditDetails['+j+'].otherSectionDesc')[0].parentNode.parentNode.parentNode.parentNode.rows[0].cells[1].children[0].style.display='none';
					document.getElementsByName('itr7.partAGEN2.auditDetails['+j+'].otherSectionDesc')[0].parentNode.parentNode.parentNode.parentNode.rows[0].cells[1].children[1].style.display='none';
			}
		}
}


function revisedSet(section,type){
    
     var fileSec=section.value;
     var fileType=document.getElementsByName(type)[0];
     
	if(fileSec=='17' && fileType.value!='R'){
            
		document.getElementsByName(type)[0].value='R';
        }
        else{
            document.getElementsByName(type)[0].value='O';
        }
                    
}

function sectionSet(section,type)
{
    var fileSec = document.getElementsByName(section)[0];
    var fileType=type.value;
    
        if(fileType=='R' && fileSec.value!=17){
            fileSec.value='17';
        }
        else{
            fileSec.value='';
        }
}

function onStateChng(state,pincode){

	var foreign = document.getElementsByName(state)[0];
	
	var pinCode = document.getElementsByName(pincode)[0];
	
	if(foreign.value != '99' && foreign.value != '-1'){				
		pinCode.value='';
	}else if(foreign.value == '99'){
		pinCode.value='999999';
	}
}

	//setInterval(function(){addError('','It is a good practice to save your work frequently. Please Click "Save Draft" to save your work, else the data you might have filled, will be lost if session is timed out.')},300000);


	function getAmt(name){
                var val = $('[name="'+name+'"]')[0].value;
		return parseInt(coalesce(val));
	}
	
	function zeroOrMore(val){
		val = coalesce(val);
		if(val < 0){
			return 0;
		}
		return val;
	}
	
function calculateTiTti(called){
	
		scheduleVCCalc();
		
		var varDate = document.getElementsByName('itr7.verification.date')[0];
		if(varDate.value=='' || varDate.value==undefined || varDate.value== null){
			var dt = new Date();
			varDate.value= ("00" + dt.getDate()).slice(-2) +  '/' + ("00" + (dt.getMonth()+1)).slice(-2)+ '/' + dt.getFullYear()  ;
		} 
		
		//TI
		$('[name="itr7.partBTI.incomeFromHP"]')[0].value = zeroOrMore(getAmt("itr7.scheduleHP.totalIncomeChargeableUnHP"));
		$('[name="itr7.partBTI.profBusGain.profGainNoSpecBus"]')[0].value = getAmt("itr7.corpScheduleBP.chargeableUs11.incAsAccOfBusUndertaking");
		//Short Term
		$('[name="itr7.partBTI.capGain.shortTerm.totalShortTerm"]')[0].value = getAmt("itr7.scheduleCG.shortTermCapGain.totalSTCG");
		//String Term
		$('[name="itr7.partBTI.capGain.longTerm.totalLongTerm"]')[0].value = zeroOrMore(getAmt('itr7.scheduleCG.longTermCapGain.totalLTCG'));		
		//3c,4,5,6...
		$('[name="itr7.partBTI.capGain.totalCapGains"]')[0].value = zeroOrMore(getAmt('itr7.partBTI.capGain.shortTerm.totalShortTerm') + getAmt('itr7.partBTI.capGain.longTerm.totalLongTerm'));		
		$('[name="itr7.partBTI.incFromOS.totIncFromOS"]')[0].value = getAmt('itr7.scheduleOS.incChargeableFrmOthSrc');
		$('[name="itr7.partBTI.voluntaryContributions.totIncFromVC"]')[0].value = getAmt('itr7.scheduleVC.totalContribution');
		$('[name="itr7.partBTI.grossIncome"]')[0].value = getAmt('itr7.partBTI.incomeFromHP')+getAmt('itr7.partBTI.profBusGain.profGainNoSpecBus')+getAmt('itr7.partBTI.capGain.totalCapGains')+getAmt('itr7.partBTI.incFromOS.totIncFromOS')+getAmt('itr7.partBTI.voluntaryContributions.totIncFromVC');
		
		$('[name="itr7.partBTI.vcCorpusSec11"]')[0].value = getAmt('itr7.scheduleVC.local.corpusFundDonation')+getAmt('itr7.scheduleVC.foreign.corpusFundDonation');
		
		
		$('[name="itr7.partBTI.totalTI"]')[0].value = getAmt('itr7.partBTI.incomeFromHP')+getAmt('itr7.partBTI.profBusGain.profGainNoSpecBus')+getAmt('itr7.partBTI.capGain.totalCapGains')+getAmt('itr7.partBTI.incFromOS.totIncFromOS')+getAmt('itr7.partBTI.voluntaryContributions.totIncFromVC');
		
		
		$('[name="itr7.partBTI.tiDeductions.totalDeductions"]')[0].value = getAmt('itr7.partBTI.tiDeductions.amtAppliedtForCharitablePurpose')+getAmt('itr7.partBTI.tiDeductions.amtAppliedForRelegiousPurposeUs111A')+getAmt('itr7.partBTI.tiDeductions.amtAppForCharitablePurposeRepayment')
																		   +getAmt('itr7.partBTI.tiDeductions.amtDeemedForCharitable')+getAmt('itr7.partBTI.tiDeductions.amtAccumulatedForCharitable')+getAmt('itr7.partBTI.tiDeductions.amtFulfilledUs112')+getAmt('itr7.partBTI.tiDeductions.amtForCharitableUs111');
		
		$('[name="itr7.partBTI.tiAdditions.totalAdditions"]')[0].value = getAmt('itr7.partBTI.tiAdditions.incChargeableUs111B')+getAmt('itr7.partBTI.tiAdditions.incChargeableUs113')+getAmt('itr7.partBTI.tiAdditions.incChargeableUs122')+getAmt('itr7.partBTI.tiAdditions.anonymousDonationVC')+getAmt('itr7.partBTI.tiAdditions.otherThanAD');	

		
		$('[name="itr7.partBTI.incChargeableUs114"]')[0].value = getAmt('itr7.corpScheduleBP.chargeableUs11.incChargeableUs11');		
		$('[name="itr7.partBTI.totalTI"]')[0].value = getAmt('itr7.partBTI.totalTI')-getAmt('itr7.partBTI.vcCorpusSec11')-getAmt('itr7.partBTI.tiDeductions.totalDeductions')+getAmt('itr7.partBTI.tiAdditions.totalAdditions')+getAmt('itr7.partBTI.incChargeableUs114');
		if($('[name="itr7.partBTI.totalTI"]')[0].value < 0){
			$('[name="itr7.partBTI.totalTI"]')[0].value = parseInt('0',10);
		}
		$('[name="itr7.partBTI.incExemptUnderSec10"]')[0].value = getAmt('itr7.partBTI.exemptionUs10_21')+getAmt('itr7.partBTI.exemptionUs10_23C')+getAmt('itr7.partBTI.exemptionOtherthenUs10');
		$('[name="itr7.partBTI.totalIncomeChargeable"]')[0].value = getAmt('itr7.partBTI.totalTI')-getAmt('itr7.partBTI.exemptionUs10_21')-getAmt('itr7.partBTI.exemptionUs10_23C')-getAmt('itr7.partBTI.exemptionOtherthenUs10')+getAmt('itr7.partBTI.incChargeableUs11_3')-getAmt('itr7.partBTI.exemptionUs13_A_B');
		if($('[name="itr7.partBTI.totalIncomeChargeable"]')[0].value < 0){
			$('[name="itr7.partBTI.totalIncomeChargeable"]')[0].value = parseInt('0',10);
		}
		
		//CYLA
		$('[name="itr7.partBTI.currentYearLoss"]')[0].value = zeroOrMore(getAmt('itr7.scheduleCYLA.totalLossSetOff.totHPlossCurYrSetoff') + getAmt('itr7.scheduleCYLA.totalLossSetOff.totBusLossSetoff') + getAmt('itr7.scheduleCYLA.totalLossSetOff.totOthSrcLossNoRaceHorseSetoff')) ;
		$('[name="itr7.partBTI.grossTotalIncome"]')[0].value = getAmt('itr7.partBTI.totalIncomeChargeable')-getAmt('itr7.partBTI.currentYearLoss');
		
		if($('[name="itr7.partBTI.grossTotalIncome"]')[0].value < 0){
			$('[name="itr7.partBTI.grossTotalIncome"]')[0].value = parseInt('0',10);
		}
		
		//SI Income 1 to 4
		$('[name="itr7.partBTI.incChargeTaxSplRate111A112"]')[0].value = getAmt('itr7.scheduleSI.splCodeRateTax[0].splRateInc') + getAmt('itr7.scheduleSI.splCodeRateTax[1].splRateInc') + getAmt('itr7.scheduleSI.splCodeRateTax[2].splRateInc') + getAmt('itr7.scheduleSI.splCodeRateTax[3].splRateInc') + 
		getOSInc();		
                
		$('[name="itr7.partBTI.totalIncome"]')[0].value = Math.round(parseInt(getAmt('itr7.partBTI.grossTotalIncome')-getAmt('itr7.partBTI.deductionsUs10A')-getAmt('itr7.partBTI.deductionsUnderScheduleVIA'), 10)/10)*10;
	
				/*if(getAmt('itr7.partBTI.grossTotalIncome')-getAmt('itr7.partBTI.incChargeTaxSplRate111A112') > 0){
                    $('[name="itr7.partBTI.deductionsUnderScheduleVIA"]').attr('readOnly', false);
                }else{
                    $('[name="itr7.partBTI.deductionsUnderScheduleVIA"]')[0].value = 0;
                    $('[name="itr7.partBTI.deductionsUnderScheduleVIA"]').attr('readOnly', true);
                }*/
         
			if($('[name="itr7.partBTI.totalIncome"]')[0].value < 0){
			$('[name="itr7.partBTI.totalIncome"]')[0].value = parseInt('0',10);
		}
		
		$('[name="itr7.partBTI.incomeChargeableTotTax"]')[0].value = getAmt('itr7.scheduleSI.splCodeRateTax[0].taxableInc') + getAmt('itr7.scheduleSI.splCodeRateTax[1].taxableInc') + getAmt('itr7.scheduleSI.splCodeRateTax[2].taxableInc') + getAmt('itr7.scheduleSI.splCodeRateTax[3].taxableInc') + 
		getOSInc();	
		
                var temp14m15 = zeroOrMore(getAmt('itr7.partBTI.totalIncome')-getAmt('itr7.partBTI.incomeChargeableTotTax'));
                
                if(temp14m15 > getExemption()){
                    $('[name="itr7.partBTI.aggregateIncome"]')[0].value = zeroOrMore(getAmt('itr7.partBTI.totalIncome')-getAmt('itr7.partBTI.incomeChargeableTotTax')+getAmt('itr7.partBTI.netAgricultureIncomeOrOtherIncomeForRate'));
                }else{
                    $('[name="itr7.partBTI.aggregateIncome"]')[0].value = 0;
                }
		
         $('[name="itr7.partBTI.donationsUs115BBC"]')[0].value =  zeroOrMore(Math.round(zeroOrMore(getAmt('itr7.scheduleVC.anonymousDonations.anonymousDonations115BBC'))));

		//TTI
		var status = $('[name="itr7.partAGEN1.orgFirmInfo.statusOrCompanyType"]')[0].value;
		if(status == '3' || status == '4'){
			//From MAT 7, 5
			$('[name="itr7.partBTTI.computationOfTaxLiability.taxOnDeemedTotIncSec115JB"]')[0].value = getAmt('itr7.scheduleMAT.taxPayableUs115JB');
                        if($('[name="itr7.partBTTI.computationOfTaxLiability.grossTaxLiability"]')[0].value > $('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.totalTaxSec115JB"]')[0].value) {
                            $('[name="itr7.partBTTI.computationOfTaxLiability.credUs115JAATaxPaid"]')[0].value = getAmt('itr7.scheduleMATC.amtTaxCredUs115JAA');
                        } else {
                             $('[name="itr7.partBTTI.computationOfTaxLiability.credUs115JAATaxPaid"]')[0].value = parseInt('0',10);
                        }
		}else{
			//From AMT 4, 5
			$('[name="itr7.partBTTI.computationOfTaxLiability.taxOnDeemedTotIncSec115JB"]')[0].value = getAmt('itr7.itrScheduleAMT.taxPayableUnderSec115JC');
                        if($('[name="itr7.partBTTI.computationOfTaxLiability.grossTaxLiability"]')[0].value > $('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.totalTaxSec115JB"]')[0].value) {
                                $('[name="itr7.partBTTI.computationOfTaxLiability.credUs115JAATaxPaid"]')[0].value = getAmt('itr7.itrScheduleAMTC.taxSection115JD');
                        } else {
                             $('[name="itr7.partBTTI.computationOfTaxLiability.credUs115JAATaxPaid"]')[0].value = parseInt('0',10);
                        }
		}
		//Surcharge
/*                if(called !='scheduleSI' && called !='calcScheduleAMT'){
                    if($('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.surcharge"]')[0].noChange!=true && $('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.educationCess"]')[0].noChange!=true){
                            $('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.surcharge"]')[0].value = calculateItr7Surcharge();
                    }
                    else{
                        $('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.surcharge"]')[0].noChange = false;
                    }
                    if($('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.educationCess"]')[0].noChange!=true){
                            $('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.educationCess"]')[0].value = calculateItr7EduCess();

                    }else{
                        $('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.educationCess"]')[0].noChange = false;
                    }
                }*/
				
			var surcharge = $('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.surcharge"]')[0];
			var tmpSurcharge = calculateItr7Surcharge();
			if(surcharge.old != tmpSurcharge){
				surcharge.old = tmpSurcharge;
				surcharge.value = tmpSurcharge;
			}
			
			var educationCess = $('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.educationCess"]')[0];
			var tmpEducationCess = calculateItr7EduCess();
			if(educationCess.old != tmpEducationCess){
				educationCess.old = tmpEducationCess;
				educationCess.value = tmpEducationCess;
			}
				
		$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.totalTaxSec115JB"]')[0].value = getAmt('itr7.partBTTI.computationOfTaxLiability.taxOnDeemedTotIncSec115JB')+getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.surcharge')+getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.educationCess');	
                	
		
		if($('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtNormalRates"]')[0].noChange!=true && called !='calcScheduleAMT') {
			//if(getAmt('itr7.partBTI.aggregateIncome')>0){
				calculateTaxPayableOnTotalInc();
           /* }else{
                document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtNormalRates')[0].value = 0;
            }	*/		 
		} else {
//			$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtNormalRates"]')[0].noChange=false;
		}
		if($('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtSpecialRates"]')[0].noChange!=true && called !='calcScheduleAMT') {
			//$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtSpecialRates"]')[0].value = getAmt('itr7.scheduleSI.totSplRateIncTax');
                        var totSplRateIncTaxTemp = getAmt('itr7.scheduleSI.totSplRateIncTax');
              
			if($('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtSpecialRates"]')[0].old !=  totSplRateIncTaxTemp){
				$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtSpecialRates"]')[0].old = totSplRateIncTaxTemp;
				$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtSpecialRates"]')[0].value = totSplRateIncTaxTemp;	
			}
		} else {
			$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtSpecialRates"]')[0].noChange=false;
		}
		if($('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.donationUs115BC"]')[0].noChange!=true && called !='calcScheduleAMT') {			
			//$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.donationUs115BC"]')[0].value = Math.round(getAmt('itr7.partBTI.donationsUs115BBC') * 0.3);
			var donationsUs115BBC = Math.round(getAmt('itr7.partBTI.donationsUs115BBC') * 0.3);
			if($('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.donationUs115BC"]')[0].old !=  donationsUs115BBC){
				$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.donationUs115BC"]')[0].old = donationsUs115BBC;
				$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.donationUs115BC"]')[0].value = donationsUs115BBC;	
			}
		} else {
			$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.donationUs115BC"]')[0].noChange=false;
		}
		
		if($('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtMarginalRate"]')[0].noChange!=true && called !='calcScheduleAMT') {
			//$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtMarginalRate"]')[0].value = calculateTaxAtMaxMarginalRate();
			var taxAtMarginalRate = calculateTaxAtMaxMarginalRate();
			if($('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtMarginalRate"]')[0].old !=  taxAtMarginalRate){
				$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtMarginalRate"]')[0].old = taxAtMarginalRate;
				$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtMarginalRate"]')[0].value = taxAtMarginalRate;	
			}
		} else {
			$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtMarginalRate"]')[0].noChange=false;
		}
        if(called == 'dateOFFormOrIncorp' || called == 'statusOrCompanyType' || called == 'residentialStatus' || called == 'netAgricultureIncomeOrOtherIncomeForRate')
        {
            if(getAmt('itr7.partBTI.aggregateIncome')>0){
                $('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.rebateOnAgricultureInc"]')[0].value = calculateAgriRebate();
            }else{
                $('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.rebateOnAgricultureInc"]')[0].value =0;
            }
        }
                
		
		$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxPayableOnTotInc"]')[0].value = zeroOrMore(getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtNormalRates')+getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtSpecialRates')+getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.donationUs115BC')+getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtMarginalRate')-getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.rebateOnAgricultureInc'));
		$('[name="itr7.partBTTI.computationOfTaxLiability.surchargeOnTaxPayable"]')[0].value = calcNormalSurcharge();	
		$('[name="itr7.partBTTI.computationOfTaxLiability.educationCess"]')[0].value = Math.round((getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxPayableOnTotInc')+getAmt('itr7.partBTTI.computationOfTaxLiability.surchargeOnTaxPayable')) * 0.03);
		$('[name="itr7.partBTTI.computationOfTaxLiability.grossTaxLiability"]')[0].value = getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxPayableOnTotInc')+getAmt('itr7.partBTTI.computationOfTaxLiability.surchargeOnTaxPayable') + getAmt('itr7.partBTTI.computationOfTaxLiability.educationCess');
		$('[name="itr7.partBTTI.computationOfTaxLiability.grossTaxPayable"]')[0].value = Math.max(getAmt('itr7.partBTTI.computationOfTaxLiability.grossTaxLiability'), getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.totalTaxSec115JB'));
		
		
		
		
		$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableAfterCredUs115JAA"]')[0].value = zeroOrMore(getAmt('itr7.partBTTI.computationOfTaxLiability.grossTaxPayable') - getAmt('itr7.partBTTI.computationOfTaxLiability.credUs115JAATaxPaid'));
		
		//TR
		$('[name="itr7.partBTTI.computationOfTaxLiability.taxRelief.section90"]')[0].value = getAmt('scheduleTR1.totalIncomeOutIndia');
		$('[name="itr7.partBTTI.computationOfTaxLiability.taxRelief.section91"]')[0].value = getAmt('scheduleTR1.totalIncomeOutIndiaDTAA');
		
		limitTo($('[name="itr7.partBTTI.computationOfTaxLiability.taxRelief.section90"]')[0],getAmt('itr7.partBTTI.computationOfTaxLiability.grossTaxLiability'));		
		limitTo($('[name="itr7.partBTTI.computationOfTaxLiability.taxRelief.section91"]')[0],getAmt('itr7.partBTTI.computationOfTaxLiability.grossTaxLiability'));
		$('[name="itr7.partBTTI.computationOfTaxLiability.taxRelief.totTaxRelief"]')[0].value = getAmt('itr7.partBTTI.computationOfTaxLiability.taxRelief.section90') + getAmt('itr7.partBTTI.computationOfTaxLiability.taxRelief.section91');
		$('[name="itr7.partBTTI.computationOfTaxLiability.netTaxLiability"]')[0].value = zeroOrMore(getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableAfterCredUs115JAA') - getAmt('itr7.partBTTI.computationOfTaxLiability.taxRelief.totTaxRelief'));
		
		calculateAdvancedTax();
		calculateTDS();
		calculateTCS();
                
                
			if($('[name="itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234A"]')[0].noChange!=true && $('[name="itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234B"]')[0].noChange!=true && $('[name="itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234C"]')[0].noChange!=true ){
				calculate234Intrst(getAmt('itr7.partBTTI.taxPaid.taxesPaid.advanceTax'));
			}else{
				$('[name="itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234A"]')[0].noChange=false;
				$('[name="itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234B"]')[0].noChange=false;
				$('[name="itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234C"]')[0].noChange=false;
			}
                
		$('[name="itr7.partBTTI.computationOfTaxLiability.intrstPay.totalIntrstPay"]')[0].value = getAmt('itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234A') + getAmt('itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234B') + getAmt('itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234C');
		$('[name="itr7.partBTTI.computationOfTaxLiability.aggregateTaxInterestLiability"]')[0].value = zeroOrMore(getAmt('itr7.partBTTI.computationOfTaxLiability.netTaxLiability') + getAmt('itr7.partBTTI.computationOfTaxLiability.intrstPay.totalIntrstPay'));	
		
		$('[name="itr7.partBTTI.taxPaid.taxesPaid.totalTaxesPaid"]')[0].value = getAmt('itr7.partBTTI.taxPaid.taxesPaid.advanceTax')+getAmt('itr7.partBTTI.taxPaid.taxesPaid.selfAssessmentTax')+getAmt('itr7.partBTTI.taxPaid.taxesPaid.tds')+getAmt('itr7.partBTTI.taxPaid.taxesPaid.tcs');
		
		$('[name="itr7.partBTTI.taxPaid.balTaxPayable"]')[0].value=rndOffNrsTen(zeroOrMore(getAmt('itr7.partBTTI.computationOfTaxLiability.aggregateTaxInterestLiability')-getAmt('itr7.partBTTI.taxPaid.taxesPaid.totalTaxesPaid')));
		$('[name="itr7.partBTTI.refund.refundDue"]')[0].value=rndOffNrsTen(zeroOrMore(getAmt('itr7.partBTTI.taxPaid.taxesPaid.totalTaxesPaid')-getAmt('itr7.partBTTI.computationOfTaxLiability.aggregateTaxInterestLiability')));
                if(called !='scheduleSI' && called !='calcScheduleAMT'){
                    //schSIChangeIncome();
                	changeCYLA('titti');
                    calcScheduleAMT('calculateTiTti');                   
                    
                }
				calcScheduleAMTC('scheduleAMTC');
				
                calcMATCFromTTI();  
		$('[name="itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtNormalRates"]')[0].noChange=false;		
		
		
		
		calculateTotalTaxIT('scheduleIT');
	}
	

function getOSInc(){
	var tab = document.getElementById('schduleOsf');
	var rows = tab.rows.length - 3;
	var total = 0;
	for(var i=1;i<rows;i++){
		if(document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls[' + i + '].sourceDescription')[0].value!='Others'){
			total = parseInt(total) + parseInt(coalesce(document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls[' + i + '].sourceAmount')[0].value));
		}
	}
	return total;
}

        function getExemption(){
		var taxPayer = $('[name="itr7.partAGEN1.orgFirmInfo.statusOrCompanyType"]')[0];  
                if( (taxPayer.value=='1') || taxPayer.value=='2' || taxPayer.value=='6' || taxPayer.value=='7' || taxPayer.value=='8'){
                    return 250000;
                }else{
                    return 0;
                }
        }
        
        function calculateTaxAtMaxMarginalRate(){
             var prncpl = getAmt('itr7.partBTI.incChrgbleMaxMarginalRates');
             var status = $('[name="itr7.partAGEN1.orgFirmInfo.statusOrCompanyType"]')[0].value;
             if(status=='4'){
                 return Math.round(prncpl * 0.4);
             } else {
            	 return Math.round(prncpl * 0.3);
             }
             return 0;
        }
        
	function rndOffNrsTen(newVar){
		
            if(  parseInt(newVar.toString().charAt(newVar.toString().length-1),10) >= parseInt('5',10)){
                    newVar = eval(Math.floor(eval(parseInt(newVar,10) / parseInt('10',10))) * parseInt('10',10));
                    newVar = eval(parseInt(newVar,10) + parseInt('10',10));

                    return newVar;
            }else{
                    newVar = eval(Math.floor(eval(parseInt(newVar,10) / parseInt('10',10))) * parseInt('10',10));

                    return newVar;
            }

        }
	
	
	
	function calculateTaxPayableOnTotalInc(){
            
		var totalIncome = zeroOrMore(getAmt('itr7.partBTI.aggregateIncome') - getAmt('itr7.partBTI.donationsUs115BBC') - getAmt('itr7.partBTI.incChrgbleMaxMarginalRates'));
		 
		var taxPayer = $('[name="itr7.partAGEN1.orgFirmInfo.statusOrCompanyType"]')[0];
		//IN-01,HUF-02,AOP-06/07,DC-03,FC-04,FRM-05,LA-10,AJP-08,COP-09
		
		var netTxblIncome 		= totalIncome;
		var incTax 				= document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtNormalRates')[0];	
		var surcharge 			= document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.surchargeOnTaxPayable')[0];
		//var trIncTax 			= document.getElementById('trIncTax');
		
		var incTaxTemp = 0;
		
		//var totTaxLiab 			= document.getElementsByName('totTaxLiab')[0];				var trTotTaxLiab 		= document.getElementById('trTotTaxLiab');
		if( (taxPayer.value=='1') || taxPayer.value=='2' || taxPayer.value=='6' || taxPayer.value=='7' || taxPayer.value=='8' ){
		
            if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('0',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('250000',10)){
            	incTaxTemp = parseInt('0',10);
		}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('250001',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('500000',10)){
			incTaxTemp = eval( eval(parseInt(rndOffNrsTen(netTxblIncome),10) - parseInt('250000',10) )  * parseFloat('0.1')) ;
		}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('500001',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('1000000',10)){
			incTaxTemp = eval(eval(eval(parseInt(rndOffNrsTen(netTxblIncome),10) - parseInt('500000',10) )* parseFloat('0.2')) + parseInt('25000',10));
		}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('1000001',10)){
			incTaxTemp = eval(eval(eval(parseInt(rndOffNrsTen(netTxblIncome),10) - parseInt('1000000',10) )* parseFloat('0.3')) + parseInt('125000',10));
		}
		
	}else if(taxPayer.value=='9'){
            
		if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('0',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('10000',10)){
			incTaxTemp = eval(parseInt(rndOffNrsTen(netTxblIncome),10) * parseFloat('0.1')) ;
		}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('10001',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('20000',10)){
			incTaxTemp = eval( eval(eval(parseInt(rndOffNrsTen(netTxblIncome),10) - parseInt('10000',10) )  * parseFloat('0.2'))  + parseInt('1000',10)) ;
		}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('20001',10)){
			incTaxTemp = eval(eval(eval(parseInt(rndOffNrsTen(netTxblIncome),10) - parseInt('20000',10) )* parseFloat('0.3')) + parseInt('3000',10));
		}
		
		
	}else if(taxPayer.value=='3' || taxPayer.value=='5' || taxPayer.value=='10'){
		
		incTaxTemp = eval(parseInt(rndOffNrsTen(netTxblIncome),10) * parseFloat('0.3'));
		// for surcharge
		if(taxPayer.value=='3'){
			var taxOnTotInc =  parseInt(incTaxTemp,10);
			var taxOnCutOffInc = 10000000  * 0.3;

			if( rndOffNrsTen(netTxblIncome) > 10000000 ){
				var tempSurcharge = taxOnTotInc  * 0.05 ;
				
				//check if eligible for marginal relief
				var extraInc = rndOffNrsTen(netTxblIncome) - 10000000;
				if( (taxOnTotInc + tempSurcharge ) > (taxOnCutOffInc + extraInc)){
					var marginalRelief = taxOnTotInc + tempSurcharge - (taxOnCutOffInc + extraInc );
					surcharge.value = tempSurcharge - marginalRelief;
					surcharge.value  = Math.round(surcharge.value);
				}else {
					surcharge.value = tempSurcharge;
					surcharge.value  = Math.round(surcharge.value);
				}
			}
		}

	}else if(taxPayer.value=='4'){
            
		incTaxTemp = eval(parseInt(rndOffNrsTen(netTxblIncome),10) * parseFloat('0.4'));
		// for surcharge
			var taxOnTotInc =  parseInt(incTaxTemp,10);
			var taxOnCutOffInc = 10000000  * 0.4;

			if( rndOffNrsTen(netTxblIncome) > 10000000 ){
				var tempSurcharge = taxOnTotInc  * 0.02 ;
				
				//check if eligible for marginal relief
				var extraInc = rndOffNrsTen(netTxblIncome) - 10000000;
				if( (taxOnTotInc + tempSurcharge ) > (taxOnCutOffInc + extraInc)){
					var marginalRelief = taxOnTotInc + tempSurcharge - (taxOnCutOffInc + extraInc );
					surcharge.value = tempSurcharge - marginalRelief;
					surcharge.value  = Math.round(surcharge.value);
				}else {
					surcharge.value = tempSurcharge;
					surcharge.value  = Math.round(surcharge.value);
				}
			}		
	}
		
	if(incTax.old !=  incTaxTemp){
		incTax.old = incTaxTemp;
		incTax.value = incTaxTemp;	
	}	
		
}

	function calculateAgriRebate(){
		var totalIncome = zeroOrMore(getAmt('itr7.partBTI.netAgricultureIncomeOrOtherIncomeForRate'));

		var taxPayer = $('[name="itr7.partAGEN1.orgFirmInfo.statusOrCompanyType"]')[0];
		//IN-01,HUF-02,AOP-06/07,DC-03,FC-04,FRM-05,LA-10,AJP-08,COP-09
		
		var netTxblIncome 		= totalIncome;
		var incTax 				= document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.rebateOnAgricultureInc')[0];	
		//var trIncTax 			= document.getElementById('trIncTax');
		
		//var totTaxLiab 			= document.getElementsByName('totTaxLiab')[0];				var trTotTaxLiab 		= document.getElementById('trTotTaxLiab');
		
		if( (taxPayer.value=='1') || taxPayer.value=='2' || taxPayer.value=='6' || taxPayer.value=='7' || taxPayer.value=='8' ){
            
		netTxblIncome = eval(netTxblIncome) + eval(parseInt('250000',10));
		if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('0',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('250000',10)){
			incTax.value = parseInt('0',10);
		}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('250001',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('500000',10)){
			incTax.value = eval( eval(parseInt(rndOffNrsTen(netTxblIncome),10) - parseInt('250000',10) )  * parseFloat('0.1')) ;
		}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('500001',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('1000000',10)){
			incTax.value = eval(eval(eval(parseInt(rndOffNrsTen(netTxblIncome),10) - parseInt('500000',10) )* parseFloat('0.2')) + parseInt('25000',10));
		}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('1000001',10)){
			incTax.value = eval(eval(eval(parseInt(rndOffNrsTen(netTxblIncome),10) - parseInt('1000000',10) )* parseFloat('0.3')) + parseInt('125000',10));
		}
		
	}else if(taxPayer.value=='9'){
		if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('0',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('10000',10)){
			incTax.value = eval(parseInt(rndOffNrsTen(netTxblIncome),10) * parseFloat('0.1')) ;
		}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('10001',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('20000',10)){
			incTax.value = eval( eval(eval(parseInt(rndOffNrsTen(netTxblIncome),10) - parseInt('10000',10) )  * parseFloat('0.2'))  + parseInt('1000',10)) ;
		}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('20001',10)){
			incTax.value = eval(eval(eval(parseInt(rndOffNrsTen(netTxblIncome),10) - parseInt('20000',10) )* parseFloat('0.3')) + parseInt('3000',10));
		}
		
		
	}else if(taxPayer.value=='3' || taxPayer.value=='5' || taxPayer.value=='10'){
		
		incTax.value = eval(parseInt(rndOffNrsTen(netTxblIncome),10) * parseFloat('0.3'));


	}else if(taxPayer.value=='4'){
		incTax.value = eval(parseInt(rndOffNrsTen(netTxblIncome),10) * parseFloat('0.4'));		
	}
	return incTax.value;	
}
	
	function calculateAdvancedTax(){
		var advanceTax = parseInt('0' ,10) ;
		var selfAssessmentTax = parseInt('0' ,10) ;
		var tab3 = document.getElementById('scheduleIT');
		var allInputTags = tab3.getElementsByTagName('input');
		for(var i = 0; i < allInputTags.length; i++) {
			if(allInputTags[i].name.match("dateDep$")){
				if(checkFirstDateBefore('01/04/2014' , allInputTags[i].value) && checkFirstDateBefore(allInputTags[i].value , '31/03/2015')){
						advanceTax = eval( parseInt(isNVL(advanceTax) ,10) + parseInt(isNVL(allInputTags[i+2].value) ,10));
					}else if( checkFirstDateBefore('01/04/2015' , allInputTags[i].value)){
						selfAssessmentTax = eval(parseInt(isNVL(selfAssessmentTax) ,10) + parseInt(isNVL(allInputTags[i+2].value) ,10)) ;
					}
			}
		}
		$('[name="itr7.partBTTI.taxPaid.taxesPaid.advanceTax"]')[0].value = advanceTax;
		$('[name="itr7.partBTTI.taxPaid.taxesPaid.selfAssessmentTax"]')[0].value = selfAssessmentTax;
		return advanceTax;
	}
	
	function calculateAdvancedTax234A(date){
		var advanceTax = parseInt('0' ,10) ;
		var selfAssessmentTax = parseInt('0' ,10) ;
		var tab3 = document.getElementById('scheduleIT');
		var allInputTags = tab3.getElementsByTagName('input');
		for(var i = 0; i < allInputTags.length; i++) {
			if(allInputTags[i].name.match("dateDep$")){
				if(checkFirstDateBefore('01/04/2015' , allInputTags[i].value) && checkFirstDateBefore(allInputTags[i].value , date)){
						advanceTax = eval( parseInt(isNVL(advanceTax) ,10) + parseInt(isNVL(allInputTags[i+2].value) ,10));
					}
			}
		}
		return advanceTax;
	}
	
function calculateTDS(){
    var TDS = parseInt('0' ,10);
	var TDS2 = parseInt('0' ,10);
	var tab2 = document.getElementById('scheduleTDS');
	var allInputTags = tab2.getElementsByTagName('input');
		for(var i = 0; i < allInputTags.length; i++) {
				if (allInputTags[i].name.match("claimOwnHands$")) {
					if(eval(parseInt(coalesce(allInputTags[i].value),10)) >  eval(parseInt(coalesce(allInputTags[i-1].value),10) + parseInt(coalesce(allInputTags[i-2].value),10))){//+parseInt(coalesce(allInputTags[i+1].value),10)
						addError(allInputTags[i],'Amount claimed for this year cannot be more than total tax deducted',true);
						j.setFieldError(allInputTags[i].name,'Amount claimed for this year cannot be more than total tax deducted');
						allInputTags[i].value = '0';
						TDS2 = eval(parseInt(TDS2 ,10) + parseInt(isNVL(allInputTags[i].value) ,10));
					}else{
						TDS2 = eval(parseInt(TDS2 ,10) + parseInt(isNVL(allInputTags[i].value) ,10));
					}
					allInputTags[i+1].value = zeroOrMore(parseInt(coalesce(allInputTags[i-2].value)) + parseInt(coalesce(allInputTags[i-1].value))
					- parseInt(coalesce(allInputTags[i].value)));
				}
			}

	var TDS3 = parseInt('0' ,10);
	var tab3 = document.getElementById('scheduleTDS3');
	var allInputTagsTDS3 = tab3.getElementsByTagName('input');
		for(var i = 0; i < allInputTagsTDS3.length; i++) {
				if (allInputTagsTDS3[i].name.match("claimOwnHands$")) {
					if(eval(parseInt(coalesce(allInputTagsTDS3[i].value),10)) >  eval(parseInt(coalesce(allInputTagsTDS3[i-1].value),10) + parseInt(coalesce(allInputTagsTDS3[i-2].value),10))){//+parseInt(coalesce(allInputTagsTDS3[i+1].value),10)
						addError(allInputTagsTDS3[i],'Amount claimed for this year cannot be more than total tax deducted',true);
						j.setFieldError(allInputTagsTDS3[i].name,'Amount claimed for this year cannot be more than total tax deducted');
						allInputTagsTDS3[i].value = '0';
						TDS3 = eval(parseInt(TDS3 ,10) + parseInt(isNVL(allInputTagsTDS3[i].value) ,10));
					}else{
						TDS3 = eval(parseInt(TDS3 ,10) + parseInt(isNVL(allInputTagsTDS3[i].value) ,10));
					}
					allInputTagsTDS3[i+1].value = zeroOrMore(parseInt(coalesce(allInputTagsTDS3[i-2].value)) + parseInt(coalesce(allInputTagsTDS3[i-1].value))
					- parseInt(coalesce(allInputTagsTDS3[i].value)));
				}
			}


		document
		.getElementsByName('scheduleTDS1.tdSonOthThanSal.totalTDSonSalaries')[0].value = parseInt(
		TDS2, 10);
document
		.getElementsByName('scheduleTDS2.tdSonOthThanSal.totalTDSonSalaries')[0].value = parseInt(
		TDS3, 10);
	TDS=eval(parseInt(TDS2,10)+parseInt(TDS3,10));
	document.getElementsByName('itr7.partBTTI.taxPaid.taxesPaid.tds')[0].value = parseInt(TDS,10);
	
	return TDS;
}
	
  function calculateTCS(){
	var TCS = parseInt('0' ,10);
	var tcsTAB = document.getElementById('scheduleTCS');
	var allInputTags = tcsTAB.getElementsByTagName('input');
		for(var i = 0; i < allInputTags.length; i++) {
			if (allInputTags[i].name.match("amtTCSClaimedThisYear$")) {
				if(parseInt(allInputTags[i].value,10) >  parseInt(allInputTags[i-1].value,10) + parseInt(coalesce(allInputTags[i-2].value),10)){
					addErrorXHTML(allInputTags[i],'Amount claimed cannot exceed Total Tax collected',true);
					j.setFieldError(allInputTags[i].name,'Amount claimed cannot exceed Total Tax collected');
					allInputTags[i].value = '0';
					TCS = eval(parseInt(TCS ,10) + parseInt(isNVL(allInputTags[i].value) ,10));
				}else{
					TCS = eval(parseInt(TCS ,10) + parseInt(isNVL(allInputTags[i].value) ,10));
				}
				allInputTags[i+1].value = zeroOrMore(parseInt(coalesce(allInputTags[i-2].value)) + parseInt(coalesce(allInputTags[i-1].value))
						- parseInt(coalesce(allInputTags[i].value)));
			}
		}
	$('[name="itr7.partBTTI.taxPaid.taxesPaid.tcs"]')[0].value = parseInt(TCS,10);
	$('[name="scheduleTCS.totalTcSSalary"]')[0].value = parseInt(TCS,10);
	return TCS;
}
	
	function calculateItr7Surcharge(){
		var netTxblIncome = zeroOrMore(getAmt('itr7.itrScheduleAMT.adjustedUnderSec115JC'));
		var status = $('[name="itr7.partAGEN1.orgFirmInfo.statusOrCompanyType"]')[0].value;
		if(status=='3' || status=='4'){
			netTxblIncome = zeroOrMore(getAmt('itr7.scheduleMAT.bookProfUs115JB'));
		}
		if((status=='3' || status=='4') && netTxblIncome > 100000000){
			return calculateItr7SurchargeOver10Crore();
		}		
		var surcharge = 0;
		var taxOnTotInc = getAmt('itr7.partBTTI.computationOfTaxLiability.taxOnDeemedTotIncSec115JB');
			if(netTxblIncome > 10000000){
			var surchargeRate = 0.1;
			if(status == '4'){	
				surchargeRate = 0.02;
			}else if(status == '3'){	
				surchargeRate = 0.05;
			}
			
				var taxOnCutOffInc = 10000000  * 0.185;
				if( rndOffNrsTen(netTxblIncome) > 10000000 ){
					var tempSurcharge = taxOnTotInc  * surchargeRate ;
					
					//check if eligible for marginal relief
					var extraInc = rndOffNrsTen(netTxblIncome) - 10000000;
					if( (taxOnTotInc + tempSurcharge ) > (taxOnCutOffInc + extraInc)){
						var marginalRelief = zeroOrMore(taxOnTotInc + tempSurcharge - (taxOnCutOffInc + extraInc ));
						surcharge = zeroOrMore(tempSurcharge - marginalRelief);
						surcharge  = Math.round(surcharge);
					}else {
						surcharge = tempSurcharge;
						surcharge  = Math.round(surcharge);
					}
				}
		}
		return Math.round(surcharge);
	}
	
	function calculateItr7SurchargeOver10Crore(){
		var netTxblIncome = zeroOrMore(getAmt('itr7.scheduleMAT.bookProfUs115JB'));
		var status = $('[name="itr7.partAGEN1.orgFirmInfo.statusOrCompanyType"]')[0].value;
		var surcharge = 0;
		var taxOnTotInc = getAmt('itr7.partBTTI.computationOfTaxLiability.taxOnDeemedTotIncSec115JB');
			if(netTxblIncome > 100000000){
			var surchargeRate = 0.1;
			var chargeOn1Crore = 1.05;
			if(status == '4'){	
				surchargeRate = 0.05;
				chargeOn1Crore = 1.02;
			}			
				var taxOnCutOffInc = 100000000  * 0.185 * chargeOn1Crore;
				if( rndOffNrsTen(netTxblIncome) > 100000000 ){
					var tempSurcharge = taxOnTotInc  * surchargeRate ;
					
					//check if eligible for marginal relief
					var extraInc = rndOffNrsTen(netTxblIncome) - 100000000;
					if( (taxOnTotInc + tempSurcharge ) > (taxOnCutOffInc + extraInc)){
						var marginalRelief = zeroOrMore(taxOnTotInc + tempSurcharge - (taxOnCutOffInc + extraInc ));
						surcharge = zeroOrMore(tempSurcharge - marginalRelief);
						surcharge  = Math.round(surcharge);
					}else {
						surcharge = tempSurcharge;
						surcharge  = Math.round(surcharge);
					}
				}
		}
		return Math.round(surcharge);
	}	
	
	function calcNormalSurcharge(){
		var taxPayer = document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0];
	
		var netIncome = getAmt('itr7.partBTI.totalIncome');
        var netTxblIncome = zeroOrMore(netIncome);
    	
		if((taxPayer.value=='3' || taxPayer.value=='4') && netTxblIncome > 100000000){
			
			return calculateItr7SurchargeFor10Crore();
		}
		return calculateItr7SurchargeTTI2f();
	}
	
	function calculateItr7SurchargeFor10Crore(){
		var surcharge = 0;
		var netIncome = getAmt('itr7.partBTI.totalIncome');
        var netTxblIncome = zeroOrMore(netIncome);
        var totalIncome = document.getElementsByName('itr7.partBTI.totalIncome')[0].value;
        var incChargeTaxSplRate111A112 = document.getElementsByName('itr7.partBTI.incChargeTaxSplRate111A112')[0].value;
               
		var dtaaInc = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[5].splRateInc')[0].value;
		var dtaaTax = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[5].splRateIncTax')[0].value;
                
		var tax = getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxPayableOnTotInc');
		
		var taxAtSpecialRates = getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtSpecialRates');
		
			if(netTxblIncome > 100000000){
				
				var normalInc = getSlabbedIncome(parseInt(totalIncome - incChargeTaxSplRate111A112));
				
				var taxOnTotInc = eval(parseInt(calculateSlabbedTax(parseInt(totalIncome - incChargeTaxSplRate111A112)),10) +parseInt( taxAtSpecialRates,10));
				
				var toBeTaxed = 100000000 - coalesce(dtaaInc);
								
				var rowCount1 = countRowInTable('itr7.scheduleSI.splCodeRateTax', 'splRateInc');

				var percent5SIInc = 0;

				var percent10SIInc = 0;

				var percent15SIInc = 0;

				var percent20SIInc = 0;
				
				var percent125SIInc=0;

				var percent25SIInc = 0;

				var percent30SIInc = 0;

				var percent50SIInc = 0;
				
								
				for ( var i = 0; i < rowCount1; i++) {

					var splRatePercent = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].splRatePercent')[0].value;
					

					if (splRatePercent == 5) {

						percent5SIInc = eval(parseInt(percent5SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i	+ '].taxableInc')[0].value, 10));

					} else if (splRatePercent == 10) {

						percent10SIInc = eval(parseInt(percent10SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					} else if (splRatePercent == 12.5) {

						percent125SIInc = eval(parseInt(percent125SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					}else if (splRatePercent == 15) {

						percent15SIInc = eval(parseInt(percent15SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					} else if (splRatePercent == 20) {

						percent20SIInc = eval(parseInt(percent20SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					} else if (splRatePercent == 25) {

						percent25SIInc = eval(parseInt(percent25SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					} else if (splRatePercent == 30) {

						percent30SIInc = eval(parseInt(percent30SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					} else if (splRatePercent == 50) {

						percent50SIInc = eval(parseInt(percent50SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					} 
				}
				
				var cgTax = 0;
				
				var cgTaxed = 0;
				
				var exmptn10 = coalesceSetRet('itr7.scheduleSI.splCodeRateTax[1].splRateInc') -
				coalesceSetRet('itr7.scheduleSI.splCodeRateTax[1].taxableInc');
				
				var exmptn15 = coalesceSetRet('itr7.scheduleSI.splCodeRateTax[0].splRateInc') -
				coalesceSetRet('itr7.scheduleSI.splCodeRateTax[0].taxableInc');
				
				var exmptn20 = coalesceSetRet('itr7.scheduleSI.splCodeRateTax[2].splRateInc') -
				coalesceSetRet('itr7.scheduleSI.splCodeRateTax[2].taxableInc');
				
				var exemption = getExemption() - exmptn10 - exmptn15 - exmptn20;
				
				var exemptionUsed = 0;
				
				if (parseInt(totalIncome - incChargeTaxSplRate111A112) > 0) {
					if (parseInt(totalIncome - incChargeTaxSplRate111A112) >= getExemption()) {
						exemptionUsed = getExemption();
					} else {
						exemptionUsed = parseInt(totalIncome - incChargeTaxSplRate111A112);
					}

				}

				toBeTaxed = zeroOrMore(parseInt(toBeTaxed - exemptionUsed - exmptn10 - exmptn15 - exmptn20));
				
				
				if (parseInt(percent5SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = (percent5SIInc) * 0.05;
					cgTaxed = percent5SIInc;
					toBeTaxed -= parseInt(percent5SIInc, 0);
				} else {
					cgTax = (toBeTaxed) * 0.05;
					cgTaxed = toBeTaxed;
					toBeTaxed = 0;
				}

				percent10SIInc = parseInt(percent10SIInc, 10)+ parseInt(normalInc["10"], 10);

				if (parseInt(percent10SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent10SIInc) * 0.1;
					cgTaxed = parseInt(cgTaxed) + percent10SIInc;
					toBeTaxed -= parseInt(percent10SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * 0.1;
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}
				
				if (parseInt(percent125SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent125SIInc) *parseFloat(0.125);
					cgTaxed = parseInt(cgTaxed) + percent125SIInc;
					toBeTaxed -= parseInt(percent125SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * parseFloat(0.125);
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}

				if (parseInt(percent15SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent15SIInc) * parseFloat(0.15);
					cgTaxed = parseInt(cgTaxed) + percent15SIInc;
					toBeTaxed -= parseInt(percent15SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * parseFloat(0.15);
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}

				percent20SIInc = parseInt(percent20SIInc, 10)
						+ parseInt(normalInc["20"], 10);
				
				if (parseInt(percent20SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent20SIInc) * 0.2;
					cgTaxed = parseInt(cgTaxed) + percent20SIInc;
					toBeTaxed -= parseInt(percent20SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * 0.2;
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}

				if (parseInt(percent25SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent25SIInc) * 0.25;
					cgTaxed = parseInt(cgTaxed) + percent25SIInc;
					toBeTaxed -= parseInt(percent25SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * 0.25;
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}

				percent30SIInc = parseInt(percent30SIInc, 10)
						+ parseInt(normalInc["30"], 10);

				if (parseInt(percent30SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent30SIInc) * 0.3;
					cgTaxed = parseInt(cgTaxed) + percent30SIInc;
					toBeTaxed -= parseInt(percent30SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * 0.3;
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}
				
				if (parseInt(normalInc["40"], 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (normalInc["40"]) * 0.4;
					cgTaxed = parseInt(cgTaxed) + normalInc["40"];
					toBeTaxed -= parseInt(normalInc["40"], 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * 0.4;
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}

				if (parseInt(percent50SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent50SIInc) * 0.5;
					cgTaxed = parseInt(cgTaxed) + percent50SIInc;
					toBeTaxed -= parseInt(percent50SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * 0.5;
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}
				var taxPayer = document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0];
				var surchrgeRate = 0.1;	
				var chargeOn1Crore = 1.05;
				if(taxPayer.value=='4'){
					surchrgeRate = 0.05;
					chargeOn1Crore = 1.02;
				}
				
				
				var taxOnCutOffInc = (parseInt(cgTax) + parseInt(dtaaTax)) * chargeOn1Crore;;			
				

				var tempSurcharge = tax  * surchrgeRate;

					//check if eligible for marginal relief
					var extraInc = rndOffNrsTen(netTxblIncome) - 100000000;
					
					if( (taxOnTotInc + tempSurcharge ) > (taxOnCutOffInc + extraInc)){
						var marginalRelief =zeroOrMore( taxOnTotInc + tempSurcharge - (taxOnCutOffInc + extraInc ));
						surcharge = zeroOrMore(tempSurcharge - marginalRelief);
						surcharge  = Math.round(surcharge);
						
					}else {
						surcharge = tempSurcharge;
						surcharge  = Math.round(surcharge);
						}
				
				
				
			}else{
				surcharge = 0;
			}	
		return Math.round(surcharge);
	}
	
	function calculateItr7SurchargeTTI2f(){
		var status = $('[name="itr7.partAGEN1.orgFirmInfo.statusOrCompanyType"]')[0].value;
		var surcharge = 0;
		var netIncome = getAmt('itr7.partBTI.totalIncome');
        var netTxblIncome = zeroOrMore(netIncome);
        var totalIncome = document.getElementsByName('itr7.partBTI.totalIncome')[0].value;
        var incChargeTaxSplRate111A112 = document.getElementsByName('itr7.partBTI.incChargeTaxSplRate111A112')[0].value;
               
		var dtaaInc = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[5].splRateInc')[0].value;
		var dtaaTax = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[5].splRateIncTax')[0].value;
                
		var tax =  document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxPayableOnTotInc')[0].value;
		
		var taxAtSpecialRates = getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnTI.taxAtSpecialRates');
		
			if(netTxblIncome > 10000000){
				
				var taxOnTotInc = parseInt(calculateSlabbedTax(totalIncome - incChargeTaxSplRate111A112)) + parseInt(taxAtSpecialRates); 

				var normalInc = getSlabbedIncome(parseInt(totalIncome - incChargeTaxSplRate111A112));
				
				var toBeTaxed = 10000000 - coalesce(dtaaInc);
				
				var rowCount1 = countRowInTable('itr7.scheduleSI.splCodeRateTax', 'splRateInc');
				
				var percent5SIInc = 0;

				var percent10SIInc = 0;

				var percent15SIInc = 0;

				var percent20SIInc = 0;
				
				var percent125SIInc=0;

				var percent25SIInc = 0;

				var percent30SIInc = 0;

				var percent50SIInc = 0;
				
								
				for ( var i = 0; i < rowCount1; i++) {

					var splRatePercent = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].splRatePercent')[0].value;
					
					if (splRatePercent == 5) {

						percent5SIInc = eval(parseInt(percent5SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i	+ '].taxableInc')[0].value, 10));

					} else if (splRatePercent == 10) {

						percent10SIInc = eval(parseInt(percent10SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					} else if (splRatePercent == 12.5) {

						percent125SIInc = eval(parseInt(percent125SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					}else if (splRatePercent == 15) {

						percent15SIInc = eval(parseInt(percent15SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					} else if (splRatePercent == 20) {

						percent20SIInc = eval(parseInt(percent20SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					} else if (splRatePercent == 25) {

						percent25SIInc = eval(parseInt(percent25SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					} else if (splRatePercent == 30) {

						percent30SIInc = eval(parseInt(percent30SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					} else if (splRatePercent == 50) {

						percent50SIInc = eval(parseInt(percent50SIInc, 10) + parseInt(document.getElementsByName('itr7.scheduleSI.splCodeRateTax[' + i + '].taxableInc')[0].value, 10));

					} 
				}
				
				
				var cgTax = 0;
				
				var cgTaxed = 0;
				
				var exmptn10 = coalesceSetRet('itr7.scheduleSI.splCodeRateTax[1].splRateInc') -
				coalesceSetRet('itr7.scheduleSI.splCodeRateTax[1].taxableInc');
				
				var exmptn15 = coalesceSetRet('itr7.scheduleSI.splCodeRateTax[0].splRateInc') -
				coalesceSetRet('itr7.scheduleSI.splCodeRateTax[0].taxableInc');
				
				var exmptn20 = coalesceSetRet('itr7.scheduleSI.splCodeRateTax[2].splRateInc') -
				coalesceSetRet('itr7.scheduleSI.splCodeRateTax[2].taxableInc');
				
				var exemption = getExemption() - exmptn10 - exmptn15 - exmptn20;
				
				var exemptionUsed = 0;
				
				if (parseInt(totalIncome - incChargeTaxSplRate111A112) > 0) {
					if (parseInt(totalIncome - incChargeTaxSplRate111A112) >= getExemption()) {
						exemptionUsed = getExemption();
					} else {
						exemptionUsed = parseInt(totalIncome - incChargeTaxSplRate111A112);
					}

				}

				toBeTaxed = zeroOrMore(parseInt(toBeTaxed - exemptionUsed - exmptn10 - exmptn15 - exmptn20));
				
				if (parseInt(percent5SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = (percent5SIInc) * 0.05;
					cgTaxed = percent5SIInc;
					toBeTaxed -= parseInt(percent5SIInc, 0);
				} else {
					cgTax = (toBeTaxed) * 0.05;
					cgTaxed = toBeTaxed;
					toBeTaxed = 0;
				}

				percent10SIInc = parseInt(percent10SIInc, 10)+ parseInt(normalInc["10"], 10);

				if (parseInt(percent10SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent10SIInc) * 0.1;
					cgTaxed = parseInt(cgTaxed) + percent10SIInc;
					toBeTaxed -= parseInt(percent10SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * 0.1;
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}
				
				if (parseInt(percent125SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent125SIInc) *parseFloat(0.125);
					cgTaxed = parseInt(cgTaxed) + percent125SIInc;
					toBeTaxed -= parseInt(percent125SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * parseFloat(0.125);
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}

				if (parseInt(percent15SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent15SIInc) * parseFloat(0.15);
					cgTaxed = parseInt(cgTaxed) + percent15SIInc;
					toBeTaxed -= parseInt(percent15SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * parseFloat(0.15);
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}

				percent20SIInc = parseInt(percent20SIInc, 10)
						+ parseInt(normalInc["20"], 10);
				
				if (parseInt(percent20SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent20SIInc) * 0.2;
					cgTaxed = parseInt(cgTaxed) + percent20SIInc;
					toBeTaxed -= parseInt(percent20SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * 0.2;
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}

				if (parseInt(percent25SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent25SIInc) * 0.25;
					cgTaxed = parseInt(cgTaxed) + percent25SIInc;
					toBeTaxed -= parseInt(percent25SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * 0.25;
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}

				percent30SIInc = parseInt(percent30SIInc, 10)
						+ parseInt(normalInc["30"], 10);

				if (parseInt(percent30SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent30SIInc) * 0.3;
					cgTaxed = parseInt(cgTaxed) + percent30SIInc;
					toBeTaxed -= parseInt(percent30SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * 0.3;
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}
				
				if (parseInt(normalInc["40"], 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (normalInc["40"]) * 0.4;
					cgTaxed = parseInt(cgTaxed) + normalInc["40"];
					toBeTaxed -= parseInt(normalInc["40"], 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * 0.4;
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}
				
				if (parseInt(percent50SIInc, 10) < parseInt(toBeTaxed, 0)) {
					cgTax = parseInt(cgTax, 10) + (percent50SIInc) * 0.5;
					cgTaxed = parseInt(cgTaxed) + percent50SIInc;
					toBeTaxed -= parseInt(percent50SIInc, 0);
				} else {
					cgTax = parseInt(cgTax, 10) + (toBeTaxed) * 0.5;
					cgTaxed = parseInt(cgTaxed) + toBeTaxed;
					toBeTaxed = 0;
				}
				
				
				var taxOnCutOffInc = eval(parseInt(coalesce(cgTax)) + parseInt(coalesce(dtaaTax)));

				var taxPayer = document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0];
				var surchrgeRate = 0.1;	
				if(taxPayer.value=='4'){
					surchrgeRate = 0.02;
				}else if(taxPayer.value=='3'){
					surchrgeRate = 0.05;
				}
				var tempSurcharge = tax  * surchrgeRate;
					
					
					//check if eligible for marginal relief
					var extraInc = rndOffNrsTen(netTxblIncome) - 10000000;
					
					if( (taxOnTotInc + tempSurcharge ) > (taxOnCutOffInc + extraInc)){
						
						var marginalRelief =zeroOrMore( taxOnTotInc + tempSurcharge - (taxOnCutOffInc + extraInc ));
						surcharge = zeroOrMore(tempSurcharge - marginalRelief);
						surcharge  = Math.round(surcharge);
						
					}else {
						surcharge = tempSurcharge;
						surcharge  = Math.round(surcharge);
						}
				
				
				
			}else{
				surcharge = 0;
			}	
			
		return Math.round(surcharge);
	}
	
	function calcAge(){
		var dob = document.getElementsByName('itr7.partAGEN1.orgFirmInfo.dateOFFormOrIncorp')[0];
		var retVal = calcAgeCommon(dob);
		return retVal;
	}
	
	function getSlabbedIncome(totalIncome){
		
		var taxPayer = document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0];
		
		var netTxblIncome 		= totalIncome;

		var inc = {"10":0,"20":0,"30":0, "40":0};
		if(taxPayer.value=='1' || taxPayer.value=='2' || taxPayer.value=='6'|| taxPayer.value=='7'|| taxPayer.value=='8'){
		//if((taxPayer.value=='1') || (taxPayer.value=='2')){
			
			if(parseInt(netTxblIncome,10) >= parseInt('0',10) && parseInt(netTxblIncome,10) <= parseInt('250000',10)){
				inc = {"10":0, "20":0, "30":0, "40":0};
			}else if(parseInt(netTxblIncome,10) >= parseInt('250001',10) && parseInt(netTxblIncome,10) <= parseInt('500000',10)){
				inc = {"10":(parseInt(netTxblIncome,10) - 250000), "20":0, "30":0, "40":0};
			}else if(parseInt(netTxblIncome,10) >= parseInt('500001',10) && parseInt(netTxblIncome,10) <= parseInt('1000000',10)){
				inc = {"10":250000, "20":(parseInt(netTxblIncome,10) - 500000), "30":0, "40":0};
			}else if(parseInt(netTxblIncome,10) >= parseInt('1000001',10)){
				inc = {"10":250000, "20":500000, "30":(parseInt(netTxblIncome,10) - 1000000), "40":0};
			}
			
		}else if(taxPayer.value =='3' || taxPayer.value =='5' || taxPayer.value =='10'){
			inc = {"10":0, "20":0, "30":(parseInt(netTxblIncome,10)), "40":0};
			
		}else if(taxPayer.value =='4'){
			inc = {"10":0, "20":0, "30":0,"40":(parseInt(netTxblIncome,10))};
			
		}else if(taxPayer.value=='9'){
			if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('0',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('10000',10)){
				inc = {"10":parseInt(netTxblIncome), "20":0, "30":0,"40":0};
			}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('10001',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('20000',10)){
				inc = {"10":10000, "20":parseInt(netTxblIncome)-10000, "30":0,"40":0};
			}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('20001',10)){
				inc = {"10":10000, "20":10000, "30":parseInt(netTxblIncome)-20000,"40":0};
			}	
		}
		return inc;
	}
	
	
	function calculateSlabbedTax(netTxblIncome){
		var incTax = 0;
		

		var status=document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0].value; 
		if(status=='1' || status=='2' || status=='6' || status=='7' || status=='8'){
		
			if(parseInt(netTxblIncome,10) >= parseInt('0',10) && parseInt(netTxblIncome,10) <= parseInt('250000',10)){
				incTax = parseInt('0',10);
			}else if(parseInt(netTxblIncome,10) >= parseInt('250001',10) && parseInt(netTxblIncome,10) <= parseInt('500000',10)){
				incTax = Math.round(eval( eval(parseInt(netTxblIncome,10) - parseInt('250000',10) )  * parseFloat('0.1'))) ;
			}else if(parseInt(netTxblIncome,10) >= parseInt('500001',10) && parseInt(netTxblIncome,10) <= parseInt('1000000',10)){
				incTax = Math.round(eval(eval(eval(parseInt(netTxblIncome,10) - parseInt('500000',10) )* parseFloat('0.2')) + parseInt('25000',10)));
			}else if(parseInt(netTxblIncome,10) >= parseInt('1000001',10)){
				incTax = Math.round(eval(eval(eval(parseInt(netTxblIncome,10) - parseInt('1000000',10) )* parseFloat('0.3')) + parseInt('125000',10)));
			}
			
		}else if(status=='3' || status=='5' || status=='10'){
			incTax = parseInt(netTxblIncome,10) * 0.3;
		}else if(status=='4'){
			incTax = parseInt(netTxblIncome,10) * 0.4;
		}else if(status=='9'){
			if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('0',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('10000',10)){
				incTax = eval(parseInt(rndOffNrsTen(netTxblIncome),10) * parseFloat('0.1'));
			}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('10001',10) && parseInt(rndOffNrsTen(netTxblIncome),10) <= parseInt('20000',10)){
				incTax = eval( eval(parseInt(rndOffNrsTen(netTxblIncome),10) - parseInt('10000',10) )  * parseFloat('0.2') + parseInt('1000',10)) ;
			}else if(parseInt(rndOffNrsTen(netTxblIncome),10) >= parseInt('20001',10)){
				incTax = eval(eval(eval(parseInt(rndOffNrsTen(netTxblIncome),10) - parseInt('20000',10) )* parseFloat('0.3')) + parseInt('3000',10));
			}
		}
		return incTax;
}
	
	
	
	function calculateItr7EduCess(){
		var totalTax = getAmt('itr7.partBTTI.computationOfTaxLiability.taxOnDeemedTotIncSec115JB') + getAmt('itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.surcharge');
		var eduCess = totalTax * 0.02;
		var secEdCess = totalTax * 0.01;
		return Math.round(eduCess + secEdCess);
	}
	
	function limitTo(field, limit, fieldDesc){
		
		if(field.value > limit){
			if(fieldDesc!=null && fieldDesc!='' && fieldDesc!=undefined){
				addErrorXHTML(null, 'Value of ' + fieldDesc + ' cannot be more than ' + limit,true);
			}
			
			if(limit>0){
				field.value = limit;
			}else{
				field.value = 0;
			}
				
		}
	}
        
        function limitToModified(field, limit, fieldDesc){
		
		if(field.value > limit){
			if(fieldDesc!=null && fieldDesc!='' && fieldDesc!=undefined){
				addErrorXHTML(null, 'Value of ' + fieldDesc + ' cannot be more than ' + limit,true);
			}			
		}
	}
        
        function getDueDate234A(){
    		//var duedate = '31/08/2015';
    		var duedate = '07/09/2015'; // Modified due to the due date extended for filing the return
    		var auditFlag = document.getElementsByName('itr7.partAGEN2.liableSec44ABflg')[0].value;
    		if(auditFlag=='Y'){
    			duedate = "31/10/2015";
    			var tab = document.getElementById('AuditDetails');
    			var inputs = tab.getElementsByTagName('select');
    			for(var i=0;i<inputs.length;i++){
    				if(inputs[i].name.match("auditedSection$")){
    					if(inputs[i].value=="92E"){
    						duedate = "30/11/2015";
    						break;
    					}
    				}
    			}
    		}
        return duedate;
        }
        
        function getDueDate234ACompany(){
    		var duedate = '31/10/2015';
    		var auditFlag = document.getElementsByName('itr7.partAGEN2.liableSec44ABflg')[0].value;
    		if(auditFlag=='Y'){
    			duedate = "31/10/2015";
    			var tab = document.getElementById('AuditDetails');
    			var inputs = tab.getElementsByTagName('select');
    			for(var i=0;i<inputs.length;i++){
    				if(inputs[i].name.match("auditedSection$")){
    					if(inputs[i].value=="92E"){
    						duedate = "30/11/2015";
    						break;
    					}
    				}
    			}
    		}
        return duedate;
        }
        
	
	function calculate234Intrst(advanceTax){
                var status = document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0].value;
                var intrst234ATemp =  document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234A')[0];
                var intrst234BTemp =  document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234B')[0];
                var intrst234CTemp =  document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234C')[0];
                                
                if(status=='3' || status=='4'){
                    calculate234IntrstForCompany(advanceTax);
                    return;
                }
                
        var TCSToDisplay = document.getElementsByName('itr7.partBTTI.taxPaid.taxesPaid.tcs')[0];
		TCSToDisplay.value = coalesce(TCSToDisplay.value);
		var TCS = TCSToDisplay.value;
		
		var TDSToDisplay = document.getElementsByName('itr7.partBTTI.taxPaid.taxesPaid.tds')[0];
		TDSToDisplay.value = coalesce(TDSToDisplay.value);
		var tdsAndTcs = parseInt(TDSToDisplay.value,10)+parseInt(TCS,10);
		
		
		
		var balTaxPayable = document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.netTaxLiability')[0];
		balTaxPayable.value = coalesce(balTaxPayable.value);
		//var balTaxPayable = balTaxPayable.value;
		
		var advanceTax234A = calculateAdvancedTax234A(getDueDate234A());
		
		var intrst234Aprinciple	;
		if(parseInt(balTaxPayable.value ,10) - parseInt(advanceTax ,10) - parseInt(advanceTax234A ,10) - parseInt(tdsAndTcs ,10) < 0){
			intrst234Aprinciple = parseInt('0' ,10);
			}else {
			
			intrst234Aprinciple = parseInt(balTaxPayable.value ,10) - parseInt(advanceTax ,10) - parseInt(advanceTax234A ,10) - parseInt(tdsAndTcs ,10);

			// Rounding off to previous hundered
				if(parseInt(intrst234Aprinciple,10) > 100){
					intrst234Aprinciple= Math.floor(parseInt(intrst234Aprinciple,10)/100)*parseInt('100' ,10);
				}
		}
		var currentDate = document.getElementsByName('itr7.verification.date')[0].value;
		if(isFirstDateBeforeOrEqual(currentDate,getCurDate())) {
			currentDate = getCurDate();
		}
                
                var filingType = document.getElementsByName('itr7.partAGEN1.filingStatus.returnFileSec.incomeTaxSec')[0].value;
                
                var actualDate = currentDate;
                var originalFilingDate = document.getElementsByName('itr7.partAGEN1.filingStatus.origRetFiledDate')[0].value;
                if((filingType=='17'|| filingType=='18') && originalFilingDate !=undefined && originalFilingDate!=null && originalFilingDate!=''){
			currentDate = originalFilingDate;
		}
                
                
		//var duedate = '01/09/2015';
		var duedate = '08/09/2015'; // Modified due to the due date extended for filing the return
		var auditFlag = document.getElementsByName('itr7.partAGEN2.liableSec44ABflg')[0].value;
		if(auditFlag=='Y'){
			duedate = "01/11/2015";
			var tab = document.getElementById('AuditDetails');
			var inputs = tab.getElementsByTagName('select');
			for(var i=0;i<inputs.length;i++){
				if(inputs[i].name.match("auditedSection$")){
					if(inputs[i].value=="92E"){
						duedate = "01/12/2015";
						break;
					}
				}
			}
		}
		var MonthsAfterDueDate =  calcNoOfMonths(currentDate , duedate);
		var intrst234A = parseInt(intrst234Aprinciple,10) * parseFloat('0.01') * parseInt(MonthsAfterDueDate) ;
                var intrst234B = parseInt('0' ,10);
		var	intrst234C = parseInt('0' ,10);

		var slab1 = parseInt('0' ,10);
		var slab2 = parseInt('0' ,10);
		var slab3 = parseInt('0' ,10);

			var tab4 = document.getElementById('scheduleIT');
			var allInputTags = tab4.getElementsByTagName('input');
			for(var i = 0; i < allInputTags.length; i++) {
				if (allInputTags[i].name.match("dateDep$")) {

					if(checkFirstDateBefore('01/04/2014' , allInputTags[i].value) && checkFirstDateBefore( allInputTags[i].value , '15/09/2014' ) ){						
						slab1 = eval(parseInt(slab1 ,10) + parseInt(isNVL(allInputTags[i+2].value) ,10));
					}
					else if(checkFirstDateBefore('16/09/2014' , allInputTags[i].value) && checkFirstDateBefore( allInputTags[i].value , '15/12/2014' ) ){						
						slab2 = eval(parseInt(slab2 ,10) + parseInt(isNVL(allInputTags[i+2].value) ,10));
					}
					else if(checkFirstDateBefore('16/12/2014' , allInputTags[i].value) && checkFirstDateBefore( allInputTags[i].value , '16/03/2015' ) ){						
						slab3 = eval(parseInt(slab3 ,10) + parseInt(isNVL(allInputTags[i+2].value) ,10));
					}
				}
			}


		var intrst234Ci = parseInt('0' ,10);
		var intrst234Cii = parseInt('0' ,10);
		var intrst234Ciii = parseInt('0' ,10);
		var advanceTaxToDisplay = document.getElementsByName('itr7.partBTTI.taxPaid.taxesPaid.advanceTax')[0];  advanceTaxToDisplay.value = coalesce(advanceTaxToDisplay.value);

		var SATtoDisplay = document.getElementsByName('itr7.partBTTI.taxPaid.taxesPaid.selfAssessmentTax')[0];
		SATtoDisplay.value = coalesce(SATtoDisplay.value);


		if(( eval(parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) >=  parseInt('10000',10))){

			if(parseInt(slab1 ,10) < eval((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) * parseFloat('0.3'))){
				var tempintrst234Ci = (((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10) ) * parseFloat('0.30')) - parseInt(slab1 ,10));

				if(parseInt(tempintrst234Ci,10) > 100){
					tempintrst234Ci= Math.floor(parseInt(tempintrst234Ci,10)/100)*parseInt('100' ,10);
				}
				intrst234Ci=parseInt(tempintrst234Ci,10)* parseFloat('0.01') * parseInt('3' ,10) ;

			}
			
			if(eval(parseInt(slab1 ,10) + parseInt(slab2 ,10)) < eval((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) * parseFloat('0.6') )){
				var tempintrst234Cii = (((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) * parseFloat('0.6') ) -parseInt(slab1 ,10) - parseInt(slab2 ,10) );

				if(parseInt(tempintrst234Cii,10) > 100){
					tempintrst234Cii= Math.floor(parseInt(tempintrst234Cii,10)/100)*parseInt('100' ,10);
				}
				intrst234Cii=parseInt(tempintrst234Cii,10)* parseFloat('0.01') * parseInt('3' ,10) ;

			}
			
			if(eval(parseInt(slab1 ,10) + parseInt(slab2 ,10) + parseInt(slab3 ,10)) < eval((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) * parseInt('1' ,10))){
				var tempintrst234Ciii = ((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) - parseInt(slab1 ,10)- parseInt(slab2 ,10) - parseInt(slab3 ,10) );

				if(parseInt(tempintrst234Ciii,10) > 100){
					tempintrst234Ciii= Math.floor(parseInt(tempintrst234Ciii,10)/100)*parseInt('100' ,10);
				}
				intrst234Ciii=parseInt(tempintrst234Ciii,10)* parseFloat('0.01') * parseInt('1' ,10) ;
			}			
		}
		else {
			 intrst234Ci = parseInt('0',10);
			 intrst234Cii = parseInt('0',10);
			 intrst234Ciii = parseInt('0',10);
		}

		intrst234C = eval(parseInt(intrst234Ci ,10) + parseInt(intrst234Cii ,10) + parseInt(intrst234Ciii ,10));

		// ===============Interest234B calculation=======================

		var intrst234Bprinciple;
		var intrst234Bi=parseInt('0',10);
		var earliestSelfAsspaidDate=parseInt('0',10);
		var noOfMonthsTillSelfasst= parseInt('0',10);
		if(parseInt(balTaxPayable.value,10) - parseInt(tdsAndTcs,10) >= parseInt('10000' ,10)) {
			if(parseInt(advanceTax,10) < ((parseInt(balTaxPayable.value,10) - parseInt(tdsAndTcs,10)) * parseFloat('0.90'))) {

				intrst234Bprinciple = (parseInt(balTaxPayable.value ,10) - parseInt(advanceTax ,10) - parseInt(tdsAndTcs,10) );

				// Rounding off to previous hundered
				if(parseInt(intrst234Bprinciple,10) > 100){
					intrst234Bprinciple= Math.floor(parseInt(intrst234Bprinciple,10)/100)*parseInt('100' ,10);
				}

				//======== Interest 234B first part calc==========

				var selfAsspaidDates=new Array();
				var selfAsspaidAmts=new Array();
				var x=parseInt('0',10);
				var tempDate=parseInt('0',10);
				var tempAmt=parseInt('0',10);

				var tab234B = document.getElementById('scheduleIT');
				var allInputTags234B = tab234B.getElementsByTagName('input');
				currentDate = actualDate;

				// to get all self assesment tax values
				for(var p = 0; p < allInputTags.length; p++) {
					if(allInputTags[p].name.match("dateDep$")){
						if( checkFirstDateBefore('01/04/2015' , allInputTags[p].value) && checkFirstDateBefore(allInputTags[p].value, currentDate) ){

							selfAsspaidDates[x]=allInputTags[p].value;
							selfAsspaidAmts[x]=allInputTags[p+2].value;
							x++;
						}
					}
				}

				// to sort all self assesment tax values according to date
				var selfAsspaidDatesSorted=new Array();
				var selfAsspaidAmtsSorted=new Array();

				if(selfAsspaidDates.length > 1){
					for(var q = 0; q < selfAsspaidDates.length-1; q++) {
						for(var r = q+1; r < selfAsspaidDates.length; r++) {
							if(checkFirstDateBefore(selfAsspaidDates[q], selfAsspaidDates[r])){

							}else{
								tempDate=selfAsspaidDates[q];
								tempAmt=selfAsspaidAmts[q];

								selfAsspaidDates[q]=selfAsspaidDates[r];
								selfAsspaidAmts[q]=selfAsspaidAmts[r];

								selfAsspaidDates[r]=tempDate;
								selfAsspaidAmts[r]=tempAmt;
							}
						}
					}
					var arrLen = selfAsspaidDates.length;
					var lastMonth = 0;
					var lastIndex = -1;
					for(var q = 0; q < arrLen; q++) {
						if(parseInt(selfAsspaidDates[q].substr(3,2), 10) == lastMonth){
							selfAsspaidAmts[lastIndex] = parseInt(selfAsspaidAmts[lastIndex], 10) + parseInt(selfAsspaidAmts[q], 10);
						}else{
							lastMonth = parseInt(selfAsspaidDates[q].substr(3,2), 10);
							selfAsspaidAmts[++lastIndex] = selfAsspaidAmts[q];
							selfAsspaidDates[lastIndex] = selfAsspaidDates[q];
						}
					}
					selfAsspaidAmts.length = ++lastIndex;
					selfAsspaidDates.length = lastIndex;
				}

				if(selfAsspaidDates.length==0){
					noOfMonthsTillSelfasst=calcNoOfMonths(currentDate,'01/04/2015');
				}else{
					noOfMonthsTillSelfasst=calcNoOfMonths(selfAsspaidDates[0],'01/04/2015');
				}

				intrst234Bi= parseInt(intrst234Bprinciple,10) * parseFloat('0.01') * parseInt(noOfMonthsTillSelfasst) ;



				//======== Interest 234B second part calc==========
				var intrst234Bprinciple2=parseInt('0',10);  // intrst234Bprinciple if self assesment is paid
				var selfAsspart=parseInt('0',10);
				var noOfMonthsTillSelfasst2;
				var intrst234Bii=parseInt('0',10);
				var partialSelfAssPaid=parseInt('0',10);
				var k=parseInt('0',10);
				var interestFrom;
				var interestTill;

				if(selfAsspaidDates.length!=0){
					
					for(var i = 0; i < selfAsspaidDates.length; i++) {
						partialSelfAssPaid= eval(parseInt(partialSelfAssPaid ,10) +parseInt(selfAsspaidAmts[i] ,10));

						intrst234Bprinciple2=zeroOrMore(eval(parseInt(balTaxPayable.value ,10) - parseInt(advanceTax ,10) - parseInt(tdsAndTcs,10) +
								parseInt(intrst234A ,10)+parseInt(intrst234C ,10)+parseInt(intrst234Bi ,10)+parseInt(intrst234Bii ,10)
								-parseInt(partialSelfAssPaid,10)));

						// Rounding off to previous hundered
						if(parseInt(intrst234Bprinciple2,10) > parseInt('100' ,10)){
							intrst234Bprinciple2= Math.floor(parseInt(intrst234Bprinciple2,10)/100)*parseInt('100' ,10);
						}
						//calclulating remaining months to levy interest

						interestTill=currentDate;
						interestFrom=selfAsspaidDates[i];

						if(i != eval(selfAsspaidDates.length-parseInt('1' ,10))){

								for(k=i;k < eval(selfAsspaidDates.length-parseInt('1' ,10)); k++){
									if(selfAsspaidDates[k]!=selfAsspaidDates[k+1]){
										interestTill=selfAsspaidDates[k+1];
										interestFrom=selfAsspaidDates[k];
										k=selfAsspaidDates.length;
									}
								}
						}
						
						noOfMonthsTillSelfasst2=calcNoOfMonths(interestTill,interestFrom)-parseInt('1' ,10) ;

						if(parseInt(intrst234Bprinciple2,10) < parseInt(intrst234Bprinciple,10)){								
							intrst234Bii= eval(parseInt(intrst234Bii,10) +
								(parseInt(intrst234Bprinciple2,10) * parseFloat('0.01') * parseInt(noOfMonthsTillSelfasst2))) ;
						}else{
							intrst234Bii= eval(parseInt(intrst234Bii,10) +
								(parseInt(intrst234Bprinciple,10) * parseFloat('0.01') * parseInt(noOfMonthsTillSelfasst2))) ;
						}					
					}
				}

				intrst234B=eval(parseInt(intrst234Bi,10) +parseInt(intrst234Bii,10));
			}
		}else{
			intrst234B = parseInt('0' ,10);
		} 
                
        if(intrst234ATemp.old !=  intrst234A){
        	intrst234ATemp.old = intrst234A;
        	intrst234ATemp.value = intrst234A;	
    	}
        if(intrst234BTemp.old !=  intrst234B){
        	intrst234BTemp.old = intrst234B;
        	intrst234BTemp.value = intrst234B;	
    	}
        if(intrst234CTemp.old !=  intrst234C){
        	intrst234CTemp.old = intrst234C;
        	intrst234CTemp.value = intrst234C;	
    	}
		

	}
	
        
	function calculate234IntrstForCompany(advanceTax){
		
		 var intrst234ATemp =  document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234A')[0];
         var intrst234BTemp =  document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234B')[0];
         var intrst234CTemp =  document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.intrstPay.intrstPayUs234C')[0];
         
		 var TCSToDisplay = document.getElementsByName('itr7.partBTTI.taxPaid.taxesPaid.tcs')[0];
		TCSToDisplay.value = coalesce(TCSToDisplay.value);
		var TCS = TCSToDisplay.value;
		
		var TDSToDisplay = document.getElementsByName('itr7.partBTTI.taxPaid.taxesPaid.tds')[0];
		TDSToDisplay.value = coalesce(TDSToDisplay.value);
		var tdsAndTcs = parseInt(TDSToDisplay.value,10)+parseInt(TCS,10);
		
		var balTaxPayable = document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.netTaxLiability')[0];
		balTaxPayable.value = coalesce(balTaxPayable.value);
		//var balTaxPayable = balTaxPayable.value;
		
		var advanceTax234A = calculateAdvancedTax234A(getDueDate234ACompany());
		
		var intrst234Aprinciple	;
		if(parseInt(balTaxPayable.value ,10) - parseInt(advanceTax ,10)- parseInt(advanceTax234A ,10) - parseInt(tdsAndTcs ,10) < 0){
			intrst234Aprinciple = parseInt('0' ,10);
			}else {
			
			intrst234Aprinciple = parseInt(balTaxPayable.value ,10) - parseInt(advanceTax ,10) - parseInt(advanceTax234A ,10) - parseInt(tdsAndTcs ,10);

			// Rounding off to previous hundered
				if(parseInt(intrst234Aprinciple,10) > 100){
					intrst234Aprinciple= Math.floor(parseInt(intrst234Aprinciple,10)/100)*parseInt('100' ,10);
				}
		}
		var currentDate = document.getElementsByName('itr7.verification.date')[0].value;		
		if(isFirstDateBeforeOrEqual(currentDate,getCurDate())) {
			currentDate = getCurDate();
		}
                var filingType = document.getElementsByName('itr7.partAGEN1.filingStatus.returnFileSec.incomeTaxSec')[0].value;
                
                var actualDate = currentDate;
                var originalFilingDate = document.getElementsByName('itr7.partAGEN1.filingStatus.origRetFiledDate')[0].value;
                if(filingType=='17' && originalFilingDate !=undefined && originalFilingDate!=null && originalFilingDate!=''){
			currentDate = originalFilingDate;
		}
		var duedate = '01/11/2015';
		var auditFlag = document.getElementsByName('itr7.partAGEN2.liableSec44ABflg')[0].value;
		if(auditFlag=='Y'){
			var tab = document.getElementById('AuditDetails');
			var inputs = tab.getElementsByTagName('select');
			for(var i=0;i<inputs.length;i++){
				if(inputs[i].name.match("auditedSection$")){
					if(inputs[i].value=="92E"){
						duedate = "01/12/2015";
						break;
					}
				}
			}
		}
		var MonthsAfterDueDate =  calcNoOfMonths(currentDate , duedate);
		var intrst234A = parseInt(intrst234Aprinciple,10) * parseFloat('0.01') * parseInt(MonthsAfterDueDate) ;
                var intrst234B = parseInt('0' ,10);
		var	intrst234C = parseInt('0' ,10);

		var slab1 = parseInt('0' ,10);
		var slab2 = parseInt('0' ,10);
		var slab3 = parseInt('0' ,10);
		var slab4 = parseInt('0' ,10);

			var tab4 = document.getElementById('scheduleIT');
			var allInputTags = tab4.getElementsByTagName('input');
			for(var i = 0; i < allInputTags.length; i++) {
				if (allInputTags[i].name.match("dateDep$")) {
                                        if(checkFirstDateBefore('01/04/2014' , allInputTags[i].value) && checkFirstDateBefore( allInputTags[i].value , '16/06/2014' ) ){						
						slab1 = eval(parseInt(slab1 ,10) + parseInt(isNVL(allInputTags[i+2].value) ,10));
					}
					if(checkFirstDateBefore('17/06/2014' , allInputTags[i].value) && checkFirstDateBefore( allInputTags[i].value , '15/09/2014' ) ){						
						slab2 = eval(parseInt(slab2 ,10) + parseInt(isNVL(allInputTags[i+2].value) ,10));
					}
					else if(checkFirstDateBefore('16/09/2014' , allInputTags[i].value) && checkFirstDateBefore( allInputTags[i].value , '15/12/2014' ) ){						
						slab3 = eval(parseInt(slab3 ,10) + parseInt(isNVL(allInputTags[i+2].value) ,10));
					}
					else if(checkFirstDateBefore('16/12/2014' , allInputTags[i].value) && checkFirstDateBefore( allInputTags[i].value , '16/03/2015' ) ){						
						slab4 = eval(parseInt(slab4 ,10) + parseInt(isNVL(allInputTags[i+2].value) ,10));
					}
				}
			}

                
		var intrst234Ci = parseInt('0' ,10);
		var intrst234Cii = parseInt('0' ,10);
		var intrst234Ciii = parseInt('0' ,10);
		var intrst234Civ = parseInt('0' ,10);
		var advanceTaxToDisplay = document.getElementsByName('itr7.partBTTI.taxPaid.taxesPaid.advanceTax')[0];  advanceTaxToDisplay.value = coalesce(advanceTaxToDisplay.value);

		var SATtoDisplay = document.getElementsByName('itr7.partBTTI.taxPaid.taxesPaid.selfAssessmentTax')[0];
		SATtoDisplay.value = coalesce(SATtoDisplay.value);


		if(( eval(parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) >=  parseInt('10000',10))){

                        

			if(parseInt(slab1 ,10) < eval((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) * parseFloat('0.12'))){
				var tempintrst234Ci = (((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10) ) * parseFloat('0.15')) - parseInt(slab1 ,10));

				if(parseInt(tempintrst234Ci,10) > 100){
					tempintrst234Ci= Math.floor(parseInt(tempintrst234Ci,10)/100)*parseInt('100' ,10);
				}
				intrst234Ci=parseInt(tempintrst234Ci,10)* parseFloat('0.01') * parseInt('3' ,10) ;
                                   
			}
			
			if(eval(parseInt(slab1 ,10) + parseInt(slab2 ,10)) < eval((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) * parseFloat('0.36') )){
				var tempintrst234Cii = (((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) * parseFloat('0.45') ) -parseInt(slab1 ,10) - parseInt(slab2 ,10) );

				if(parseInt(tempintrst234Cii,10) > 100){
					tempintrst234Cii= Math.floor(parseInt(tempintrst234Cii,10)/100)*parseInt('100' ,10);
				}
				intrst234Cii=parseInt(tempintrst234Cii,10)* parseFloat('0.01') * parseInt('3' ,10) ;

			}
			
			
			if(eval(parseInt(slab1 ,10) + parseInt(slab2 ,10) + parseInt(slab3 ,10)) < eval((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) * parseFloat('0.75' ,10))){
				var tempintrst234Ciii = (((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) * parseFloat('0.75')) - parseInt(slab1 ,10)- parseInt(slab2 ,10) - parseInt(slab3 ,10) );
				
				if(parseInt(tempintrst234Ciii,10) > 100){
					tempintrst234Ciii= Math.floor(parseInt(tempintrst234Ciii,10)/100)*parseInt('100' ,10);
				}
				intrst234Ciii=parseInt(tempintrst234Ciii,10)* parseFloat('0.01') * parseInt('3' ,10) ;
			}
			
			if(eval(parseInt(slab1 ,10) + parseInt(slab2 ,10) + parseInt(slab3 ,10) +  parseInt(slab4 ,10)) < eval((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) * parseInt('1' ,10))){
				var tempintrst234Civ = ((parseInt(balTaxPayable.value ,10) - parseInt(tdsAndTcs ,10)) - parseInt(slab1 ,10)- parseInt(slab2 ,10) - parseInt(slab3 ,10) - parseInt(slab4 ,10) );
				if(parseInt(tempintrst234Civ,10) > 100){
					tempintrst234Civ= Math.floor(parseInt(tempintrst234Civ,10)/100)*parseInt('100' ,10);
				}
				intrst234Civ=parseInt(tempintrst234Civ,10)* parseFloat('0.01') * parseInt('1' ,10) ;
			}
			
		}
		else {
			 intrst234Ci = parseInt('0',10);
			 intrst234Cii = parseInt('0',10);
			 intrst234Ciii = parseInt('0',10);
			 intrst234Civ = parseInt('0',10);
		}
		intrst234C = eval(parseInt(intrst234Ci ,10) + parseInt(intrst234Cii ,10) + parseInt(intrst234Ciii ,10) + parseInt(intrst234Civ ,10));

		// ===============Interest234B calculation=======================

		var intrst234Bprinciple;
		var intrst234Bi=parseInt('0',10);
		var noOfMonthsTillSelfasst= parseInt('0',10);
		if(parseInt(balTaxPayable.value,10) - parseInt(tdsAndTcs,10) >= parseInt('10000' ,10)) {
			if(parseInt(advanceTax,10) < ((parseInt(balTaxPayable.value,10) - parseInt(tdsAndTcs,10)) * parseFloat('0.90'))) {

				intrst234Bprinciple = (parseInt(balTaxPayable.value ,10) - parseInt(advanceTax ,10) - parseInt(tdsAndTcs,10) );

				// Rounding off to previous hundered
				if(parseInt(intrst234Bprinciple,10) > 100){
					intrst234Bprinciple= Math.floor(parseInt(intrst234Bprinciple,10)/100)*parseInt('100' ,10);
				}

				//======== Interest 234B first part calc==========

				var selfAsspaidDates=new Array();
				var selfAsspaidAmts=new Array();
				var x=parseInt('0',10);
				var tempDate=parseInt('0',10);
				var tempAmt=parseInt('0',10);

				var tab234B = document.getElementById('scheduleIT');
				currentDate = actualDate;

				// to get all self assesment tax values
				for(var p = 0; p < allInputTags.length; p++) {
					if(allInputTags[p].name.match("dateDep$")){
						if( checkFirstDateBefore('01/04/2015' , allInputTags[p].value) && checkFirstDateBefore(allInputTags[p].value, currentDate) ){

							selfAsspaidDates[x]=allInputTags[p].value;
							selfAsspaidAmts[x]=allInputTags[p+2].value;
							x++;
						}
					}
				}

				// to sort all self assesment tax values according to date

				if(selfAsspaidDates.length > 1){
					for(var q = 0; q < selfAsspaidDates.length-1; q++) {
						for(var r = q+1; r < selfAsspaidDates.length; r++) {
							if(checkFirstDateBefore(selfAsspaidDates[q], selfAsspaidDates[r])){

							}else{
								tempDate=selfAsspaidDates[q];
								tempAmt=selfAsspaidAmts[q];

								selfAsspaidDates[q]=selfAsspaidDates[r];
								selfAsspaidAmts[q]=selfAsspaidAmts[r];

								selfAsspaidDates[r]=tempDate;
								selfAsspaidAmts[r]=tempAmt;
							}
						}
					}
				}

				if(selfAsspaidDates.length==0){
					noOfMonthsTillSelfasst=calcNoOfMonths(currentDate,'01/04/2015');
				}else{
					noOfMonthsTillSelfasst=calcNoOfMonths(selfAsspaidDates[0],'01/04/2015');
				}

				intrst234Bi= parseInt(intrst234Bprinciple,10) * parseFloat('0.01') * parseInt(noOfMonthsTillSelfasst) ;



				//======== Interest 234B second part calc==========
				var intrst234Bprinciple2=parseInt('0',10);  // intrst234Bprinciple if self assesment is paid

				var noOfMonthsTillSelfasst2;
				var intrst234Bii=parseInt('0',10);
				var partialSelfAssPaid=parseInt('0',10);
				var k=parseInt('0',10);
				var interestFrom;
				var interestTill;

				if(selfAsspaidDates.length!=0){
					
					for(var i = 0; i < selfAsspaidDates.length; i++) {
						partialSelfAssPaid= eval(parseInt(partialSelfAssPaid ,10) +parseInt(selfAsspaidAmts[i] ,10));

						intrst234Bprinciple2=zeroOrMore(eval(parseInt(balTaxPayable.value ,10) - parseInt(advanceTax ,10) - parseInt(tdsAndTcs,10) +
								parseInt(intrst234A ,10)+parseInt(intrst234C ,10)+parseInt(intrst234Bi ,10)+parseInt(intrst234Bii ,10)
								-parseInt(partialSelfAssPaid,10)));

						// Rounding off to previous hundered
						if(parseInt(intrst234Bprinciple2,10) > parseInt('100' ,10)){
							intrst234Bprinciple2= Math.floor(parseInt(intrst234Bprinciple2,10)/100)*parseInt('100' ,10);
						}
						//calclulating remaining months to levy interest

						interestTill=currentDate;
						interestFrom=selfAsspaidDates[i];

						if(i != eval(selfAsspaidDates.length-parseInt('1' ,10))){

								for(k=i;k < eval(selfAsspaidDates.length-parseInt('1' ,10)); k++){
									if(selfAsspaidDates[k]!=selfAsspaidDates[k+1]){
										interestTill=selfAsspaidDates[k+1];
										interestFrom=selfAsspaidDates[k];
										k=selfAsspaidDates.length;
									}
								}
						}
						
						noOfMonthsTillSelfasst2=calcNoOfMonths(interestTill,interestFrom)-parseInt('1' ,10) ;
						if(parseInt(intrst234Bprinciple2,10) < parseInt(intrst234Bprinciple,10)){								
							intrst234Bii= eval(parseInt(intrst234Bii,10) +
								(parseInt(intrst234Bprinciple2,10) * parseFloat('0.01') * parseInt(noOfMonthsTillSelfasst2))) ;
						}else{
							intrst234Bii= eval(parseInt(intrst234Bii,10) +
								(parseInt(intrst234Bprinciple,10) * parseFloat('0.01') * parseInt(noOfMonthsTillSelfasst2))) ;
						}					
					}
				}
				intrst234B=eval(parseInt(intrst234Bi,10) +parseInt(intrst234Bii,10));
			}
		}else{
			intrst234B = parseInt('0' ,10);
		} 
                
		
                if(intrst234ATemp.old !=  intrst234A){
                	intrst234ATemp.old = intrst234A;
                	intrst234ATemp.value = intrst234A;	
            	}
                if(intrst234BTemp.old !=  intrst234B){
                	intrst234BTemp.old = intrst234B;
                	intrst234BTemp.value = intrst234B;	
            	}
                if(intrst234CTemp.old !=  intrst234C){
                	intrst234CTemp.old = intrst234C;
                	intrst234CTemp.value = intrst234C;	
            	}
		

	}
        
        

function calcSchBPBalance() {
var profBfrTaxPL = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.profBfrTaxPL')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.profBfrTaxPL');
var netPLFromSpecBus = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.netPLFromSpecBus')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLFromSpecBus');
var netProfLossSpecifiedBus = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.netProfLossSpecifiedBus')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netProfLossSpecifiedBus');
var plUs44SChapXIIG = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.plUs44SChapXIIG')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.plUs44SChapXIIG');
var firmShareInc = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.incCredPL.firmShareInc')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.incCredPL.firmShareInc');
var aopboiSharInc = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.incCredPL.aopboiSharInc')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.incCredPL.aopboiSharInc');
var othExempInc = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.incCredPL.othExempInc')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.incCredPL.othExempInc');
var totExempInc = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.incCredPL.totExempInc')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.incCredPL.totExempInc');

var balancePLOthThanSpecBus = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.balancePLOthThanSpecBus')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.balancePLOthThanSpecBus');

var expDebToPLOthHeads = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.expDebToPLOthHeads')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.expDebToPLOthHeads');
var expDebToPLExemptInc = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.expDebToPLExemptInc')[0];  coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.expDebToPLExemptInc');
var totExpDebPL = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.totExpDebPL')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.totExpDebPL');

var adjustedPLOthThanSpecBus = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.adjustedPLOthThanSpecBus')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.adjustedPLOthThanSpecBus');

var deemIncUs3380HHD80IA = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.deemIncUs3380HHD80IA')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.deemIncUs3380HHD80IA');
var othItemDisallowUs28To44DA = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.othItemDisallowUs28To44DA')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.othItemDisallowUs28To44DA');
var anyOthIncNotInclInExpDisallowPL = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.anyOthIncNotInclInExpDisallowPL')[0];  coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.anyOthIncNotInclInExpDisallowPL');
var totAfterAddToPLDeprOthSpecInc =  document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.totAfterAddToPLDeprOthSpecInc')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.totAfterAddToPLDeprOthSpecInc');

var deductUs321Iii =  document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.deductUs321Iii')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.deductUs321Iii');
var anyOthAmtAllDeduct = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.anyOthAmtAllDeduct')[0];  coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.anyOthAmtAllDeduct');
var totDeductionAmts =  document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.totDeductionAmts')[0];  coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.totDeductionAmts');

var plAftAdjDedBusOthThanSpec =  document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.plAftAdjDedBusOthThanSpec')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.plAftAdjDedBusOthThanSpec');

var section44AD = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.deemedProfitBusUs.section44AD')[0];  coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.deemedProfitBusUs.section44AD');
var section44AE = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.deemedProfitBusUs.section44AE')[0];  coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.deemedProfitBusUs.section44AE');
var totDeemedProfitBusUs = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.deemedProfitBusUs.totDeemedProfitBusUs')[0];   coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.deemedProfitBusUs.totDeemedProfitBusUs');

//var profitLossBfrDeductUs10S = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.profitLossBfrDeductUs10S')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.profitLossBfrDeductUs10S');
//
//var section10A =  document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.deductionUs10S.section10A')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.deductionUs10S.section10A');
//var section10AA = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.deductionUs10S.section10AA')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.deductionUs10S.section10AA');
//var totDeductionUs10S = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.deductionUs10S.totDeductionUs10S')[0]; coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.deductionUs10S.totDeductionUs10S');

var netPLAftAdjBusOthThanSpec =  document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.netPLAftAdjBusOthThanSpec')[0];   coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLAftAdjBusOthThanSpec');

var netPLBusOthThanSpec7A7B7CI = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7CI')[0];   coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7CI');
var netPLBusOthThanSpec7A7B7C = document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7C')[0];   coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7C');

var netPLFrmSpecBus = document.getElementsByName('itr7.corpScheduleBP.specBusinessInc.netPLFrmSpecBus')[0]; coalesceSetRet('itr7.corpScheduleBP.specBusinessInc.netPLFrmSpecBus');
var additionUs28To44DA = document.getElementsByName('itr7.corpScheduleBP.specBusinessInc.additionUs28To44DA')[0]; coalesceSetRet('itr7.corpScheduleBP.specBusinessInc.additionUs28To44DA');
var deductUs28To44DA = document.getElementsByName('itr7.corpScheduleBP.specBusinessInc.deductUs28To44DA')[0];  coalesceSetRet('itr7.corpScheduleBP.specBusinessInc.deductUs28To44DA');
var adjustedPLFrmSpecuBus = document.getElementsByName('itr7.corpScheduleBP.specBusinessInc.adjustedPLFrmSpecuBus')[0];  coalesceSetRet('itr7.corpScheduleBP.specBusinessInc.adjustedPLFrmSpecuBus');

var netPLFrmSpecifiedBus = document.getElementsByName('itr7.corpScheduleBP.incSpecifiedBusiness.netPLFrmSpecifiedBus')[0];  coalesceSetRet('itr7.corpScheduleBP.incSpecifiedBusiness.netPLFrmSpecifiedBus');
var addSec28To44DA = document.getElementsByName('itr7.corpScheduleBP.incSpecifiedBusiness.addSec28To44DA')[0]; coalesceSetRet('itr7.corpScheduleBP.incSpecifiedBusiness.addSec28To44DA');
var dedSec28To44DAOTDedSec35AD = document.getElementsByName('itr7.corpScheduleBP.incSpecifiedBusiness.dedSec28To44DAOTDedSec35AD')[0];  coalesceSetRet('itr7.corpScheduleBP.incSpecifiedBusiness.dedSec28To44DAOTDedSec35AD');
var profitLossSpecifiedBusiness = document.getElementsByName('itr7.corpScheduleBP.incSpecifiedBusiness.profitLossSpecifiedBusiness')[0]; coalesceSetRet('itr7.corpScheduleBP.incSpecifiedBusiness.profitLossSpecifiedBusiness');

var dedSec35AD = document.getElementsByName('itr7.corpScheduleBP.incSpecifiedBusiness.dedSec35AD')[0]; coalesceSetRet('itr7.corpScheduleBP.incSpecifiedBusiness.dedSec35AD');
var profitLossSpecifiedBusFinal = document.getElementsByName('itr7.corpScheduleBP.incSpecifiedBusiness.profitLossSpecifiedBusFinal')[0]; coalesceSetRet('itr7.corpScheduleBP.incSpecifiedBusiness.profitLossSpecifiedBusFinal');

var incChrgUnHdProftGain = document.getElementsByName('itr7.corpScheduleBP.incChrgUnHdProftGain')[0]; coalesceSetRet('itr7.corpScheduleBP.incChrgUnHdProftGain');
var incAsAccOfBusUndertaking = document.getElementsByName('itr7.corpScheduleBP.chargeableUs11.incAsAccOfBusUndertaking')[0]; coalesceSetRet('itr7.corpScheduleBP.chargeableUs11.incAsAccOfBusUndertaking');
var incChargeableUs11 = document.getElementsByName('itr7.corpScheduleBP.chargeableUs11.incChargeableUs11')[0]; coalesceSetRet('itr7.corpScheduleBP.chargeableUs11.incChargeableUs11');


totExempInc.value = eval(parseInt(coalesce(firmShareInc.value) ,10)) + eval(parseInt(coalesce(aopboiSharInc.value) ,10)) + eval(parseInt(coalesce(othExempInc.value),10));

var totExpDebPLTemp =  eval(parseInt(coalesce(expDebToPLOthHeads.value) ,10)) + eval(parseInt(coalesce(expDebToPLExemptInc.value) ,10));
if( parseInt(totExpDebPLTemp ,10) >0 ){
		totExpDebPL.value = totExpDebPLTemp;
	}else{
		totExpDebPL.value = parseInt(0,10);
	}


var totDeductionAmtsTemp = eval(parseInt(coalesce(deductUs321Iii.value) ,10)) + eval(parseInt(coalesce(anyOthAmtAllDeduct.value) ,10));
if( parseInt(totDeductionAmtsTemp ,10) >0 ){
		totDeductionAmts.value = totDeductionAmtsTemp;
	}else{
		totDeductionAmts.value = parseInt(0,10);
	}

var totDeemedProfitBusUsTemp = eval(parseInt(coalesce(section44AD.value) ,10)) + eval(parseInt(coalesce(section44AE.value) ,10));
if( parseInt(totDeemedProfitBusUsTemp ,10) >0 ){
		totDeemedProfitBusUs.value = totDeemedProfitBusUsTemp;
	}else{
		totDeemedProfitBusUs.value = parseInt(0,10);
	}
plUs44SChapXIIG.value = coalesce(totDeemedProfitBusUs.value);
//var totDeductionUs10STemp = eval(parseInt(coalesce(section10A.value) ,10)) + eval(parseInt(coalesce(section10AA.value) ,10));
//if( parseInt(totDeductionUs10STemp ,10) >0 ){
//		totDeductionUs10S.value = totDeductionUs10STemp;
//	}else{
//		totDeductionUs10S.value = parseInt(0,10);
//	}
netPLFrmSpecBus.value = coalesce(netPLFromSpecBus.value);
var adjustedPLFrmSpecuBusTemp = eval(parseInt(coalesce(netPLFrmSpecBus.value) ,10)) + eval(parseInt(coalesce(additionUs28To44DA.value) ,10)) - eval(parseInt(coalesce(deductUs28To44DA.value) ,10));

if( parseInt(adjustedPLFrmSpecuBusTemp ,10) >0 ){
	adjustedPLFrmSpecuBus.value = adjustedPLFrmSpecuBusTemp;
}else{
	adjustedPLFrmSpecuBus.value = parseInt(0,10);
}
netPLFrmSpecifiedBus.value = coalesce(netProfLossSpecifiedBus.value);
profitLossSpecifiedBusiness.value = eval(parseInt(coalesce(netPLFrmSpecifiedBus.value) ,10)) + eval(parseInt(coalesce(addSec28To44DA.value) ,10)) - eval(parseInt(coalesce(dedSec28To44DAOTDedSec35AD.value) ,10));

var profitLossSpecifiedBusFinalTemp = eval(parseInt(coalesce(profitLossSpecifiedBusiness.value) ,10)) - eval(parseInt(coalesce(dedSec35AD.value) ,10));

if( parseInt(profitLossSpecifiedBusFinalTemp ,10) >0 ){
	profitLossSpecifiedBusFinal.value = profitLossSpecifiedBusFinalTemp;
}else{
	profitLossSpecifiedBusFinal.value = parseInt(0,10);
}
	
	
	
        balancePLOthThanSpecBus.value = eval(parseInt(coalesce(profBfrTaxPL.value) ,10)) - eval(parseInt(coalesce(netPLFromSpecBus.value) ,10)) - eval(parseInt(coalesce(netProfLossSpecifiedBus.value),10)) - eval(parseInt(coalesce(plUs44SChapXIIG.value),10)) - eval(parseInt(coalesce(totExempInc.value),10));
        adjustedPLOthThanSpecBus.value = eval(parseInt(coalesce(balancePLOthThanSpecBus.value) ,10)) + eval(parseInt(coalesce(totExpDebPL.value) ,10));
        

        var totAfterAddToPLDeprOthSpecIncTemp = eval(parseInt(coalesce(adjustedPLOthThanSpecBus.value) ,10)) + eval(parseInt(coalesce(deemIncUs3380HHD80IA.value) ,10)) + eval(parseInt(coalesce(othItemDisallowUs28To44DA.value) ,10)) + eval(parseInt(coalesce(anyOthIncNotInclInExpDisallowPL.value) ,10));

		totAfterAddToPLDeprOthSpecInc.value = totAfterAddToPLDeprOthSpecIncTemp;

        
        var plAftAdjDedBusOthThanSpecTemp = eval(parseInt(coalesce(totAfterAddToPLDeprOthSpecInc.value) ,10)) - eval(parseInt(coalesce(totDeductionAmts.value) ,10));

		plAftAdjDedBusOthThanSpec.value = plAftAdjDedBusOthThanSpecTemp;
        
//        var profitLossBfrDeductUs10STemp = eval(parseInt(coalesce(plAftAdjDedBusOthThanSpec.value) ,10)) + eval(parseInt(coalesce(totDeemedProfitBusUs.value) ,10));
//		profitLossBfrDeductUs10S.value = profitLossBfrDeductUs10STemp;
          var netPLAftAdjBusOthThanSpecTemp = eval(parseInt(coalesce(plAftAdjDedBusOthThanSpec.value) ,10)) + eval(parseInt(coalesce(totDeemedProfitBusUs.value) ,10));
		netPLAftAdjBusOthThanSpec.value = netPLAftAdjBusOthThanSpecTemp;
    
       if($('[name="itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7C"]')[0].flag!='Y' ) {
           netPLBusOthThanSpec7A7B7C.value = coalesce(netPLAftAdjBusOthThanSpec.value);
        }
        
       
   	coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7CI');		
	if(coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLAftAdjBusOthThanSpec')<0 && 
		coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7CI')==0){
		
		document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7C')[0].value = 
			coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLAftAdjBusOthThanSpec');
			
	}else if((coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLAftAdjBusOthThanSpec')<0 && 
		coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7CI')!=0) ||
		(coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLAftAdjBusOthThanSpec')>=0)){
		
		if(	coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7CI') > 
				coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLAftAdjBusOthThanSpec')){
				
			document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7C')[0].value = 
				coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7CI');
				
		}else{
		
			document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7C')[0].value = 
				coalesceSetRet('itr7.corpScheduleBP.businessIncOthThanSpec.netPLAftAdjBusOthThanSpec');
		}
		
	}
       
       
        
        incChrgUnHdProftGain.value = eval(parseInt(coalesce(netPLBusOthThanSpec7A7B7C.value) ,10)) + eval(parseInt(coalesce(adjustedPLFrmSpecuBus.value) ,10)) + eval(parseInt(coalesce(profitLossSpecifiedBusFinal.value) ,10));

        var incChargeableUs11Temp =  eval(parseInt(coalesce(incChrgUnHdProftGain.value) ,10)) - eval(parseInt(coalesce(incAsAccOfBusUndertaking.value) ,10));
        if( parseInt(incChargeableUs11Temp ,10) >0 ){
		incChargeableUs11.value = incChargeableUs11Temp;
	}else{
		incChargeableUs11.value = parseInt(0,10);
	}
        
	changeCYLA();
        calculateTiTti();
}



function calcTaxPayableSchMAT() {

var profAfterTaxPLAcnt = document.getElementsByName('itr7.scheduleMAT.profAfterTaxPLAcnt')[0];  
var itPaidInclDefTax = document.getElementsByName('itr7.scheduleMAT.additions.itPaidInclDefTax')[0]; 
var resvrNo33AC = document.getElementsByName('itr7.scheduleMAT.additions.resvrNo33AC')[0]; 
var provUncertainLiab = document.getElementsByName('itr7.scheduleMAT.additions.provUncertainLiab')[0]; 
var provLossOfSubsComp = document.getElementsByName('itr7.scheduleMAT.additions.provLossOfSubsComp')[0];
var dividendPaidOrProposed = document.getElementsByName('itr7.scheduleMAT.additions.dividendPaidOrProposed')[0];  
var expendExempIncUs10S = document.getElementsByName('itr7.scheduleMAT.additions.expendExempIncUs10S')[0]; 
var depreciatAttribToRevalAsset = document.getElementsByName('itr7.scheduleMAT.additions.depreciatAttribToRevalAsset')[0]; 
var others =  document.getElementsByName('itr7.scheduleMAT.additions.others')[0];  
var totAdditions = document.getElementsByName('itr7.scheduleMAT.additions.totAdditions')[0]; 
var amtWithdrawFromResvrIfCredPL = document.getElementsByName('itr7.scheduleMAT.deducts.amtWithdrawFromResvrIfCredPL')[0]; 
var incExempIncUs10S = document.getElementsByName('itr7.scheduleMAT.deducts.incExempIncUs10S')[0]; 
var amtWithdrawFromResvrIfCredPLNoAttrib = document.getElementsByName('itr7.scheduleMAT.deducts.amtWithdrawFromResvrIfCredPLNoAttrib')[0]; 
var unAbsorbedDepreciat = document.getElementsByName('itr7.scheduleMAT.deducts.unAbsorbedDepreciat')[0]; 
var proSickIndustryOrExcedAccumLos = document.getElementsByName('itr7.scheduleMAT.deducts.proSickIndustryOrExcedAccumLos')[0]; 
var deductsOthers = document.getElementsByName('itr7.scheduleMAT.deducts.others')[0]; 
var totDeducts = document.getElementsByName('itr7.scheduleMAT.deducts.totDeducts')[0];  

var bookProfUs115JB = document.getElementsByName('itr7.scheduleMAT.bookProfUs115JB')[0]; bookProfUs115JB.value = coalesce(bookProfUs115JB.value);

var taxPayableUs115JB = document.getElementsByName('itr7.scheduleMAT.taxPayableUs115JB')[0]; taxPayableUs115JB.value = coalesce(taxPayableUs115JB.value);

var totAdditionsTemp =  eval(parseInt(coalesce(itPaidInclDefTax.value) ,10)) + eval(parseInt(coalesce(resvrNo33AC.value) ,10)) + eval(parseInt(coalesce(provUncertainLiab.value) ,10)) +
								eval(parseInt(coalesce(provLossOfSubsComp.value) ,10)) + eval(parseInt(coalesce(dividendPaidOrProposed.value) ,10)) + 
										eval(parseInt(coalesce(expendExempIncUs10S.value) ,10)) + eval(parseInt(coalesce(depreciatAttribToRevalAsset.value) ,10)) + eval(parseInt(coalesce(others.value) ,10));
if( parseInt(coalesce(totAdditionsTemp) ,10) >0 ){
		totAdditions.value = totAdditionsTemp;
	}else{
		totAdditions.value = parseInt(0,10);
	}

var totDeductsTemp =  eval(parseInt(coalesce(amtWithdrawFromResvrIfCredPL.value) ,10)) + eval(parseInt(coalesce(incExempIncUs10S.value) ,10)) + eval(parseInt(coalesce(amtWithdrawFromResvrIfCredPLNoAttrib.value) ,10)) + eval(parseInt(coalesce(unAbsorbedDepreciat.value) ,10)) + eval(parseInt(coalesce(proSickIndustryOrExcedAccumLos.value) ,10)) + eval(parseInt(coalesce(deductsOthers.value) ,10));
if( parseInt(coalesce(totDeductsTemp) ,10) >0 ){
		totDeducts.value = totDeductsTemp;
	}else{
		totDeducts.value = parseInt(0,10);
	}
bookProfUs115JB.value = eval(parseInt(coalesce(profAfterTaxPLAcnt.value) ,10)) + eval(parseInt(coalesce(totAdditions.value) ,10)) - eval(parseInt(coalesce(totDeducts.value) ,10));

	if (bookProfUs115JB.value > 0) {
		var taxPayableUs115JBTemp = Math.round((18.5 * eval(parseInt(
				bookProfUs115JB.value, 10))) / 100);
		if (parseInt(taxPayableUs115JBTemp, 10) > 0) {
			taxPayableUs115JB.value = taxPayableUs115JBTemp;
		} else {
			taxPayableUs115JB.value = parseInt(0, 10);
		}
	} else {
            taxPayableUs115JB.value = parseInt(0, 10);
        }
     calculateTiTti();
}

function changeCYLA(called) {

	var hpIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.houseProperty.incCYLA.incOfCurYrUnderThatHead')[0]; hpIncOfCurYrUnderThatHead.value = coalesce(hpIncOfCurYrUnderThatHead.value);
	var hpBusLossSetoff = document.getElementsByName('itr7.scheduleCYLA.houseProperty.incCYLA.busLossSetoff')[0];  hpBusLossSetoff.value = coalesce(hpBusLossSetoff.value);
	var hpOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.houseProperty.incCYLA.othSrcLossNoRaceHorseSetoff')[0]; hpOthSrcLossNoRaceHorseSetoff.value = coalesce(hpOthSrcLossNoRaceHorseSetoff.value);
	var hpIncOfCurYrAfterSetOff = document.getElementsByName('itr7.scheduleCYLA.houseProperty.incCYLA.incOfCurYrAfterSetOff')[0]; hpIncOfCurYrAfterSetOff.value = coalesce(hpIncOfCurYrAfterSetOff.value);
	var busIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.busProfInclSpecProf.incCYLA.incOfCurYrUnderThatHead')[0]; busIncOfCurYrUnderThatHead.value = coalesce(busIncOfCurYrUnderThatHead.value);
	var busHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.busProfInclSpecProf.incCYLA.hPlossCurYrSetoff')[0]; busHPlossCurYrSetoff.value = coalesce(busHPlossCurYrSetoff.value);
	var busOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.busProfInclSpecProf.incCYLA.othSrcLossNoRaceHorseSetoff')[0]; busOthSrcLossNoRaceHorseSetoff.value = coalesce(busOthSrcLossNoRaceHorseSetoff.value);
	var busIncOfCurYrAfterSetOff = document.getElementsByName('itr7.scheduleCYLA.busProfInclSpecProf.incCYLA.incOfCurYrAfterSetOff')[0]; busIncOfCurYrAfterSetOff.value = coalesce(busIncOfCurYrAfterSetOff.value);
	var specltvIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.speculativeInc.incCYLA.incOfCurYrUnderThatHead')[0]; specltvIncOfCurYrUnderThatHead.value = coalesce(specltvIncOfCurYrUnderThatHead.value);
	var specltvHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.speculativeInc.incCYLA.hPlossCurYrSetoff')[0]; specltvHPlossCurYrSetoff.value = coalesce(specltvHPlossCurYrSetoff.value);	
	var specltvOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.speculativeInc.incCYLA.othSrcLossNoRaceHorseSetoff')[0]; specltvOthSrcLossNoRaceHorseSetoff.value = coalesce(specltvOthSrcLossNoRaceHorseSetoff.value);
	var specltvIncOfCurYrAfterSetOff = document.getElementsByName('itr7.scheduleCYLA.speculativeInc.incCYLA.incOfCurYrAfterSetOff')[0]; specltvIncOfCurYrAfterSetOff.value = coalesce(specltvIncOfCurYrAfterSetOff.value);
	var specfidIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.specifiedInc.incCYLA.incOfCurYrUnderThatHead')[0]; specfidIncOfCurYrUnderThatHead.value = coalesce(specfidIncOfCurYrUnderThatHead.value);
	var specfidHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.specifiedInc.incCYLA.hPlossCurYrSetoff')[0]; specfidHPlossCurYrSetoff.value = coalesce(specfidHPlossCurYrSetoff.value);	
	var specfidOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.specifiedInc.incCYLA.othSrcLossNoRaceHorseSetoff')[0]; specfidOthSrcLossNoRaceHorseSetoff.value = coalesce(specfidOthSrcLossNoRaceHorseSetoff.value);
	var specfidIncOfCurYrAfterSetOff = document.getElementsByName('itr7.scheduleCYLA.specifiedInc.incCYLA.incOfCurYrAfterSetOff')[0]; specfidIncOfCurYrAfterSetOff.value = coalesce(specfidIncOfCurYrAfterSetOff.value);
	var stcgIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.stcg.incCYLA.incOfCurYrUnderThatHead')[0]; stcgIncOfCurYrUnderThatHead.value = coalesce(stcgIncOfCurYrUnderThatHead.value);
	var stcgHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.stcg.incCYLA.hPlossCurYrSetoff')[0]; stcgHPlossCurYrSetoff.value = coalesce(stcgHPlossCurYrSetoff.value);
	var stcgBusLossSetoff = document.getElementsByName('itr7.scheduleCYLA.stcg.incCYLA.busLossSetoff')[0]; stcgBusLossSetoff.value = coalesce(stcgBusLossSetoff.value);
	var stcgOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.stcg.incCYLA.othSrcLossNoRaceHorseSetoff')[0]; stcgOthSrcLossNoRaceHorseSetoff.value = coalesce(stcgOthSrcLossNoRaceHorseSetoff.value);
	var stcgIncOfCurYrAfterSetOff  = document.getElementsByName('itr7.scheduleCYLA.stcg.incCYLA.incOfCurYrAfterSetOff')[0]; stcgIncOfCurYrAfterSetOff.value = coalesce(stcgIncOfCurYrAfterSetOff.value);
	var ltcgIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.ltcg.incCYLA.incOfCurYrUnderThatHead')[0]; ltcgIncOfCurYrUnderThatHead.value = coalesce(ltcgIncOfCurYrUnderThatHead.value);
	var ltcgHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.ltcg.incCYLA.hPlossCurYrSetoff')[0]; ltcgHPlossCurYrSetoff.value = coalesce(ltcgHPlossCurYrSetoff.value);
	var ltcgBusLossSetoff = document.getElementsByName('itr7.scheduleCYLA.ltcg.incCYLA.busLossSetoff')[0]; ltcgBusLossSetoff.value = coalesce(ltcgBusLossSetoff.value);
	var ltcgOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.ltcg.incCYLA.othSrcLossNoRaceHorseSetoff')[0];  ltcgOthSrcLossNoRaceHorseSetoff.value = coalesce(ltcgOthSrcLossNoRaceHorseSetoff.value);
	var ltcgIncOfCurYrAfterSetOff = document.getElementsByName('itr7.scheduleCYLA.ltcg.incCYLA.incOfCurYrAfterSetOff')[0]; ltcgIncOfCurYrAfterSetOff.value = coalesce(ltcgIncOfCurYrAfterSetOff.value);
	var othSrcIncOfCurYrUnderThatHead  = document.getElementsByName('itr7.scheduleCYLA.othSrcInclRaceHorse.incCYLA.incOfCurYrUnderThatHead')[0]; othSrcIncOfCurYrUnderThatHead.value = coalesce(othSrcIncOfCurYrUnderThatHead.value);
	var othSrcHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.othSrcInclRaceHorse.incCYLA.hPlossCurYrSetoff')[0]; othSrcHPlossCurYrSetoff.value = coalesce(othSrcHPlossCurYrSetoff.value);
	var othSrcBusLossSetoff = document.getElementsByName('itr7.scheduleCYLA.othSrcInclRaceHorse.incCYLA.busLossSetoff')[0]; othSrcBusLossSetoff.value = coalesce(othSrcBusLossSetoff.value);
	var othSrcIncOfCurYrAfterSetOff= document.getElementsByName('itr7.scheduleCYLA.othSrcInclRaceHorse.incCYLA.incOfCurYrAfterSetOff')[0];  othSrcIncOfCurYrAfterSetOff.value = coalesce(othSrcIncOfCurYrAfterSetOff.value);
	var profitFrmRaceHorseIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.profitFrmRaceHorse.incCYLA.incOfCurYrUnderThatHead')[0]; profitFrmRaceHorseIncOfCurYrUnderThatHead.value = coalesce(profitFrmRaceHorseIncOfCurYrUnderThatHead.value);
	var profitFrmRaceHorseHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.profitFrmRaceHorse.incCYLA.hPlossCurYrSetoff')[0]; profitFrmRaceHorseHPlossCurYrSetoff.value = coalesce(profitFrmRaceHorseHPlossCurYrSetoff.value);
	var profitFrmRaceHorseBusLossSetoff= document.getElementsByName('itr7.scheduleCYLA.profitFrmRaceHorse.incCYLA.busLossSetoff')[0]; profitFrmRaceHorseBusLossSetoff.value = coalesce(profitFrmRaceHorseBusLossSetoff.value);
	var profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff= document.getElementsByName('itr7.scheduleCYLA.profitFrmRaceHorse.incCYLA.othSrcLossNoRaceHorseSetoff')[0]; profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value = coalesce(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value);
	var profitFrmRaceHorseIncOfCurYrAfterSetOff = document.getElementsByName('itr7.scheduleCYLA.profitFrmRaceHorse.incCYLA.incOfCurYrAfterSetOff')[0]; profitFrmRaceHorseIncOfCurYrAfterSetOff.value = coalesce(profitFrmRaceHorseIncOfCurYrAfterSetOff.value);
	var totHPlossCurYrSetoff =  document.getElementsByName('itr7.scheduleCYLA.totalLossSetOff.totHPlossCurYrSetoff')[0]; totHPlossCurYrSetoff.value = coalesce(totHPlossCurYrSetoff.value);
	var totBusLossSetoff = document.getElementsByName('itr7.scheduleCYLA.totalLossSetOff.totBusLossSetoff')[0]; totBusLossSetoff.value = coalesce(totBusLossSetoff.value);
	var totOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.totalLossSetOff.totOthSrcLossNoRaceHorseSetoff')[0]; totOthSrcLossNoRaceHorseSetoff.value = coalesce(totOthSrcLossNoRaceHorseSetoff.value);
	var balHPlossCurYrAftSetoff = document.getElementsByName('itr7.scheduleCYLA.lossRemAftSetOff.balHPlossCurYrAftSetoff')[0]; balHPlossCurYrAftSetoff.value = coalesce(balHPlossCurYrAftSetoff.value);
	var balBusLossAftSetoff = document.getElementsByName('itr7.scheduleCYLA.lossRemAftSetOff.balBusLossAftSetoff')[0]; balBusLossAftSetoff.value = coalesce(balBusLossAftSetoff.value);
	var balOthSrcLossNoRaceHorseAftSetoff = document.getElementsByName('itr7.scheduleCYLA.lossRemAftSetOff.balOthSrcLossNoRaceHorseAftSetoff')[0]; balOthSrcLossNoRaceHorseAftSetoff.value = coalesce(balOthSrcLossNoRaceHorseAftSetoff.value);
	var balSCG = document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset.balSCG')[0]; balSCG.value = coalesce(balSCG.value);

	var totalIncomeChargeableUnHP = document.getElementsByName('itr7.scheduleHP.totalIncomeChargeableUnHP')[0];


	var totHPlossCurYr = document.getElementsByName('itr7.scheduleCYLA.totalCurYr.totHPlossCurYr')[0]; 
	totHPlossCurYr.value = coalesce(totHPlossCurYr.value);
	var totBusLoss = document.getElementsByName('itr7.scheduleCYLA.totalCurYr.totBusLoss')[0];
	totBusLoss.value = coalesce(totBusLoss.value);
	
	var totOthSrcLossNoRaceHorse = document.getElementsByName('itr7.scheduleCYLA.totalCurYr.totOthSrcLossNoRaceHorse')[0];
	totOthSrcLossNoRaceHorse.value = coalesce(totOthSrcLossNoRaceHorse.value);

	var totalIncomeChargeableUnHP=document.getElementsByName('itr7.scheduleHP.totalIncomeChargeableUnHP')[0];
	totalIncomeChargeableUnHP.value = coalesce(totalIncomeChargeableUnHP.value);
	var netPLBusOthThanSpec7A7B7C=document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7C')[0];
	netPLBusOthThanSpec7A7B7C.value = coalesce(netPLBusOthThanSpec7A7B7C.value);
	var balanceNoRaceHorse=document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.balanceNoRaceHorse')[0];
	balanceNoRaceHorse.value = coalesce(balanceNoRaceHorse.value);
	var totalSTCG=document.getElementsByName('itr7.scheduleCG.shortTermCapGain.totalSTCG')[0];
	totalSTCG.value = coalesce(totalSTCG.value);
	var totalLTCG=document.getElementsByName('itr7.scheduleCG.longTermCapGain.totalLTCG')[0];
	totalLTCG.value = coalesce(totalLTCG.value);
	var adjustedPLFrmSpecuBus=document.getElementsByName('itr7.corpScheduleBP.specBusinessInc.adjustedPLFrmSpecuBus')[0];
	adjustedPLFrmSpecuBus.value = coalesce(adjustedPLFrmSpecuBus.value);
	var profitLossSpecifiedBusFinal=document.getElementsByName('itr7.corpScheduleBP.incSpecifiedBusiness.profitLossSpecifiedBusFinal')[0];
	profitLossSpecifiedBusFinal.value = coalesce(profitLossSpecifiedBusFinal.value);
	var balanceOwnRaceHorse=document.getElementsByName('itr7.scheduleOS.incFromOwnHorse.balanceOwnRaceHorse')[0];
	balanceOwnRaceHorse.value = coalesce(balanceOwnRaceHorse.value);

	var deemedSTCGDeprAsset=document.getElementsByName('itr7.scheduleCG.shortTermCapGain.deemedSTCGDeprAsset')[0];
	deemedSTCGDeprAsset.value = coalesce(deemedSTCGDeprAsset.value);
	var exemptionUs111A=document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0];
	exemptionUs111A.value = coalesce(exemptionUs111A.value);

	var balLTCGNo112=document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.balLTCGNo112')[0];
	balLTCGNo112.value = coalesce(balLTCGNo112.value);
	var balCG=document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.balCG')[0];
	balCG.value = coalesce(balCG.value);
	var balLTCG112=document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.balLTCG112')[0];
	balLTCG112.value = coalesce(balLTCG112.value);
	var A2eA3A4Remain = 0;
	var B1eRemain = 0;
	var A1eRemain = 0;
	var B2eRemain = 0;
	A2eA3A4Remain= eval(balSCG.value)+eval(deemedSTCGDeprAsset.value)-eval(exemptionUs111A.value);
	B1eRemain=balLTCGNo112.value;
	A1eRemain=balCG.value;
	B2eRemain=balLTCG112.value;
	
	if(totalSTCG.value < 0) {
		var tmp = totalSTCG.value;
		if(B1eRemain>0){
			B1eRemain = eval(parseInt(B1eRemain,10) + parseInt(tmp,10));
			tmp = zeroOrLess(B1eRemain);
			B1eRemain = zeroOrMore(B1eRemain);
		}
		if(tmp < 0 && B2eRemain>0){
			B2eRemain = eval(parseInt(B2eRemain,10) + parseInt(tmp,10));
			B2eRemain = zeroOrMore(B2eRemain);
		}
	}
	        hpIncOfCurYrUnderThatHead.value=0;
	        totHPlossCurYr.value=0;
	        busIncOfCurYrUnderThatHead.value=0;
	        totBusLoss.value=0;
	        othSrcIncOfCurYrUnderThatHead.value=0;
	        totOthSrcLossNoRaceHorse.value=0;
	        specfidIncOfCurYrUnderThatHead.value=0;
	        stcgIncOfCurYrUnderThatHead.value=0;
	        ltcgIncOfCurYrUnderThatHead.value=0;
	        profitFrmRaceHorseIncOfCurYrUnderThatHead.value=0;
	        specltvIncOfCurYrUnderThatHead.value=0;

			if(eval(totalIncomeChargeableUnHP.value) >= 0){

				hpIncOfCurYrUnderThatHead.value=totalIncomeChargeableUnHP.value;
				totHPlossCurYr.value=0;

			}else{

				totHPlossCurYr.value=Math.abs(totalIncomeChargeableUnHP.value);
				hpIncOfCurYrUnderThatHead.value=0;

			}
						

			if(eval(balanceNoRaceHorse.value) >= 0){

				othSrcIncOfCurYrUnderThatHead.value=balanceNoRaceHorse.value;
				totOthSrcLossNoRaceHorse.value=0;

			}else{

				totOthSrcLossNoRaceHorse.value=Math.abs(balanceNoRaceHorse.value);
				othSrcIncOfCurYrUnderThatHead.value=0;

			}
			
			if(eval(profitLossSpecifiedBusFinal.value)>=0){
				var netPLBusOthThanSpec7A7B7Ctemp;
				if(eval(netPLBusOthThanSpec7A7B7C.value)<0){
					netPLBusOthThanSpec7A7B7Ctemp = eval(profitLossSpecifiedBusFinal.value) + eval(netPLBusOthThanSpec7A7B7C.value);					
				} else {
					netPLBusOthThanSpec7A7B7Ctemp= eval(profitLossSpecifiedBusFinal.value);
				}
				if(eval(netPLBusOthThanSpec7A7B7Ctemp)>=0){
					specfidIncOfCurYrUnderThatHead.value=netPLBusOthThanSpec7A7B7Ctemp;
				}
			
			}
			
			if(eval(adjustedPLFrmSpecuBus.value)>=0){
			var adjustedPLFrmSpecuBusTemp;
				if(eval(netPLBusOthThanSpec7A7B7Ctemp)<0){
					adjustedPLFrmSpecuBusTemp = eval(adjustedPLFrmSpecuBus.value) + eval(netPLBusOthThanSpec7A7B7Ctemp);
				} else {
					adjustedPLFrmSpecuBusTemp= eval(adjustedPLFrmSpecuBus.value);
				}
				if(eval(adjustedPLFrmSpecuBusTemp)>=0){			
					specltvIncOfCurYrUnderThatHead.value=adjustedPLFrmSpecuBusTemp;
					adjustedPLFrmSpecuBusTemp=0;
				}
			
			}
			
			if(netPLBusOthThanSpec7A7B7C.value>=0) {
				busIncOfCurYrUnderThatHead.value=netPLBusOthThanSpec7A7B7C.value;
				totBusLoss.value=0;
			}else{
				totBusLoss.value=Math.abs(adjustedPLFrmSpecuBusTemp);
				busIncOfCurYrUnderThatHead.value=0;

			}
						
			
			if(eval(totalSTCG.value)>=0){
			
				stcgIncOfCurYrUnderThatHead.value=totalSTCG.value;
			
			}
			if(eval(totalSTCG.value)<0 ){
			
				if(eval(totalLTCG.value)+eval(totalSTCG.value)>0){
				
					ltcgIncOfCurYrUnderThatHead.value=eval(totalLTCG.value)+eval(totalSTCG.value);
				}
			
			}else{
			
				ltcgIncOfCurYrUnderThatHead.value=totalLTCG.value;
			
			}
			
			if(eval(ltcgIncOfCurYrUnderThatHead.value)<0){
				
				ltcgIncOfCurYrUnderThatHead.value=0;
			}
			
			if(eval(balanceOwnRaceHorse.value)>=0){
			
				profitFrmRaceHorseIncOfCurYrUnderThatHead.value=balanceOwnRaceHorse.value;
			
			}
			
			hpOthSrcLossNoRaceHorseSetoff.value=0;
			busOthSrcLossNoRaceHorseSetoff.value=0;
			specltvOthSrcLossNoRaceHorseSetoff.value=0;
			specfidOthSrcLossNoRaceHorseSetoff.value=0;
			stcgOthSrcLossNoRaceHorseSetoff.value=0;
			ltcgOthSrcLossNoRaceHorseSetoff.value=0;
			profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value=0;
			
			hpBusLossSetoff.value=0;						
			stcgBusLossSetoff.value=0;
			ltcgBusLossSetoff.value=0;
			othSrcBusLossSetoff.value=0;
			profitFrmRaceHorseBusLossSetoff.value=0;
			
			busHPlossCurYrSetoff.value=0;
			specltvHPlossCurYrSetoff.value=0;
			specfidHPlossCurYrSetoff.value=0;
			stcgHPlossCurYrSetoff.value=0;
			ltcgHPlossCurYrSetoff.value=0;
			othSrcHPlossCurYrSetoff.value=0;
			profitFrmRaceHorseHPlossCurYrSetoff.value=0;
			
			if(eval(totOthSrcLossNoRaceHorse.value)>0){

				var osLossToBeAdjusted=totOthSrcLossNoRaceHorse.value;
			
				eval(profitFrmRaceHorseIncOfCurYrUnderThatHead.value) >=eval(osLossToBeAdjusted) ? 
				(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value=osLossToBeAdjusted) : 
				(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value=profitFrmRaceHorseIncOfCurYrUnderThatHead.value) 
			
				osLossToBeAdjusted=eval(osLossToBeAdjusted)-eval(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value);
				
				if(eval(osLossToBeAdjusted)>0){
				
					eval(hpIncOfCurYrUnderThatHead.value) >=eval(osLossToBeAdjusted) ? 
					(hpOthSrcLossNoRaceHorseSetoff.value=osLossToBeAdjusted) :
					(hpOthSrcLossNoRaceHorseSetoff.value=hpIncOfCurYrUnderThatHead.value);
				
					osLossToBeAdjusted=eval(osLossToBeAdjusted)-eval(hpOthSrcLossNoRaceHorseSetoff.value);
					
					if(eval(osLossToBeAdjusted)>0){
					
						eval(busIncOfCurYrUnderThatHead.value) >=eval(osLossToBeAdjusted) ? 
						(busOthSrcLossNoRaceHorseSetoff.value=osLossToBeAdjusted) :
						(busOthSrcLossNoRaceHorseSetoff.value=busIncOfCurYrUnderThatHead.value);
						
						osLossToBeAdjusted=eval(osLossToBeAdjusted)-eval(busOthSrcLossNoRaceHorseSetoff.value);
					
						if(eval(osLossToBeAdjusted)>0){
					
							eval(specltvIncOfCurYrUnderThatHead.value) >=eval(osLossToBeAdjusted) ? 
							(specltvOthSrcLossNoRaceHorseSetoff.value=osLossToBeAdjusted) :
							(specltvOthSrcLossNoRaceHorseSetoff.value=specltvIncOfCurYrUnderThatHead.value);
							
							osLossToBeAdjusted=eval(osLossToBeAdjusted)-eval(specltvOthSrcLossNoRaceHorseSetoff.value);
							
							if(eval(osLossToBeAdjusted)>0){
							
								eval(specfidIncOfCurYrUnderThatHead.value) >=eval(osLossToBeAdjusted) ? 
								(specfidOthSrcLossNoRaceHorseSetoff.value=osLossToBeAdjusted) :
								(specfidOthSrcLossNoRaceHorseSetoff.value=specfidIncOfCurYrUnderThatHead.value);
							
								osLossToBeAdjusted=eval(osLossToBeAdjusted)-eval(specfidOthSrcLossNoRaceHorseSetoff.value);
								
								if(eval(osLossToBeAdjusted)>0){
								
									if(stcgIncOfCurYrUnderThatHead.value>0){
									
										if(eval(A2eA3A4Remain) <= eval(osLossToBeAdjusted)){
										
											stcgOthSrcLossNoRaceHorseSetoff.value=A2eA3A4Remain;
											A2eA3A4Remain = 0;
											
										}else{										
											stcgOthSrcLossNoRaceHorseSetoff.value=osLossToBeAdjusted;
											A2eA3A4Remain = eval(parseInt(A2eA3A4Remain,10) - parseInt(stcgOthSrcLossNoRaceHorseSetoff.value,10));
										}
										osLossToBeAdjusted=eval(osLossToBeAdjusted)-eval(stcgOthSrcLossNoRaceHorseSetoff.value);										
									}
									
									
									if(eval(osLossToBeAdjusted) > 0){
									
										if(ltcgIncOfCurYrUnderThatHead.value>0){											
											if(eval(B1eRemain)<=eval(osLossToBeAdjusted)){
											
												ltcgOthSrcLossNoRaceHorseSetoff.value=B1eRemain;
												B1eRemain = 0;
											}else{
											
												ltcgOthSrcLossNoRaceHorseSetoff.value=osLossToBeAdjusted;
												B1eRemain = parseInt(B1eRemain,10) - parseInt(ltcgOthSrcLossNoRaceHorseSetoff.value,10);
											}
										osLossToBeAdjusted=eval(osLossToBeAdjusted)-eval(ltcgOthSrcLossNoRaceHorseSetoff.value);										
										}
									
										
										
										if(eval(osLossToBeAdjusted)>0){
													
											if((eval(stcgIncOfCurYrUnderThatHead.value)-eval(stcgOthSrcLossNoRaceHorseSetoff.value))>0){
													
												if(eval(balCG.value) <= eval(osLossToBeAdjusted)){
												
													stcgOthSrcLossNoRaceHorseSetoff.value = eval(stcgOthSrcLossNoRaceHorseSetoff.value)+eval(balCG.value);
													osLossToBeAdjusted=eval(osLossToBeAdjusted)-eval(balCG.value);
													A1eRemain = 0;
												}else{
												
													stcgOthSrcLossNoRaceHorseSetoff.value = eval(stcgOthSrcLossNoRaceHorseSetoff.value)+eval(osLossToBeAdjusted);
													A1eRemain =  parseInt(balCG.value,10) - parseInt(osLossToBeAdjusted,10);
													osLossToBeAdjusted=0;
													
												}												
											}	
											
											
											
											if(eval(osLossToBeAdjusted) > 0){
											
												if((ltcgIncOfCurYrUnderThatHead.value-ltcgOthSrcLossNoRaceHorseSetoff.value)>0){
											
													if(eval(balLTCG112.value)<=eval(osLossToBeAdjusted)){
													
														ltcgOthSrcLossNoRaceHorseSetoff.value=eval(ltcgOthSrcLossNoRaceHorseSetoff.value)+eval(balLTCG112.value);
														osLossToBeAdjusted=eval(osLossToBeAdjusted)-eval(balLTCG112.value);
														B2eRemain = 0;
													}else{
													
														ltcgOthSrcLossNoRaceHorseSetoff.value=eval(ltcgOthSrcLossNoRaceHorseSetoff.value)+eval(osLossToBeAdjusted);
														B2eRemain = parseInt(balLTCG112.value,10) - parseInt(osLossToBeAdjusted,10);
														osLossToBeAdjusted=0;														
													}													
												}
				
												
						
											}
											
										}
				
									}
									
								}

							}
		
						}
					
					}
				
				}
				
			}
		
			if(eval(totBusLoss.value)>0){
						
						var busLossToBeAdjusted=totBusLoss.value;
									
							if(eval(busLossToBeAdjusted)>0){
					
								(eval(hpIncOfCurYrUnderThatHead.value)-eval(hpOthSrcLossNoRaceHorseSetoff.value)) >=eval(busLossToBeAdjusted) ? 
								(hpBusLossSetoff.value =busLossToBeAdjusted) :
								(hpBusLossSetoff.value =(eval(hpIncOfCurYrUnderThatHead.value)-eval(hpOthSrcLossNoRaceHorseSetoff.value)));
			
								busLossToBeAdjusted=eval(busLossToBeAdjusted)-eval(hpBusLossSetoff.value );
								
								if(eval(busLossToBeAdjusted)>0){
						
									eval(othSrcIncOfCurYrUnderThatHead.value) >=eval(busLossToBeAdjusted) ? 
									(othSrcBusLossSetoff.value=busLossToBeAdjusted) :
									(othSrcBusLossSetoff.value=othSrcIncOfCurYrUnderThatHead.value);
							
									busLossToBeAdjusted=eval(busLossToBeAdjusted)-eval(othSrcBusLossSetoff.value);
									
									if(eval(busLossToBeAdjusted)>0){
									
										(eval(profitFrmRaceHorseIncOfCurYrUnderThatHead.value)-eval(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value)) >=busLossToBeAdjusted ? 
										(profitFrmRaceHorseBusLossSetoff.value=busLossToBeAdjusted) : 
										(profitFrmRaceHorseBusLossSetoff.value=(eval(profitFrmRaceHorseIncOfCurYrUnderThatHead.value)-eval(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value)));
										busLossToBeAdjusted=eval(busLossToBeAdjusted)-eval(profitFrmRaceHorseBusLossSetoff.value);
										
										if(eval(busLossToBeAdjusted)>0){
		
											//var tempStcg= eval(balSCG.value)+eval(deemedSTCGDeprAsset.value)-eval(exemptionUs111A.value);
											var setOffRemain = eval(parseInt(stcgIncOfCurYrUnderThatHead.value,10)-parseInt(stcgOthSrcLossNoRaceHorseSetoff.value,10));
											
											if(parseInt(setOffRemain,10) >0 && parseInt(A2eA3A4Remain,10)>0){
												
												if(eval(A2eA3A4Remain) <= eval(busLossToBeAdjusted)){
												
													stcgBusLossSetoff.value=A2eA3A4Remain;
													A2eA3A4Remain=0;
													
												}else{
												
													stcgBusLossSetoff.value=eval(busLossToBeAdjusted);
													A2eA3A4Remain=eval(parseInt(A2eA3A4Remain,10) - parseInt(busLossToBeAdjusted,10));
												}
											busLossToBeAdjusted=eval(busLossToBeAdjusted)-eval(stcgBusLossSetoff.value);
											
											}
											
											
											if(eval(busLossToBeAdjusted) > 0){
											
												if((eval(ltcgIncOfCurYrUnderThatHead.value)-eval(ltcgOthSrcLossNoRaceHorseSetoff.value))>0){
												
													if(eval(B1eRemain)<=eval(busLossToBeAdjusted)){
													
														ltcgBusLossSetoff.value=eval(B1eRemain);
														B1eRemain = 0;
													
													}else{
													
														//ltcgBusLossSetoff.value=eval(busLossToBeAdjusted)-eval(ltcgOthSrcLossNoRaceHorseSetoff.value);
														ltcgBusLossSetoff.value=eval(busLossToBeAdjusted);
														B1eRemain = eval(B1eRemain)-eval(ltcgBusLossSetoff.value);
													
													}
												busLossToBeAdjusted=eval(busLossToBeAdjusted)-eval(ltcgBusLossSetoff.value);
												}
											
												
												
												if(eval(busLossToBeAdjusted)>0){
															
													if((eval(stcgIncOfCurYrUnderThatHead.value)-eval(stcgBusLossSetoff.value)-eval(stcgOthSrcLossNoRaceHorseSetoff.value))>0){
															
														if(eval(A1eRemain)<= eval(busLossToBeAdjusted)){
														
															stcgBusLossSetoff.value = eval(stcgBusLossSetoff.value)+eval(A1eRemain);
															busLossToBeAdjusted=eval(busLossToBeAdjusted)-eval(A1eRemain);
															A1eRemain = 0;
														}else{
														
															stcgBusLossSetoff.value = eval(stcgBusLossSetoff.value)+eval(busLossToBeAdjusted);
															A1eRemain = eval(A1eRemain) - eval(busLossToBeAdjusted);
															busLossToBeAdjusted=0;															
														}
														
													}	
													
													
													
													if(eval(busLossToBeAdjusted) > 0){
													
														if((eval(ltcgIncOfCurYrUnderThatHead.value)-eval(ltcgBusLossSetoff.value-ltcgOthSrcLossNoRaceHorseSetoff.value))>0){
													
															if(eval(B2eRemain)<=eval(busLossToBeAdjusted)){
															
																ltcgBusLossSetoff.value=eval(ltcgBusLossSetoff.value)+eval(B2eRemain);
																busLossToBeAdjusted=eval(busLossToBeAdjusted)-eval(B2eRemain);
																B2eRemain = 0;
															}else{
															
																ltcgBusLossSetoff.value=eval(ltcgBusLossSetoff.value)+eval(busLossToBeAdjusted);
																B2eRemain = eval(B2eRemain) - eval(busLossToBeAdjusted);
																busLossToBeAdjusted=0;																
															}
														}
						
														
								
													}
													
												}
						
											}

										
										}
										
									
									}
								
								}
							
							
							}
			
			}
			
			if(eval(totHPlossCurYr.value)>0){
			
				var hpLossToBeAdjusted=totHPlossCurYr.value;
			
				(eval(busIncOfCurYrUnderThatHead.value)- eval(busOthSrcLossNoRaceHorseSetoff.value))>=eval(hpLossToBeAdjusted) ? 
				(busHPlossCurYrSetoff.value=hpLossToBeAdjusted) :
				(busHPlossCurYrSetoff.value=(eval(busIncOfCurYrUnderThatHead.value)- eval(busOthSrcLossNoRaceHorseSetoff.value)));
				hpLossToBeAdjusted=eval(hpLossToBeAdjusted)-eval(busHPlossCurYrSetoff.value);	
				
				if(eval(hpLossToBeAdjusted)>0){
								
					(eval(specltvIncOfCurYrUnderThatHead.value)-eval(specltvOthSrcLossNoRaceHorseSetoff.value)) >=hpLossToBeAdjusted ? 
					(specltvHPlossCurYrSetoff.value=hpLossToBeAdjusted) :
					(specltvHPlossCurYrSetoff.value=(eval(specltvIncOfCurYrUnderThatHead.value)-eval(specltvOthSrcLossNoRaceHorseSetoff.value)));
							
					hpLossToBeAdjusted=eval(hpLossToBeAdjusted)-eval(specltvHPlossCurYrSetoff.value);
					
					if(eval(hpLossToBeAdjusted)>0){
					
						(eval(specfidIncOfCurYrUnderThatHead.value)-eval(specfidOthSrcLossNoRaceHorseSetoff.value)) >=eval(hpLossToBeAdjusted) ? 
						(specfidHPlossCurYrSetoff.value=hpLossToBeAdjusted) :
						(specfidHPlossCurYrSetoff.value=(eval(specfidIncOfCurYrUnderThatHead.value)-eval(specfidOthSrcLossNoRaceHorseSetoff.value)));
							
						hpLossToBeAdjusted=eval(hpLossToBeAdjusted)-eval(specfidHPlossCurYrSetoff.value);
						
						if(eval(hpLossToBeAdjusted)>0){
						
							(eval(othSrcIncOfCurYrUnderThatHead.value)-eval(othSrcBusLossSetoff.value)) >=eval(hpLossToBeAdjusted) ? 
							(othSrcHPlossCurYrSetoff.value=hpLossToBeAdjusted) :
							(othSrcHPlossCurYrSetoff.value=(eval(othSrcIncOfCurYrUnderThatHead.value)-eval(othSrcBusLossSetoff.value)));
							
							hpLossToBeAdjusted=eval(hpLossToBeAdjusted)-eval(othSrcHPlossCurYrSetoff.value);
														
							if(eval(hpLossToBeAdjusted)>0){
						
								(eval(profitFrmRaceHorseIncOfCurYrUnderThatHead.value)-eval(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value) -eval(profitFrmRaceHorseBusLossSetoff.value)) >=hpLossToBeAdjusted ? 
								(profitFrmRaceHorseHPlossCurYrSetoff.value=hpLossToBeAdjusted) : 
								(profitFrmRaceHorseHPlossCurYrSetoff.value=(eval(profitFrmRaceHorseIncOfCurYrUnderThatHead.value)-eval(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value)-eval(profitFrmRaceHorseBusLossSetoff.value)));
								
								hpLossToBeAdjusted=eval(hpLossToBeAdjusted)-eval(profitFrmRaceHorseHPlossCurYrSetoff.value);
								
								if(eval(hpLossToBeAdjusted)>0){
				
											//var tempStcg= eval(balSCG.value)+eval(deemedSTCGDeprAsset.value)-eval(exemptionUs111A.value);
											var setOffRemainSTCG  = eval(stcgIncOfCurYrUnderThatHead.value)-eval(stcgOthSrcLossNoRaceHorseSetoff.value)-eval(stcgBusLossSetoff.value);
											
											if(parseInt(setOffRemainSTCG,10) >0 && parseInt(A2eA3A4Remain,10)>0){
												if(eval(A2eA3A4Remain)<= eval(hpLossToBeAdjusted)){
												
													stcgHPlossCurYrSetoff.value=A2eA3A4Remain;
													A2eA3A4Remain=0;
													
												}else{
												
													stcgHPlossCurYrSetoff.value=eval(hpLossToBeAdjusted);
													A2eA3A4Remain=eval(parseInt(A2eA3A4Remain,10) - parseInt(hpLossToBeAdjusted,10));
												}
												hpLossToBeAdjusted=eval(hpLossToBeAdjusted)-eval(stcgHPlossCurYrSetoff.value);
																																				
											}
																						
											if(eval(hpLossToBeAdjusted) > 0){
											
												if((eval(ltcgIncOfCurYrUnderThatHead.value)-eval(ltcgOthSrcLossNoRaceHorseSetoff.value)-eval(ltcgBusLossSetoff.value))>0){
													
													if(eval(B1eRemain)<=eval(hpLossToBeAdjusted)){
													
														//ltcgHPlossCurYrSetoff.value=eval(balLTCGNo112.value)-eval(ltcgOthSrcLossNoRaceHorseSetoff.value)-eval(ltcgBusLossSetoff.value);
														ltcgHPlossCurYrSetoff.value=eval(B1eRemain);
														B1eRemain = 0;
													
													}else{
													
														//ltcgHPlossCurYrSetoff.value=eval(hpLossToBeAdjusted)-eval(ltcgOthSrcLossNoRaceHorseSetoff.value)-eval(ltcgBusLossSetoff.value);
														ltcgHPlossCurYrSetoff.value=eval(hpLossToBeAdjusted);
														B1eRemain = eval(B1eRemain)-eval(ltcgHPlossCurYrSetoff.value);
													}
													hpLossToBeAdjusted=eval(hpLossToBeAdjusted)-eval(ltcgHPlossCurYrSetoff.value);
												}
												
												if(eval(hpLossToBeAdjusted)>0){
															
													if((eval(stcgIncOfCurYrUnderThatHead.value)-eval(stcgHPlossCurYrSetoff.value)-eval(stcgOthSrcLossNoRaceHorseSetoff.value)-eval(stcgBusLossSetoff.value))>0){
												
												
														if(eval(A1eRemain)<= eval(hpLossToBeAdjusted)){
														
															stcgHPlossCurYrSetoff.value=eval(stcgHPlossCurYrSetoff.value)+eval(A1eRemain);
															hpLossToBeAdjusted=eval(hpLossToBeAdjusted)-eval(A1eRemain);
															A1eRemain = 0;
														}else{
												
															stcgHPlossCurYrSetoff.value=eval(stcgHPlossCurYrSetoff.value)+eval(hpLossToBeAdjusted);															
															A1eRemain = eval(A1eRemain) - eval(hpLossToBeAdjusted);
															hpLossToBeAdjusted=0;
														}
														
														
													}	
													
													
													if(eval(hpLossToBeAdjusted) > 0){
													
														if((eval(ltcgIncOfCurYrUnderThatHead.value)-eval(ltcgHPlossCurYrSetoff.value))>0){
													
															if(eval(B2eRemain)<=eval(hpLossToBeAdjusted)){
															
																ltcgHPlossCurYrSetoff.value=eval(ltcgHPlossCurYrSetoff.value)+eval(B2eRemain);
																hpLossToBeAdjusted=eval(hpLossToBeAdjusted)-eval(B2eRemain);
																B2eRemain = 0;
															}else{
															
																ltcgHPlossCurYrSetoff.value=eval(ltcgHPlossCurYrSetoff.value)+eval(hpLossToBeAdjusted);
																B2eRemain = eval(B2eRemain) - eval(hpLossToBeAdjusted);
																hpLossToBeAdjusted=0;
																
															}
															
														}
						
													}
													
												}
						
											}
								}
							
							
							}
		
						
						}
					
					}
				
				}
				
			}
			

			totHPlossCurYrSetoff.value=eval(busHPlossCurYrSetoff.value)+eval(specltvHPlossCurYrSetoff.value)+eval(specfidHPlossCurYrSetoff.value)+eval(stcgHPlossCurYrSetoff.value)+eval(ltcgHPlossCurYrSetoff.value)+eval(othSrcHPlossCurYrSetoff.value)+eval(profitFrmRaceHorseHPlossCurYrSetoff.value); 
			hpBusLossSetoff.value=parseInt(hpBusLossSetoff.value);
			
			totBusLossSetoff.value=eval(hpBusLossSetoff.value)+eval(stcgBusLossSetoff.value)+eval(ltcgBusLossSetoff.value)+eval(othSrcBusLossSetoff.value)+eval(profitFrmRaceHorseBusLossSetoff.value);
			
			totOthSrcLossNoRaceHorseSetoff.value =eval(hpOthSrcLossNoRaceHorseSetoff.value)+eval(busOthSrcLossNoRaceHorseSetoff.value)+eval(specltvOthSrcLossNoRaceHorseSetoff.value)+eval(specfidOthSrcLossNoRaceHorseSetoff.value)+eval(stcgOthSrcLossNoRaceHorseSetoff.value)+eval(ltcgOthSrcLossNoRaceHorseSetoff.value)+eval(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value);
			
		
			hpIncOfCurYrAfterSetOff.value=eval(hpIncOfCurYrUnderThatHead.value)-eval(hpBusLossSetoff.value)-eval(hpOthSrcLossNoRaceHorseSetoff.value);

			busIncOfCurYrAfterSetOff.value=eval(busIncOfCurYrUnderThatHead.value)-eval(busOthSrcLossNoRaceHorseSetoff.value)-eval(busHPlossCurYrSetoff.value);
			
			specltvIncOfCurYrAfterSetOff.value =eval(specltvIncOfCurYrUnderThatHead.value)-eval(specltvHPlossCurYrSetoff.value)-eval(specltvOthSrcLossNoRaceHorseSetoff.value);
			
			specfidIncOfCurYrAfterSetOff.value=eval(specfidIncOfCurYrUnderThatHead.value )-eval(specfidHPlossCurYrSetoff.value)-eval(specfidOthSrcLossNoRaceHorseSetoff.value);
			
			stcgIncOfCurYrAfterSetOff.value=eval(stcgIncOfCurYrUnderThatHead.value)-eval(stcgHPlossCurYrSetoff.value)-eval(stcgBusLossSetoff.value)-eval(stcgOthSrcLossNoRaceHorseSetoff.value);
			
			ltcgIncOfCurYrAfterSetOff.value=eval(ltcgIncOfCurYrUnderThatHead.value)-eval(ltcgHPlossCurYrSetoff.value)-eval(ltcgBusLossSetoff.value)-eval(ltcgOthSrcLossNoRaceHorseSetoff.value);
			
			othSrcIncOfCurYrAfterSetOff.value=eval(othSrcIncOfCurYrUnderThatHead.value)-eval(othSrcHPlossCurYrSetoff.value)-eval(othSrcBusLossSetoff.value);
			
			profitFrmRaceHorseIncOfCurYrAfterSetOff.value=eval(profitFrmRaceHorseIncOfCurYrUnderThatHead.value)-eval(profitFrmRaceHorseHPlossCurYrSetoff.value)-eval(profitFrmRaceHorseBusLossSetoff.value)-eval(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value);
			
			balHPlossCurYrAftSetoff.value=eval(totHPlossCurYr.value)-eval(totHPlossCurYrSetoff.value);
			
			balBusLossAftSetoff.value=eval(totBusLoss.value) -eval(totBusLossSetoff.value);
			
			balOthSrcLossNoRaceHorseAftSetoff.value=eval(totOthSrcLossNoRaceHorse.value)-eval(totOthSrcLossNoRaceHorseSetoff.value);
			
			schSIChangeIncome(B1eRemain,A1eRemain,B2eRemain,called);
			
	}



function commonCalcCYLA(incOfCurrYr,lossToBeAdjusted,incRemainAftrSetoff,totalLossSetOff,fieldName){
	

	if(eval(incOfCurrYr) < eval(incRemainAftrSetoff) || eval(lossToBeAdjusted) < eval(totalLossSetOff)){
	
		fieldName.value=fieldName.oldvalue;
	
	}
}

function calculateCYLA(fieldName){

var hpIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.houseProperty.incCYLA.incOfCurYrUnderThatHead')[0]; hpIncOfCurYrUnderThatHead.value = coalesce(hpIncOfCurYrUnderThatHead.value);
var hpBusLossSetoff = document.getElementsByName('itr7.scheduleCYLA.houseProperty.incCYLA.busLossSetoff')[0];  hpBusLossSetoff.value = coalesce(hpBusLossSetoff.value);
var hpOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.houseProperty.incCYLA.othSrcLossNoRaceHorseSetoff')[0]; hpOthSrcLossNoRaceHorseSetoff.value = coalesce(hpOthSrcLossNoRaceHorseSetoff.value);
var hpIncOfCurYrAfterSetOff = document.getElementsByName('itr7.scheduleCYLA.houseProperty.incCYLA.incOfCurYrAfterSetOff')[0]; hpIncOfCurYrAfterSetOff.value = coalesce(hpIncOfCurYrAfterSetOff.value);
var busIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.busProfInclSpecProf.incCYLA.incOfCurYrUnderThatHead')[0]; busIncOfCurYrUnderThatHead.value = coalesce(busIncOfCurYrUnderThatHead.value);
var busHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.busProfInclSpecProf.incCYLA.hPlossCurYrSetoff')[0]; busHPlossCurYrSetoff.value = coalesce(busHPlossCurYrSetoff.value);
var busOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.busProfInclSpecProf.incCYLA.othSrcLossNoRaceHorseSetoff')[0]; busOthSrcLossNoRaceHorseSetoff.value = coalesce(busOthSrcLossNoRaceHorseSetoff.value);
var busIncOfCurYrAfterSetOff = document.getElementsByName('itr7.scheduleCYLA.busProfInclSpecProf.incCYLA.incOfCurYrAfterSetOff')[0]; busIncOfCurYrAfterSetOff.value = coalesce(busIncOfCurYrAfterSetOff.value);
var specltvIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.speculativeInc.incCYLA.incOfCurYrUnderThatHead')[0]; specltvIncOfCurYrUnderThatHead.value = coalesce(specltvIncOfCurYrUnderThatHead.value);
var specltvHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.speculativeInc.incCYLA.hPlossCurYrSetoff')[0]; specltvHPlossCurYrSetoff.value = coalesce(specltvHPlossCurYrSetoff.value);
var specltvOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.speculativeInc.incCYLA.othSrcLossNoRaceHorseSetoff')[0]; specltvOthSrcLossNoRaceHorseSetoff.value = coalesce(specltvOthSrcLossNoRaceHorseSetoff.value);
var specltvIncOfCurYrAfterSetOff = document.getElementsByName('itr7.scheduleCYLA.speculativeInc.incCYLA.incOfCurYrAfterSetOff')[0]; specltvIncOfCurYrAfterSetOff.value = coalesce(specltvIncOfCurYrAfterSetOff.value);
var specfidIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.specifiedInc.incCYLA.incOfCurYrUnderThatHead')[0]; specfidIncOfCurYrUnderThatHead.value = coalesce(specfidIncOfCurYrUnderThatHead.value);
var specfidHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.specifiedInc.incCYLA.hPlossCurYrSetoff')[0]; specfidHPlossCurYrSetoff.value = coalesce(specfidHPlossCurYrSetoff.value);
var specfidOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.specifiedInc.incCYLA.othSrcLossNoRaceHorseSetoff')[0]; specfidOthSrcLossNoRaceHorseSetoff.value = coalesce(specfidOthSrcLossNoRaceHorseSetoff.value);
var specfidIncOfCurYrAfterSetOff = document.getElementsByName('itr7.scheduleCYLA.specifiedInc.incCYLA.incOfCurYrAfterSetOff')[0]; specfidIncOfCurYrAfterSetOff.value = coalesce(specfidIncOfCurYrAfterSetOff.value);
var stcgIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.stcg.incCYLA.incOfCurYrUnderThatHead')[0]; stcgIncOfCurYrUnderThatHead.value = coalesce(stcgIncOfCurYrUnderThatHead.value);
var stcgHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.stcg.incCYLA.hPlossCurYrSetoff')[0]; stcgHPlossCurYrSetoff.value = coalesce(stcgHPlossCurYrSetoff.value);
var stcgBusLossSetoff = document.getElementsByName('itr7.scheduleCYLA.stcg.incCYLA.busLossSetoff')[0]; stcgBusLossSetoff.value = coalesce(stcgBusLossSetoff.value);
var stcgOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.stcg.incCYLA.othSrcLossNoRaceHorseSetoff')[0]; stcgOthSrcLossNoRaceHorseSetoff.value = coalesce(stcgOthSrcLossNoRaceHorseSetoff.value);
var stcgIncOfCurYrAfterSetOff  = document.getElementsByName('itr7.scheduleCYLA.stcg.incCYLA.incOfCurYrAfterSetOff')[0]; stcgIncOfCurYrAfterSetOff.value = coalesce(stcgIncOfCurYrAfterSetOff.value);
var ltcgIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.ltcg.incCYLA.incOfCurYrUnderThatHead')[0]; ltcgIncOfCurYrUnderThatHead.value = coalesce(ltcgIncOfCurYrUnderThatHead.value);
var ltcgHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.ltcg.incCYLA.hPlossCurYrSetoff')[0]; ltcgHPlossCurYrSetoff.value = coalesce(ltcgHPlossCurYrSetoff.value);
var ltcgBusLossSetoff = document.getElementsByName('itr7.scheduleCYLA.ltcg.incCYLA.busLossSetoff')[0]; ltcgBusLossSetoff.value = coalesce(ltcgBusLossSetoff.value);
var ltcgOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.ltcg.incCYLA.othSrcLossNoRaceHorseSetoff')[0];  ltcgOthSrcLossNoRaceHorseSetoff.value = coalesce(ltcgOthSrcLossNoRaceHorseSetoff.value);
var ltcgIncOfCurYrAfterSetOff = document.getElementsByName('itr7.scheduleCYLA.ltcg.incCYLA.incOfCurYrAfterSetOff')[0]; ltcgIncOfCurYrAfterSetOff.value = coalesce(ltcgIncOfCurYrAfterSetOff.value);
var othSrcIncOfCurYrUnderThatHead  = document.getElementsByName('itr7.scheduleCYLA.othSrcInclRaceHorse.incCYLA.incOfCurYrUnderThatHead')[0]; othSrcIncOfCurYrUnderThatHead.value = coalesce(othSrcIncOfCurYrUnderThatHead.value);
var othSrcHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.othSrcInclRaceHorse.incCYLA.hPlossCurYrSetoff')[0]; othSrcHPlossCurYrSetoff.value = coalesce(othSrcHPlossCurYrSetoff.value);
var othSrcBusLossSetoff = document.getElementsByName('itr7.scheduleCYLA.othSrcInclRaceHorse.incCYLA.busLossSetoff')[0]; othSrcBusLossSetoff.value = coalesce(othSrcBusLossSetoff.value);
var othSrcIncOfCurYrAfterSetOff= document.getElementsByName('itr7.scheduleCYLA.othSrcInclRaceHorse.incCYLA.incOfCurYrAfterSetOff')[0];  othSrcIncOfCurYrAfterSetOff.value = coalesce(othSrcIncOfCurYrAfterSetOff.value);
var profitFrmRaceHorseIncOfCurYrUnderThatHead = document.getElementsByName('itr7.scheduleCYLA.profitFrmRaceHorse.incCYLA.incOfCurYrUnderThatHead')[0]; profitFrmRaceHorseIncOfCurYrUnderThatHead.value = coalesce(profitFrmRaceHorseIncOfCurYrUnderThatHead.value);
var profitFrmRaceHorseHPlossCurYrSetoff = document.getElementsByName('itr7.scheduleCYLA.profitFrmRaceHorse.incCYLA.hPlossCurYrSetoff')[0]; profitFrmRaceHorseHPlossCurYrSetoff.value = coalesce(profitFrmRaceHorseHPlossCurYrSetoff.value);
var profitFrmRaceHorseBusLossSetoff= document.getElementsByName('itr7.scheduleCYLA.profitFrmRaceHorse.incCYLA.busLossSetoff')[0]; profitFrmRaceHorseBusLossSetoff.value = coalesce(profitFrmRaceHorseBusLossSetoff.value);
var profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff= document.getElementsByName('itr7.scheduleCYLA.profitFrmRaceHorse.incCYLA.othSrcLossNoRaceHorseSetoff')[0]; profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value = coalesce(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value);
var profitFrmRaceHorseIncOfCurYrAfterSetOff = document.getElementsByName('itr7.scheduleCYLA.profitFrmRaceHorse.incCYLA.incOfCurYrAfterSetOff')[0]; profitFrmRaceHorseIncOfCurYrAfterSetOff.value = coalesce(profitFrmRaceHorseIncOfCurYrAfterSetOff.value);
var totHPlossCurYrSetoff =  document.getElementsByName('itr7.scheduleCYLA.totalLossSetOff.totHPlossCurYrSetoff')[0]; totHPlossCurYrSetoff.value = coalesce(totHPlossCurYrSetoff.value);
var totBusLossSetoff = document.getElementsByName('itr7.scheduleCYLA.totalLossSetOff.totBusLossSetoff')[0]; totBusLossSetoff.value = coalesce(totBusLossSetoff.value);
var totOthSrcLossNoRaceHorseSetoff = document.getElementsByName('itr7.scheduleCYLA.totalLossSetOff.totOthSrcLossNoRaceHorseSetoff')[0]; totOthSrcLossNoRaceHorseSetoff.value = coalesce(totOthSrcLossNoRaceHorseSetoff.value);
var balHPlossCurYrAftSetoff = document.getElementsByName('itr7.scheduleCYLA.lossRemAftSetOff.balHPlossCurYrAftSetoff')[0]; balHPlossCurYrAftSetoff.value = coalesce(balHPlossCurYrAftSetoff.value);
var balBusLossAftSetoff = document.getElementsByName('itr7.scheduleCYLA.lossRemAftSetOff.balBusLossAftSetoff')[0]; balBusLossAftSetoff.value = coalesce(balBusLossAftSetoff.value);
var balOthSrcLossNoRaceHorseAftSetoff = document.getElementsByName('itr7.scheduleCYLA.lossRemAftSetOff.balOthSrcLossNoRaceHorseAftSetoff')[0]; balOthSrcLossNoRaceHorseAftSetoff.value = coalesce(balOthSrcLossNoRaceHorseAftSetoff.value);

var totalIncomeChargeableUnHP = document.getElementsByName('itr7.scheduleHP.totalIncomeChargeableUnHP')[0];


var totHPlossCurYr = document.getElementsByName('itr7.scheduleCYLA.totalCurYr.totHPlossCurYr')[0]; 
totHPlossCurYr.value = coalesce(totHPlossCurYr.value);
var totBusLoss = document.getElementsByName('itr7.scheduleCYLA.totalCurYr.totBusLoss')[0];
totBusLoss.value = coalesce(totBusLoss.value);
var totOthSrcLossNoRaceHorse = document.getElementsByName('itr7.scheduleCYLA.totalCurYr.totOthSrcLossNoRaceHorse')[0];
totOthSrcLossNoRaceHorse.value = coalesce(totOthSrcLossNoRaceHorse.value);

var totalIncomeChargeableUnHP=document.getElementsByName('itr7.scheduleHP.totalIncomeChargeableUnHP')[0];
totalIncomeChargeableUnHP.value = coalesce(totalIncomeChargeableUnHP.value);
var netPLBusOthThanSpec7A7B7C=document.getElementsByName('itr7.corpScheduleBP.businessIncOthThanSpec.netPLBusOthThanSpec7A7B7C')[0];
netPLBusOthThanSpec7A7B7C.value = coalesce(netPLBusOthThanSpec7A7B7C.value);
var balanceNoRaceHorse=document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.balanceNoRaceHorse')[0];
balanceNoRaceHorse.value = coalesce(balanceNoRaceHorse.value);
var totalSTCG=document.getElementsByName('itr7.scheduleCG.shortTermCapGain.totalSTCG')[0];
totalSTCG.value = coalesce(totalSTCG.value);
var totalLTCG=document.getElementsByName('itr7.scheduleCG.longTermCapGain.totalLTCG')[0];
totalLTCG.value = coalesce(totalLTCG.value);
var adjustedPLFrmSpecuBus=document.getElementsByName('itr7.corpScheduleBP.specBusinessInc.adjustedPLFrmSpecuBus')[0];
adjustedPLFrmSpecuBus.value = coalesce(adjustedPLFrmSpecuBus.value);
var profitLossSpecifiedBusFinal=document.getElementsByName('itr7.corpScheduleBP.incSpecifiedBusiness.profitLossSpecifiedBusFinal')[0];
profitLossSpecifiedBusFinal.value = coalesce(profitLossSpecifiedBusFinal.value);
var balanceOwnRaceHorse=document.getElementsByName('itr7.scheduleOS.incFromOwnHorse.balanceOwnRaceHorse')[0];
balanceOwnRaceHorse.value = coalesce(balanceOwnRaceHorse.value);

var deemedSTCGDeprAsset=document.getElementsByName('itr7.scheduleCG.shortTermCapGain.deemedSTCGDeprAsset')[0];
deemedSTCGDeprAsset.value = coalesce(deemedSTCGDeprAsset.value);
var exemptionUs111A=document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0];
exemptionUs111A.value = coalesce(exemptionUs111A.value);

var balLTCGNo112=document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetNoProviso112.balLTCGNo112')[0];
balLTCGNo112.value = coalesce(balLTCGNo112.value);
var balCG=document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.balCG')[0];
balCG.value = coalesce(balCG.value);
var balLTCG112=document.getElementsByName('itr7.scheduleCG.longTermCapGain.otherAssetProviso112.balLTCG112')[0];
balLTCG112.value = coalesce(balLTCG112.value);



totHPlossCurYrSetoff.value=eval(busHPlossCurYrSetoff.value)+eval(specltvHPlossCurYrSetoff.value)+eval(specfidHPlossCurYrSetoff.value)+eval(stcgHPlossCurYrSetoff.value)+eval(ltcgHPlossCurYrSetoff.value)+eval(othSrcHPlossCurYrSetoff.value)+eval(profitFrmRaceHorseHPlossCurYrSetoff.value); 

totBusLossSetoff.value=eval(hpBusLossSetoff.value)+eval(stcgBusLossSetoff.value)+eval(ltcgBusLossSetoff.value)+eval(othSrcBusLossSetoff.value)+eval(profitFrmRaceHorseBusLossSetoff.value);
		
totOthSrcLossNoRaceHorseSetoff.value =eval(hpOthSrcLossNoRaceHorseSetoff.value)+eval(busOthSrcLossNoRaceHorseSetoff.value)+eval(specltvOthSrcLossNoRaceHorseSetoff.value)+eval(specfidOthSrcLossNoRaceHorseSetoff.value)+eval(stcgOthSrcLossNoRaceHorseSetoff.value)+eval(ltcgOthSrcLossNoRaceHorseSetoff.value)+eval(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value);


if(fieldName.name=='itr7.scheduleCYLA.busProfInclSpecProf.incCYLA.hPlossCurYrSetoff'){
commonCalcCYLA(busIncOfCurYrUnderThatHead.value,totHPlossCurYr.value,eval(busOthSrcLossNoRaceHorseSetoff.value)+eval(busHPlossCurYrSetoff.value),totHPlossCurYrSetoff.value,fieldName);
}

if(fieldName.name=='itr7.scheduleCYLA.speculativeInc.incCYLA.hPlossCurYrSetoff'){
commonCalcCYLA(specltvIncOfCurYrUnderThatHead.value,totHPlossCurYr.value,eval(specltvHPlossCurYrSetoff.value)+eval(specltvOthSrcLossNoRaceHorseSetoff.value),totHPlossCurYrSetoff.value,fieldName);
}

if(fieldName.name=='itr7.scheduleCYLA.specifiedInc.incCYLA.hPlossCurYrSetoff'){
commonCalcCYLA(specfidIncOfCurYrUnderThatHead.value,totHPlossCurYr.value,eval(specfidHPlossCurYrSetoff.value)+eval(specfidOthSrcLossNoRaceHorseSetoff.value)+eval(specfidOthSrcLossNoRaceHorseSetoff.value),totHPlossCurYrSetoff.value,fieldName);
}

if(fieldName.name=='itr7.scheduleCYLA.stcg.incCYLA.hPlossCurYrSetoff'){
commonCalcCYLA(stcgIncOfCurYrUnderThatHead.value,totHPlossCurYr.value,eval(stcgHPlossCurYrSetoff.value)+eval(stcgBusLossSetoff.value)+eval(stcgOthSrcLossNoRaceHorseSetoff.value),totHPlossCurYrSetoff.value,fieldName);
}

if(fieldName.name=='itr7.scheduleCYLA.ltcg.incCYLA.hPlossCurYrSetoff'){
commonCalcCYLA(ltcgIncOfCurYrUnderThatHead.value,totHPlossCurYr.value,eval(ltcgHPlossCurYrSetoff.value)+eval(ltcgBusLossSetoff.value)+eval(ltcgOthSrcLossNoRaceHorseSetoff.value),totHPlossCurYrSetoff.value,fieldName);
}

if(fieldName.name=='itr7.scheduleCYLA.othSrcInclRaceHorse.incCYLA.hPlossCurYrSetoff'){
commonCalcCYLA(othSrcIncOfCurYrUnderThatHead.value,totHPlossCurYr.value,eval(othSrcHPlossCurYrSetoff.value)+eval(othSrcBusLossSetoff.value),totHPlossCurYrSetoff.value,fieldName);
}
if(fieldName.name=='itr7.scheduleCYLA.profitFrmRaceHorse.incCYLA.hPlossCurYrSetoff'){
commonCalcCYLA(profitFrmRaceHorseIncOfCurYrUnderThatHead.value,totHPlossCurYr.value,eval(profitFrmRaceHorseHPlossCurYrSetoff.value)+eval(profitFrmRaceHorseBusLossSetoff.value)+eval(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value),totHPlossCurYrSetoff.value,fieldName);
}

if(fieldName.name=='itr7.scheduleCYLA.houseProperty.incCYLA.busLossSetoff'){
commonCalcCYLA(hpIncOfCurYrUnderThatHead.value,totBusLoss.value,eval(hpBusLossSetoff.value)+eval(hpOthSrcLossNoRaceHorseSetoff.value),totBusLossSetoff.value,fieldName);
}

if(fieldName.name=='itr7.scheduleCYLA.stcg.incCYLA.busLossSetoff'){
commonCalcCYLA(stcgIncOfCurYrUnderThatHead.value,totBusLoss.value,eval(stcgHPlossCurYrSetoff.value)+eval(stcgBusLossSetoff.value)+eval(stcgOthSrcLossNoRaceHorseSetoff.value),totBusLossSetoff.value,fieldName);
}

if(fieldName.name=='itr7.scheduleCYLA.ltcg.incCYLA.busLossSetoff'){
commonCalcCYLA(ltcgIncOfCurYrUnderThatHead.value,totBusLoss.value,eval(ltcgHPlossCurYrSetoff.value)+eval(ltcgBusLossSetoff.value)+eval(ltcgOthSrcLossNoRaceHorseSetoff.value),totBusLossSetoff.value,fieldName);
}

if(fieldName.name=='itr7.scheduleCYLA.othSrcInclRaceHorse.incCYLA.busLossSetoff'){
commonCalcCYLA(othSrcIncOfCurYrUnderThatHead.value,totBusLoss.value,eval(othSrcHPlossCurYrSetoff.value)+eval(othSrcBusLossSetoff.value),totBusLossSetoff.value,fieldName);
}
if(fieldName.name=='itr7.scheduleCYLA.profitFrmRaceHorse.incCYLA.busLossSetoff'){
commonCalcCYLA(profitFrmRaceHorseIncOfCurYrUnderThatHead.value,totBusLoss.value,eval(profitFrmRaceHorseHPlossCurYrSetoff.value)+eval(profitFrmRaceHorseBusLossSetoff.value)+eval(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value),totBusLossSetoff.value,fieldName);
}



if(fieldName.name=='itr7.scheduleCYLA.houseProperty.incCYLA.othSrcLossNoRaceHorseSetoff'){
commonCalcCYLA(hpIncOfCurYrUnderThatHead.value,totOthSrcLossNoRaceHorse.value,eval(hpBusLossSetoff.value)+eval(hpOthSrcLossNoRaceHorseSetoff.value),totOthSrcLossNoRaceHorseSetoff.value,fieldName);
}

if(fieldName.name=='itr7.scheduleCYLA.busProfInclSpecProf.incCYLA.othSrcLossNoRaceHorseSetoff'){
commonCalcCYLA(busIncOfCurYrUnderThatHead.value,totOthSrcLossNoRaceHorse.value,eval(busOthSrcLossNoRaceHorseSetoff.value)+eval(busHPlossCurYrSetoff.value),totOthSrcLossNoRaceHorseSetoff.value,fieldName);
}

if(fieldName.name=='itr7.scheduleCYLA.speculativeInc.incCYLA.othSrcLossNoRaceHorseSetoff'){
commonCalcCYLA(specltvIncOfCurYrUnderThatHead.value,totOthSrcLossNoRaceHorse.value,eval(specltvHPlossCurYrSetoff.value)+eval(specltvOthSrcLossNoRaceHorseSetoff.value),totOthSrcLossNoRaceHorseSetoff.value,fieldName);
}

if(fieldName.name=='itr7.scheduleCYLA.specifiedInc.incCYLA.othSrcLossNoRaceHorseSetoff'){
commonCalcCYLA(specfidIncOfCurYrUnderThatHead.value,totOthSrcLossNoRaceHorse.value,eval(specfidHPlossCurYrSetoff.value)+eval(specfidOthSrcLossNoRaceHorseSetoff.value)+eval(specfidOthSrcLossNoRaceHorseSetoff.value),totOthSrcLossNoRaceHorseSetoff.value,fieldName);
}
if(fieldName.name=='itr7.scheduleCYLA.stcg.incCYLA.othSrcLossNoRaceHorseSetoff'){
commonCalcCYLA(stcgIncOfCurYrUnderThatHead.value,totOthSrcLossNoRaceHorse.value,eval(stcgHPlossCurYrSetoff.value)+eval(stcgBusLossSetoff.value)+eval(stcgOthSrcLossNoRaceHorseSetoff.value),totOthSrcLossNoRaceHorseSetoff.value,fieldName);
}

if(fieldName.name=='itr7.scheduleCYLA.ltcg.incCYLA.othSrcLossNoRaceHorseSetoff'){
commonCalcCYLA(ltcgIncOfCurYrUnderThatHead.value,totOthSrcLossNoRaceHorse.value,eval(ltcgHPlossCurYrSetoff.value)+eval(ltcgBusLossSetoff.value)+eval(ltcgOthSrcLossNoRaceHorseSetoff.value),totOthSrcLossNoRaceHorseSetoff.value,fieldName);
}
if(fieldName.name=='itr7.scheduleCYLA.profitFrmRaceHorse.incCYLA.othSrcLossNoRaceHorseSetoff'){
commonCalcCYLA(profitFrmRaceHorseIncOfCurYrUnderThatHead.value,totOthSrcLossNoRaceHorse.value,eval(profitFrmRaceHorseHPlossCurYrSetoff.value)+eval(profitFrmRaceHorseBusLossSetoff.value)+eval(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value),totOthSrcLossNoRaceHorseSetoff.value,fieldName);
}

hpIncOfCurYrAfterSetOff.value=eval(hpIncOfCurYrUnderThatHead.value)-eval(hpBusLossSetoff.value)-eval(hpOthSrcLossNoRaceHorseSetoff.value);

busIncOfCurYrAfterSetOff.value=eval(busIncOfCurYrUnderThatHead.value)-eval(busOthSrcLossNoRaceHorseSetoff.value)-eval(busHPlossCurYrSetoff.value);

specltvIncOfCurYrAfterSetOff.value =eval(specltvIncOfCurYrUnderThatHead.value)-eval(specltvHPlossCurYrSetoff.value)-eval(specltvOthSrcLossNoRaceHorseSetoff.value);
		
specfidIncOfCurYrAfterSetOff.value=eval(specfidIncOfCurYrUnderThatHead.value )-eval(specfidHPlossCurYrSetoff.value)-eval(specfidOthSrcLossNoRaceHorseSetoff.value);
		
stcgIncOfCurYrAfterSetOff.value=eval(stcgIncOfCurYrUnderThatHead.value)-eval(stcgHPlossCurYrSetoff.value)-eval(stcgBusLossSetoff.value)-eval(stcgOthSrcLossNoRaceHorseSetoff.value);
		
ltcgIncOfCurYrAfterSetOff.value=eval(ltcgIncOfCurYrUnderThatHead.value)-eval(ltcgHPlossCurYrSetoff.value)-eval(ltcgBusLossSetoff.value)-eval(ltcgOthSrcLossNoRaceHorseSetoff.value);
		
othSrcIncOfCurYrAfterSetOff.value=eval(othSrcIncOfCurYrUnderThatHead.value)-eval(othSrcHPlossCurYrSetoff.value)-eval(othSrcBusLossSetoff.value);
		
profitFrmRaceHorseIncOfCurYrAfterSetOff.value=eval(profitFrmRaceHorseIncOfCurYrUnderThatHead.value)-eval(profitFrmRaceHorseHPlossCurYrSetoff.value)-eval(profitFrmRaceHorseBusLossSetoff.value)-eval(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value);

totHPlossCurYrSetoff.value=eval(busHPlossCurYrSetoff.value)+eval(specltvHPlossCurYrSetoff.value)+eval(specfidHPlossCurYrSetoff.value)+eval(stcgHPlossCurYrSetoff.value)+eval(ltcgHPlossCurYrSetoff.value)+eval(othSrcHPlossCurYrSetoff.value)+eval(profitFrmRaceHorseHPlossCurYrSetoff.value); 

totBusLossSetoff.value=eval(hpBusLossSetoff.value)+eval(stcgBusLossSetoff.value)+eval(ltcgBusLossSetoff.value)+eval(othSrcBusLossSetoff.value)+eval(profitFrmRaceHorseBusLossSetoff.value);
		
totOthSrcLossNoRaceHorseSetoff.value =eval(hpOthSrcLossNoRaceHorseSetoff.value)+eval(busOthSrcLossNoRaceHorseSetoff.value)+eval(specltvOthSrcLossNoRaceHorseSetoff.value)+eval(specfidOthSrcLossNoRaceHorseSetoff.value)+eval(stcgOthSrcLossNoRaceHorseSetoff.value)+eval(ltcgOthSrcLossNoRaceHorseSetoff.value)+eval(profitFrmRaceHorseOthSrcLossNoRaceHorseSetoff.value);

balHPlossCurYrAftSetoff.value=eval(totHPlossCurYr.value)-eval(totHPlossCurYrSetoff.value);
balOthSrcLossNoRaceHorseAftSetoff.value=eval(totOthSrcLossNoRaceHorse.value)-eval(totOthSrcLossNoRaceHorseSetoff.value);
balBusLossAftSetoff.value=eval(totBusLoss.value)-eval(totBusLossSetoff.value);



}
        
function totAmtOfScheduleMATC(tableId){

		var tab = document.getElementById(tableId);
		var rowCount = tab.rows.length - 3;
		var allInputTags = tab.getElementsByTagName('input');
		var totMatCredGross = parseInt('0' ,10);
		var totMatCredSetOff = parseInt('0' ,10);
		var totMatCredBF = parseInt('0' ,10);
		var totMatCredUtilCurrYr = parseInt('0' ,10);
		var totBalMATCredCF = parseInt('0' ,10);

		for(var i =0; i < rowCount; i++) {
			
			var matCredGross = parseInt(coalesce(document.getElementsByName('itr7.scheduleMATC.utilMATCredAvl['+i+'].matCredGross')[0].value),10);
			var matCredSetOff = parseInt(coalesce(document.getElementsByName('itr7.scheduleMATC.utilMATCredAvl['+i+'].matCredSetOff')[0].value),10);
			var matCredUtilCurrYr = parseInt(coalesce(document.getElementsByName('itr7.scheduleMATC.utilMATCredAvl['+i+'].matCredUtilCurrYr')[0].value),10);
			
			
			var matCredBF = document.getElementsByName('itr7.scheduleMATC.utilMATCredAvl['+i+'].matCredBF')[0];
			
			matCredBF.value = eval(matCredGross - matCredSetOff);
			
			document.getElementsByName('itr7.scheduleMATC.utilMATCredAvl[8].matCredBF')[0].value = parseInt('0',10); 
			
			
			var balMATCredCF = document.getElementsByName('itr7.scheduleMATC.utilMATCredAvl['+i+'].balMATCredCF')[0];
			
			balMATCredCF.value = zeroOrMore(eval(matCredBF.value - matCredUtilCurrYr));
			
			document.getElementsByName('itr7.scheduleMATC.utilMATCredAvl[8].balMATCredCF')[0].value = document.getElementsByName('itr7.scheduleMATC.utilMATCredAvl[8].matCredGross')[0].value 
			
			
			totMatCredGross = eval(parseInt(totMatCredGross,10) + parseInt(matCredGross,10));
			totMatCredSetOff = eval(parseInt(totMatCredSetOff,10) + parseInt(matCredSetOff,10));
			totMatCredBF = eval(parseInt(totMatCredBF,10) + parseInt(matCredBF.value,10));
			totMatCredUtilCurrYr = eval(parseInt(totMatCredUtilCurrYr,10) + parseInt(matCredUtilCurrYr,10));
			totBalMATCredCF = eval(parseInt(totBalMATCredCF,10) + parseInt(balMATCredCF.value,10));
		}
		

			document.getElementsByName('itr7.scheduleMATC.totMatCredGross')[0].value=totMatCredGross;
			document.getElementsByName('itr7.scheduleMATC.totMatCredSetOff')[0].value=totMatCredSetOff;
			document.getElementsByName('itr7.scheduleMATC.totMatCredBF')[0].value=totMatCredBF;
			document.getElementsByName('itr7.scheduleMATC.totMatCredUtilCurrYr')[0].value=totMatCredUtilCurrYr;
			document.getElementsByName('itr7.scheduleMATC.totBalMATCredCF')[0].value=totBalMATCredCF;
			
			document.getElementsByName('itr7.scheduleMATC.amtTaxCredUs115JAA')[0].value=totMatCredUtilCurrYr;
		
			document.getElementsByName('itr7.scheduleMATC.amtMATLiabAllAssYrAvailSubseqYr')[0].value=totBalMATCredCF;
			
}
function coalesceString(val){
    if(val==undefined || val == null){
        return 0;
    }
    return val
}

function scheduleSiIncome(tableId)  {

var secCode1A =  document.getElementsByName('itr7.scheduleSI.splCodeRateTax[0].secCode')[0]; secCode1A.value = coalesceString(secCode1A.value);
var splRatePercent1A = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[0].splRatePercent')[0]; splRatePercent1A.value = coalesce(splRatePercent1A.value);
var splRateInc1A = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[0].splRateInc')[0]; 
var taxableInc1A = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[0].taxableInc')[0]; taxableInc1A.value = coalesce(taxableInc1A.value);
var splRateIncTax1A = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[0].splRateIncTax')[0]; splRateIncTax1A.value = coalesce(splRateIncTax1A.value);

var secCode22 =  document.getElementsByName('itr7.scheduleSI.splCodeRateTax[1].secCode')[0]; secCode22.value = coalesceString(secCode22.value);
var splRatePercent22 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[1].splRatePercent')[0]; splRatePercent22.value = coalesce(splRatePercent22.value);
var splRateInc22 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[1].splRateInc')[0]; splRateInc22.value = coalesce(splRateInc22.value);
var taxableInc22 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[1].taxableInc')[0]; taxableInc22.value = coalesce(taxableInc22.value);
var splRateIncTax22 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[1].splRateIncTax')[0]; splRateIncTax22.value = coalesce(splRateIncTax22.value);

var secCode21 =  document.getElementsByName('itr7.scheduleSI.splCodeRateTax[2].secCode')[0]; secCode21.value = coalesceString(secCode21.value);
var splRatePercent21 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[2].splRatePercent')[0]; splRatePercent21.value = coalesce(splRatePercent21.value);
var splRateInc21 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[2].splRateInc')[0]; splRateInc21.value = coalesce(splRateInc21.value);
var taxableInc21 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[2].taxableInc')[0]; taxableInc21.value = coalesce(taxableInc21.value);
var splRateIncTax21 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[2].splRateIncTax')[0]; splRateIncTax21.value = coalesce(splRateIncTax21.value);

var secCode5BB =  document.getElementsByName('itr7.scheduleSI.splCodeRateTax[3].secCode')[0]; secCode5BB.value = coalesceString(secCode5BB.value);
var splRatePercent5BB = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[3].splRatePercent')[0]; splRatePercent5BB.value = coalesce(splRatePercent5BB.value);
var splRateInc5BB = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[3].splRateInc')[0]; splRateInc5BB.value = coalesce(splRateInc5BB.value);
var taxableInc5BB = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[3].taxableInc')[0]; taxableInc5BB.value = coalesce(taxableInc5BB.value);
var splRateIncTax5BB = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[3].splRateIncTax')[0]; splRateIncTax5BB.value = coalesce(splRateIncTax5BB.value);

var secCode5BBE =  document.getElementsByName('itr7.scheduleSI.splCodeRateTax[4].secCode')[0]; secCode5BBE.value = coalesceString(secCode5BBE.value);
var splRatePercent5BBE = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[4].splRatePercent')[0]; splRatePercent5BBE.value = coalesce(splRatePercent5BBE.value);
var splRateInc5BBE = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[4].splRateInc')[0]; splRateInc5BBE.value = coalesce(splRateInc5BBE.value);
var taxableInc5BBE = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[4].taxableInc')[0]; taxableInc5BBE.value = coalesce(taxableInc5BBE.value);
var splRateIncTax5BBE = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[4].splRateIncTax')[0]; splRateIncTax5BBE.value = coalesce(splRateIncTax5BBE.value);

var secCodeDTAA =  document.getElementsByName('itr7.scheduleSI.splCodeRateTax[5].secCode')[0]; secCodeDTAA.value = coalesceString(secCodeDTAA.value);
var splRatePercentDTAA = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[5].splRatePercent')[0]; splRatePercentDTAA.value = coalesce(splRatePercentDTAA.value);
var splRateIncDTAA = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[5].splRateInc')[0]; splRateIncDTAA.value = coalesce(splRateIncDTAA.value);
var taxableIncDTAA = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[5].taxableInc')[0]; taxableIncDTAA.value = coalesce(taxableIncDTAA.value);
var splRateIncTaxDTAA = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[5].splRateIncTax')[0]; splRateIncTaxDTAA.value = coalesce(splRateIncTaxDTAA.value);

var secCode1 =  document.getElementsByName('itr7.scheduleSI.splCodeRateTax[6].secCode')[0]; secCode1.value = coalesceString(secCode1.value);
var splRatePercent1 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[6].splRatePercent')[0]; splRatePercent1.value = coalesce(splRatePercent1.value);
var splRateInc1 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[6].splRateInc')[0]; splRateInc1.value = coalesce(splRateInc1.value);
var taxableInc1 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[6].taxableInc')[0]; taxableInc1.value = coalesce(taxableInc1.value);
var splRateIncTax1 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[6].splRateIncTax')[0]; splRateIncTax1.value = coalesce(splRateIncTax1.value);

var grossTotalIncome = document.getElementsByName('itr7.partBTI.grossTotalIncome')[0]; grossTotalIncome.value = coalesce(grossTotalIncome.value);
var totalIncome = document.getElementsByName('itr7.partBTI.totalIncome')[0]; totalIncome.value = coalesce(totalIncome.value);
var incChargeTaxSplRate111A112 = document.getElementsByName('itr7.partBTI.incChargeTaxSplRate111A112')[0]; incChargeTaxSplRate111A112.value = coalesce(incChargeTaxSplRate111A112.value);


splRateInc5BB.value = zeroOrMore(coalesce(document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls[0].sourceAmount')[0].value));

var exemptLimit=0;
exemptLimit = getExemptLimit();

if(eval(parseInt(totalIncome.value ,10)) > 0) {
var taxableIncome = eval(parseInt(totalIncome.value ,10)) - eval(parseInt(coalesce(incChargeTaxSplRate111A112.value) ,10));

if(taxableIncome>=0) {
	var remaining = eval(parseInt(exemptLimit ,10)) - eval(parseInt(taxableIncome ,10));	
	
	if(remaining > 0) {
			if(splRateInc21.value>=remaining) {
					taxableInc21.value = splRateInc21.value - remaining;
					taxableInc1A.value = coalesce(splRateInc1A.value);
					taxableInc22.value = splRateInc22.value;					
			} else {
					taxableInc21.value = 0;
					remaining = remaining - splRateInc21.value;
					if(coalesce(splRateInc1A.value) >= remaining) {
						taxableInc1A.value = coalesce(splRateInc1A.value) - remaining;
						taxableInc22.value = splRateInc22.value;
					} else {
						taxableInc1A.value = 0;
						remaining = remaining - coalesce(splRateInc1A.value);
						if(splRateInc22.value >= remaining) {
							taxableInc22.value = splRateInc22.value - remaining;
						} else {
							taxableInc22.value = 0;
							remaining = remaining - taxableInc22.value;
						}

					}
			}
		} else {
			taxableInc21.value = splRateInc21.value;
			taxableInc1A.value = coalesce(splRateInc1A.value);
			taxableInc22.value = splRateInc22.value;
		}
} else {
    var remaining = eval(parseInt(exemptLimit ,10));
     if(splRateInc21.value>=remaining) {
					taxableInc21.value = splRateInc21.value - remaining;
					taxableInc1A.value = coalesce(splRateInc1A.value);
					taxableInc22.value = splRateInc22.value;					
			} else {
					taxableInc21.value = 0;
					remaining = remaining - splRateInc21.value;
					if(coalesce(splRateInc1A.value) >= remaining) {
						taxableInc1A.value = coalesce(splRateInc1A.value) - remaining;
						taxableInc22.value = splRateInc22.value;
					} else {
						taxableInc1A.value = 0;
						remaining = remaining - coalesce(splRateInc1A.value);
						if(splRateInc22.value >= remaining) {
							taxableInc22.value = splRateInc22.value - remaining;
						} else {
							taxableInc22.value = 0;
							remaining = remaining - taxableInc22.value;
						}

					}
			}
}
} else {
    var remaining = eval(parseInt(exemptLimit ,10));
     if(splRateInc21.value>=remaining) {
					taxableInc21.value = splRateInc21.value - remaining;
					taxableInc1A.value = coalesce(splRateInc1A.value);
					taxableInc22.value = splRateInc22.value;					
			} else {
					taxableInc21.value = 0;
					remaining = remaining - splRateInc21.value;
					if(coalesce(splRateInc1A.value) >= remaining) {
						taxableInc1A.value = coalesce(splRateInc1A.value) - remaining;
						taxableInc22.value = splRateInc22.value;
					} else {
						taxableInc1A.value = 0;
						remaining = remaining - coalesce(splRateInc1A.value);
						if(splRateInc22.value >= remaining) {
							taxableInc22.value = splRateInc22.value - remaining;
						} else {
							taxableInc22.value = 0;
							remaining = remaining - taxableInc22.value;
						}

					}
			}
}

//Taxable income for the remaining 3 rows other than auto populate
taxableInc5BB.value = splRateInc5BB.value;
taxableInc5BBE.value = splRateInc5BBE.value;
//taxableIncDTAA.value = splRateIncDTAA.value;
taxableInc1.value = splRateInc1.value;



//Column 'Tax thereon' values for fixed rows
splRateIncTax1A.value = Math.round((15*eval(parseInt(taxableInc1A.value,10)))/parseInt('100' ,10));
splRateIncTax22.value = Math.round((10*eval(parseInt(taxableInc22.value,10)))/parseInt('100' ,10));
splRateIncTax21.value = Math.round((20*eval(parseInt(taxableInc21.value,10)))/parseInt('100' ,10));
splRateIncTax5BB.value = Math.round((30*eval(parseInt(taxableInc5BB.value,10)))/parseInt('100' ,10));
splRateIncTax5BBE.value = Math.round((30*eval(parseInt(taxableInc5BBE.value,10)))/parseInt('100' ,10));
//splRateIncTaxDTAA.value = Math.round((1*eval(parseInt(taxableIncDTAA.value,10)))/parseInt('100' ,10));
//splRateIncTax1.value = Math.round((10*eval(parseInt(taxableInc1.value,10)))/parseInt('100' ,10));



var totSplRateInc = eval(parseInt(coalesce(splRateInc1A.value) ,10)) + eval(parseInt(splRateInc22.value ,10)) + eval(parseInt(splRateInc21.value ,10)) + eval(parseInt(splRateInc5BB.value ,10))
 + eval(parseInt(splRateInc5BBE.value ,10)) + eval(parseInt(splRateIncDTAA.value ,10)) + eval(parseInt(splRateInc1.value ,10));

var totSplRateIncTax = eval(parseInt(splRateIncTax1A.value ,10)) + eval(parseInt(splRateIncTax22.value ,10)) + eval(parseInt(splRateIncTax21.value ,10)) + eval(parseInt(splRateIncTax5BB.value ,10))
 + eval(parseInt(splRateIncTax5BBE.value ,10)) + eval(parseInt(splRateIncTaxDTAA.value ,10)) + eval(parseInt(splRateIncTax1.value ,10));


var rowCount1=countRowInTable('itr7.scheduleSI.splCodeRateTax','splRateInc');

		for(var i = 7; i < rowCount1; i++) {
			
			var splCodeValue=document.getElementsByName('itr7.scheduleSI.splCodeRateTax['+i+'].splRateInc')[0].value;
                        var splRatePercent = document.getElementsByName('itr7.scheduleSI.splCodeRateTax['+i+'].splRatePercent')[0].value;
                        document.getElementsByName('itr7.scheduleSI.splCodeRateTax['+i+'].taxableInc')[0].value=coalesce(splCodeValue);
                        document.getElementsByName('itr7.scheduleSI.splCodeRateTax['+i+'].splRateIncTax')[0].value=Math.round(eval((parseFloat(coalesce(splRatePercent) ,10) * parseInt(coalesce(splCodeValue),10))/parseInt('100' ,10) ));
                        
                        totSplRateInc = eval ( parseInt(totSplRateInc ,10) + parseInt( coalesce(splCodeValue) ,10) );
                        totSplRateIncTax = eval ( parseInt(totSplRateIncTax ,10) + parseInt( coalesce(document.getElementsByName('itr7.scheduleSI.splCodeRateTax['+i+'].splRateIncTax')[0].value) ,10) );
			
		}
	document.getElementsByName('itr7.scheduleSI.totSplRateIncTax')[0].value = zeroOrMore(totSplRateIncTax);
	document.getElementsByName('itr7.scheduleSI.totSplRateInc')[0].value = zeroOrMore(totSplRateInc);

	calculateTiTti('scheduleSI');	
	
}

function calcMATCFromTTI(){

var statusOfPerson	= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0].value ;
var panStatus		= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.panNumber')[0].value.substring(3,4);


if(statusOfPerson=='3' || statusOfPerson=='4' ){

var totalTaxSec115JB=document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.totalTaxSec115JB')[0];
totalTaxSec115JB.value = coalesce(totalTaxSec115JB.value);

var grossTaxLiability=document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.grossTaxLiability')[0];
grossTaxLiability.value = coalesce(grossTaxLiability.value);

var taxUs115JBCurrAssYr=document.getElementsByName('itr7.scheduleMATC.taxUs115JBCurrAssYr')[0];
taxUs115JBCurrAssYr.value = coalesce(taxUs115JBCurrAssYr.value);

var taxOthProvCurrAssYr=document.getElementsByName('itr7.scheduleMATC.taxOthProvCurrAssYr')[0];
taxOthProvCurrAssYr.value = coalesce(taxOthProvCurrAssYr.value);

taxUs115JBCurrAssYr.value=totalTaxSec115JB.value;
taxOthProvCurrAssYr.value=grossTaxLiability.value;

if(eval(taxUs115JBCurrAssYr.value) > eval(taxOthProvCurrAssYr.value)){

document.getElementsByName('itr7.scheduleMATC.utilMATCredAvl[8].matCredGross')[0].value=eval(taxUs115JBCurrAssYr.value)-eval(taxOthProvCurrAssYr.value);
document.getElementsByName('itr7.scheduleMATC.utilMATCredAvl[8].balMATCredCF')[0].value=eval(taxUs115JBCurrAssYr.value)-eval(taxOthProvCurrAssYr.value);
document.getElementsByName('itr7.scheduleMATC.amtOfTaxWithCred')[0].value=0;

}else{
	document.getElementsByName('itr7.scheduleMATC.utilMATCredAvl[8].matCredGross')[0].value=0;
	document.getElementsByName('itr7.scheduleMATC.utilMATCredAvl[8].balMATCredCF')[0].value=0;
	document.getElementsByName('itr7.scheduleMATC.amtOfTaxWithCred')[0].value=eval(taxOthProvCurrAssYr.value)-eval(taxUs115JBCurrAssYr.value);

}
totAmtOfScheduleMATC('scheduleMATC');
}

}

function populateSplRatePercent(elem) {

    var index = elem.selectedIndex - 1;

    var position = parseInt(elem.name.substring(elem.name.indexOf("[") + 1, elem.name.indexOf("]")));

    if (index == 0) {
       document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("20", 10);
    } else if (index == 1) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("50", 10);
    } else if (index == 2) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("20", 10);
    } else if (index == 3) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("10", 10);
    } else if (index == 4) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = 12.50;
    } else if (index == 5) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("5", 10);
    } else if (index == 6) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("10", 10);
    } else if (index == 7) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("20", 10);
    } else if (index == 8) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("10", 10); 
    } else if (index == 9) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("5", 10);
    } else if (index == 10) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= parseInt("20", 10);
    } else if (index == 11) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= parseInt("30", 10);
    } else if ((index == 12)) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("10", 10);
    } else if (index == 13) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("10", 10);
    } else if (index == 14) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("10", 10);
    } else if (index == 15) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("10", 10);
    } else if (index == 16) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value = parseInt("20", 10);
    } else if (index == 17) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= parseInt("20", 10);
    } else if (index == 18) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= parseInt("15", 10);
    } else if (index == 19) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= parseInt("25", 10);
    } else if (index == 20) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= parseInt("25", 10);
    }else if (index == 21) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= parseInt("10", 10);
    }else if (index == 22) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= parseInt("10", 10);
    }else if (index == 23) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= parseInt("20", 10);
    }else if (index == 24) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= parseInt("5", 10);
    }else if (index == 25) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= parseInt("5", 10);
    }else if (index == 26) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= parseInt("5", 10);
    } else if (index == 27) {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= parseInt("15", 10);
    } else {
        document.getElementsByName("itr7.scheduleSI.splCodeRateTax["+position+"].splRatePercent")[0].value= '';
    }
    
    scheduleSiIncome('scheduleSI');
}

function getExemptLimit() {
	var limit=0;
	
	var status = document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0].value;
	var residentialStatus = document.getElementsByName('itr7.partAGEN1.filingStatus.residentialStatus')[0].value;
	var dob = document.getElementsByName('itr7.partAGEN1.orgFirmInfo.dateOFFormOrIncorp')[0].value;
	if(residentialStatus == 'NRI') {
		limit = 0;
	} else if(status == '2') {
		limit = 250000;
	} else if(status == '1') {
		limit=250000;		
	}
	
	return limit;	
}

function selectToTextReadonly(selectField,textField,checkValue){
	var val=document.getElementsByName(selectField)[0].value;
	if(document.getElementsByName(textField)[0].type=='select-one'){
	if(val == checkValue){
		document.getElementsByName(textField)[0].disabled=false;
	}
	else{
		document.getElementsByName(textField)[0].disabled=true;
		if(document.getElementsByName(textField)[0].options[0].value == 0){
			document.getElementsByName(textField)[0].value="0";	
		}else{
		document.getElementsByName(textField)[0].value="";
		}
	}
	}
	else{
	if(val == checkValue){
		document.getElementsByName(textField)[0].readOnly=false;
                document.getElementsByName(textField)[0].disabled=false;
	}
	else{
		document.getElementsByName(textField)[0].readOnly=true;
                document.getElementsByName(textField)[0].disabled=true;
		document.getElementsByName(textField)[0].value="";
	}
	}
}

function isLetOut(){

	var totHp = eval(parseInt(document.getElementById('scheduleHPLast').cells[0].textContent) - 1);
	for ( var i = 0; i < totHp; i++) {
		var tempName = 'itr7.scheduleHP.propertyDetails[' + i + '].ifLetOut';
		var val = document.getElementsByName(tempName)[0].value;

		if (val == 'Y') {

			$('#scheduleHPTenant' + eval(parseInt(i) + 1)).find(':input').prop(
					'disabled', false);
			document.getElementsByName('scheduleHP.propertyDetails[' + i
					+ '].coTenants[0].coTenantsSNo')[0].value = 1;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.annualLetableValue')[0].disabled = false;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.rentNotRealized')[0].disabled = false;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.localTaxes')[0].disabled = false;
		} else if (val == 'D') {
			$('#scheduleHPTenant' + eval(parseInt(i) + 1)).find(
					'[type=\"checkbox\"]').attr('checked', 'checked');
			deleteRowTable('scheduleHPTenant' + eval(parseInt(i) + 1), 1, 1);
			$('#scheduleHPTenant' + eval(parseInt(i) + 1)).find(':input').prop(
					'disabled', true);
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.annualLetableValue')[0].disabled = false;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.rentNotRealized')[0].disabled = false;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.localTaxes')[0].disabled = false;
		
		} else {

			$('#scheduleHPTenant' + eval(parseInt(i) + 1)).find(
					'[type=\"checkbox\"]').attr('checked', 'checked');
			deleteRowTable('scheduleHPTenant' + eval(parseInt(i) + 1), 1, 1);
			$('#scheduleHPTenant' + eval(parseInt(i) + 1)).find(':input').prop(
					'disabled', true);

			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.annualLetableValue')[0].disabled = true;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.annualLetableValue')[0].value = '';
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.rentNotRealized')[0].disabled = true;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.rentNotRealized')[0].value = '';
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.localTaxes')[0].disabled = true;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.localTaxes')[0].value = '';
		}

	}

}


function addRowToTableScheduleSI(tableId,noOfRow,last){

	addRowToTable(tableId,noOfRow,last);
	scheduleSiIncome (tableId);
	var table=document.getElementById(tableId);
	modifyRow(table);

}

function deleteRowToTableScheduleSI(tableId,noOfRow,last){

	deleteRowTableModified(tableId,noOfRow,last);
	scheduleSiIncome(tableId);

}


function calcScheduleAMT(called) {
	var statusOfPerson	= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0].value ;

	if(!(statusOfPerson=='3' || statusOfPerson=='4')){
	var totalIncItem11 = document.getElementsByName('itr7.itrScheduleAMT.totalIncItem11')[0]; totalIncItem11.value = coalesce(totalIncItem11.value);
	var deductClaimSec6A = document.getElementsByName('itr7.itrScheduleAMT.adjustmentSec115JC.deductClaimSec6A')[0]; deductClaimSec6A.value = coalesce(deductClaimSec6A.value);
	var deductClaimSec10AA = document.getElementsByName('itr7.itrScheduleAMT.adjustmentSec115JC.deductClaimSec10AA')[0]; deductClaimSec10AA.value = coalesce(deductClaimSec10AA.value);
	var deductClaimSec35AD = document.getElementsByName('itr7.itrScheduleAMT.adjustmentSec115JC.deductClaimSec35AD')[0]; deductClaimSec35AD.value = coalesce(deductClaimSec35AD.value);
	var total = document.getElementsByName('itr7.itrScheduleAMT.adjustmentSec115JC.total')[0]; total.value = coalesce(total.value);
	var adjustedUnderSec115JC = document.getElementsByName('itr7.itrScheduleAMT.adjustedUnderSec115JC')[0]; adjustedUnderSec115JC.value = coalesce(adjustedUnderSec115JC.value);
	var taxPayableUnderSec115JC = document.getElementsByName('itr7.itrScheduleAMT.taxPayableUnderSec115JC')[0]; taxPayableUnderSec115JC.value = coalesce(taxPayableUnderSec115JC.value);
	
	totalIncItem11.value = zeroOrMore(coalesce(document.getElementsByName('itr7.partBTI.totalIncome')[0].value));
	
	var totalTemp =  eval(parseInt(deductClaimSec6A.value ,10)) + eval(parseInt(deductClaimSec10AA.value ,10)) + eval(parseInt(deductClaimSec35AD.value ,10));
	if( parseInt(totalTemp ,10) >0 ){
			total.value = totalTemp;
		}else{
			total.value = parseInt(0,10);
		}
	
	var adjustedUnderSec115JCTemp =  eval(parseInt(totalIncItem11.value ,10)) + eval(parseInt(total.value ,10));
	if( parseInt(adjustedUnderSec115JCTemp ,10) >0 ){
			adjustedUnderSec115JC.value = adjustedUnderSec115JCTemp;
		} else{
			adjustedUnderSec115JC.value = parseInt(0,10);
		}
	
	var statusOrCompanyType = document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0].value; 
	if((statusOrCompanyType == '5' || statusOrCompanyType == '10' || adjustedUnderSec115JC.value > parseInt(2000000,10)) && total.value > parseInt(0,10)) {
		taxPayableUnderSec115JC.value = Math.round(adjustedUnderSec115JC.value * (0.185));
	} else {
		taxPayableUnderSec115JC.value = parseInt(0,10);
	}
        
            calculateTiTti('calcScheduleAMT');
      }
}

function calcScheduleAMTC(tableId) {


	var statusOfPerson	= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0].value ;

	if(!(statusOfPerson=='3' || statusOfPerson=='4')){
	
	var taxSection115JC = document.getElementsByName('itr7.itrScheduleAMTC.taxSection115JC')[0]; taxSection115JC.value = coalesce(taxSection115JC.value);
	var taxOthProvisions = document.getElementsByName('itr7.itrScheduleAMTC.taxOthProvisions')[0]; taxOthProvisions.value = coalesce(taxOthProvisions.value);
	var amtTaxCreditAvailable = document.getElementsByName('itr7.itrScheduleAMTC.amtTaxCreditAvailable')[0]; amtTaxCreditAvailable.value = coalesce(amtTaxCreditAvailable.value);
	
	taxSection115JC.value = coalesce(document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.taxPayableOnDeemedTI.totalTaxSec115JB')[0].value); 
	taxOthProvisions.value = coalesce(document.getElementsByName('itr7.partBTTI.computationOfTaxLiability.grossTaxLiability')[0].value);
	
	var amtTaxCreditAvailableTemp =  eval(parseInt(taxOthProvisions.value ,10)) - eval(parseInt(taxSection115JC.value ,10));
	if( parseInt(amtTaxCreditAvailableTemp ,10) >=0 ){
		amtTaxCreditAvailable.value = amtTaxCreditAvailableTemp;
		document.getElementsByName('itr7.scheduleAMTC.scheduleAMTCUtil.CYamtCreditFwd')[0].value = 0;
		document.getElementsByName('itr7.scheduleAMTC.scheduleAMTCUtil.CYamtCreditBalBroughtFwd')[0].value = 0;
		document.getElementsByName('itr7.scheduleAMTC.scheduleAMTCUtil.CYbalAmtCreditCarryFwd')[0].value = 0;		
		} else{
			amtTaxCreditAvailable.value = parseInt(0,10);
			document.getElementsByName('itr7.scheduleAMTC.scheduleAMTCUtil.CYamtCreditFwd')[0].value = Math.abs(amtTaxCreditAvailableTemp);
			document.getElementsByName('itr7.scheduleAMTC.scheduleAMTCUtil.CYamtCreditBalBroughtFwd')[0].value = Math.abs(amtTaxCreditAvailableTemp);
			document.getElementsByName('itr7.scheduleAMTC.scheduleAMTCUtil.CYbalAmtCreditCarryFwd')[0].value = Math.abs(amtTaxCreditAvailableTemp);
		}
	
	var totAMTGross = parseInt('0' ,10);
	var totBalBF = parseInt('0' ,10);
	var totAmtCreditUtilisedCY = parseInt('0' ,10);
	var totBalAMTCreditCF = parseInt('0' ,10);	
			
	var amtCreditFwd = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[0].amtCreditFwd')[0].value;
	var amtCreditSetOfEy = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[0].amtCreditSetOfEy')[0];
	var amtCreditBalBroughtFwd = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[0].amtCreditBalBroughtFwd')[0];
	var amtCreditUtilized = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[0].amtCreditUtilized')[0].value;
	var balAmtCreditCarryFwd = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[0].balAmtCreditCarryFwd')[0];
	
	var amtCreditFwd1 = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[1].amtCreditFwd')[0].value;
	var amtCreditSetOfEy1 = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[1].amtCreditSetOfEy')[0];
	var amtCreditBalBroughtFwd1 = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[1].amtCreditBalBroughtFwd')[0];
	var amtCreditUtilized1 = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[1].amtCreditUtilized')[0].value;
	var balAmtCreditCarryFwd1 = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[1].balAmtCreditCarryFwd')[0];
	
	var amtCreditFwd2 = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[2].amtCreditFwd')[0].value;
	var amtCreditBalBroughtFwd2 = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[2].amtCreditBalBroughtFwd')[0];
	var amtCreditUtilized2 = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[2].amtCreditUtilized')[0].value;
	var balAmtCreditCarryFwd2 = document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[2].balAmtCreditCarryFwd')[0];
	
	var amtCreditFwd3 = document.getElementsByName('itr7.scheduleAMTC.scheduleAMTCUtil.CYamtCreditFwd')[0].value;
	var amtCreditBalBroughtFwd3 = document.getElementsByName('itr7.scheduleAMTC.scheduleAMTCUtil.CYamtCreditBalBroughtFwd')[0];	
	var balAmtCreditCarryFwd3 = document.getElementsByName('itr7.scheduleAMTC.scheduleAMTCUtil.CYbalAmtCreditCarryFwd')[0];
	
	if(parseInt(coalesce(amtCreditSetOfEy.value),10) > parseInt(coalesce(amtCreditFwd),10)){
     	j.setFieldError('itr7.itrScheduleAMTC.scheduleAMTC[0].amtCreditSetOfEy','Set-off in earlier years (B2) should not be greater than Gross (B1)');
 		addErrorXHTML(document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[0].amtCreditSetOfEy')[0],'Set-off in earlier years (B2) should not be greater than Gross (B1)',true);
 		amtCreditSetOfEy.value=parseInt(0,10);		 		
     }else{
    	 amtCreditBalBroughtFwd.value = eval(parseInt(coalesce(amtCreditFwd),10)) - eval(parseInt(coalesce(amtCreditSetOfEy.value),10)); 
     }
	
	if(parseInt(coalesce(amtCreditSetOfEy1.value),10) > parseInt(coalesce(amtCreditFwd1),10)){
     	j.setFieldError('itr7.itrScheduleAMTC.scheduleAMTC[1].amtCreditSetOfEy','Set-off in earlier years (B2) should not be greater than Gross (B1)');
 		addErrorXHTML(document.getElementsByName('itr7.itrScheduleAMTC.scheduleAMTC[1].amtCreditSetOfEy')[0],'Set-off in earlier years (B2) should not be greater than Gross (B1)',true);
 		amtCreditSetOfEy1.value=parseInt(0,10);		 		
     }else{
    	 amtCreditBalBroughtFwd1.value = eval(parseInt(coalesce(amtCreditFwd1),10)) - eval(parseInt(coalesce(amtCreditSetOfEy1.value),10)); 
     }	
	
	 amtCreditBalBroughtFwd2.value = parseInt(coalesce(amtCreditFwd2),10); 
	 amtCreditBalBroughtFwd3.value = parseInt(coalesce(amtCreditFwd3),10); 
	 
	 totAMTGross = parseInt(coalesce(amtCreditFwd),10) + parseInt(coalesce(amtCreditFwd1),10) +  parseInt(coalesce(amtCreditFwd2),10) + parseInt(coalesce(amtCreditFwd3),10); 
	 totBalBF = parseInt(coalesce(amtCreditBalBroughtFwd.value),10) + parseInt(coalesce(amtCreditBalBroughtFwd1.value),10) +  parseInt(coalesce(amtCreditBalBroughtFwd2.value),10) + parseInt(coalesce(amtCreditBalBroughtFwd3.value),10);
	 
	 balAmtCreditCarryFwd.value= parseInt(coalesce(amtCreditBalBroughtFwd.value),10) - parseInt(coalesce(amtCreditUtilized),10); 
	 balAmtCreditCarryFwd1.value= parseInt(coalesce(amtCreditBalBroughtFwd1.value),10) - parseInt(coalesce(amtCreditUtilized1),10); 
	 balAmtCreditCarryFwd2.value= parseInt(coalesce(amtCreditBalBroughtFwd2.value),10) - parseInt(coalesce(amtCreditUtilized2),10);
	 balAmtCreditCarryFwd3.value= parseInt(coalesce( amtCreditBalBroughtFwd3.value),10); 
	 
	 totAmtCreditUtilisedCY = parseInt(coalesce(amtCreditUtilized),10) + parseInt(coalesce(amtCreditUtilized1),10) + parseInt(coalesce(amtCreditUtilized2),10); 
	 totBalAMTCreditCF = parseInt(coalesce(balAmtCreditCarryFwd.value),10) + parseInt(coalesce(balAmtCreditCarryFwd1.value),10) + parseInt(coalesce(balAmtCreditCarryFwd2.value),10) + parseInt(coalesce(balAmtCreditCarryFwd3.value),10); 
		
		document.getElementsByName('itr7.itrScheduleAMTC.totAMTGross')[0].value=totAMTGross;		
		document.getElementsByName('itr7.itrScheduleAMTC.totBalBF')[0].value=totBalBF;		
		document.getElementsByName('itr7.itrScheduleAMTC.totSetOffEys')[0].value=parseInt(coalesce(amtCreditSetOfEy.value),10) + parseInt(coalesce(amtCreditSetOfEy1.value),10);
		document.getElementsByName('itr7.itrScheduleAMTC.totAmtCreditUtilisedCY')[0].value=totAmtCreditUtilisedCY;		
		document.getElementsByName('itr7.itrScheduleAMTC.totBalAMTCreditCF')[0].value=totBalAMTCreditCF;
		
		document.getElementsByName('itr7.itrScheduleAMTC.taxSection115JD')[0].value=totAmtCreditUtilisedCY;
		document.getElementsByName('itr7.itrScheduleAMTC.amtLiabilityAvailable')[0].value=totBalAMTCreditCF;
	}
}

function checkTableEmpty(tableId){

	var tab = document.getElementById(tableId);
	var allInputTags = tab.getElementsByTagName('input');
	var allSelectTags = tab.getElementsByTagName('select');
	var allTextareaTags = tab.getElementsByTagName('textarea');
	var isTableBlank = true;
	
	for ( var i = 0; i < allInputTags.length; i++) {
		if(!allInputTags[i].name.match(".chosenCheckBox$")){
			if(allInputTags[i] != undefined || allInputTags[i].value != null){
				if((allInputTags[i].getAttribute("readonly") == null ) || 
					(allInputTags[i].getAttribute("readonly") != 'readonly')){
						if( allInputTags[i].parentNode.style.display != "none"  && allInputTags[i].getAttribute('type')!='hidden' ){
							var str = allInputTags[i].value.replace(/^\s+|\s+$/g,'');				
							if(str!=''){
								isTableBlank = false;
								break;
							}
						}
				}
			}
		}
	}
	
	for ( var i = 0; i < allTextareaTags.length; i++) {
		if(allTextareaTags[i] != undefined || allTextareaTags[i].value != null ){
			var str = allTextareaTags[i].value.replace(/^\s+|\s+$/g,'');
			if(str!=''){
				isTableBlank = false;
				break;
			}
		}
	}
	
	for ( var i = 0; i < allSelectTags.length; i++) {
		if(allSelectTags[i].value != '-1' && allSelectTags[i].value != ''){
			isTableBlank = false;
			break;
		}
	}

	return isTableBlank;
}


function validateXML(){
    
    var flag=true;
    flag=panStatusCheck();
   
    if(flag){
         flag=trAndFSICheck('scheduleFSI','scheduleTR');
    }
    return flag;
    
}

function trAndFSICheck(scheduleFSI,scheduleTR){

 var flag=true;
 
 var isFsiBlank = checkTableEmpty(scheduleFSI);
 var isTRBlank  = checkTableEmpty(scheduleTR);
 
 
 var claimUs9090A91Flag	= document.getElementsByName('itr7.partAGEN1.filingStatus.claimUs9090A91Flag')[0].value ;
 
 var residentStatus = document.getElementsByName('itr7.partAGEN1.filingStatus.residentialStatus')[0].value;
 var checkValue = 'RES';
 
 if(claimUs9090A91Flag=='YES' && isFsiBlank && isTRBlank){
 
	addErrorXHTML('','Please fill the TR and FSI Schedules, as you have selected claim under section 90/90A/91',true)
	flag=false;
 
 }
 
 if(isFsiBlank && !isTRBlank && residentStatus==checkValue){
	 showPage('page26');
	addErrorXHTML('','Please fill the details in Schedule FSI.');
	flag=false;
 
 }
 
 return flag;
 
 
}

function panStatusCheck(){
    var statusOfPerson       	= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0].value ;
    var panStatus		= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.panNumber')[0].value.substring(3,4);

         var statusCheck=true;
    
        var error = 'Please enter a valid PAN for the selected Status';
        
	if(statusOfPerson=="01" && panStatus != "P"){		
             addErrorXHTML('',error);
            showPage('page2');
            statusCheck = false;
        }
        else if(statusOfPerson=="02" && panStatus != "H"){		
             addErrorXHTML('',error);
            showPage('page2');
            statusCheck = false;
        }
        else if((statusOfPerson=="03" || statusOfPerson=="04") && !(panStatus == "C" || panStatus == "G")){		
             addErrorXHTML('',error);
            showPage('page2');
            statusCheck = false;
        }
        else if(statusOfPerson=="05" && !(panStatus == "F" || panStatus == "G")){		
             addErrorXHTML('',error);
            showPage('page2');
            statusCheck = false;
        }          
        else if(statusOfPerson=="06" && !(panStatus == "A" || panStatus == "B" || panStatus == "G")){		
            addErrorXHTML('',error);
            showPage('page2');
            statusCheck = false;
        }
        else if(statusOfPerson=="07" && !(panStatus == "T" || panStatus == "A" || panStatus == "B" || panStatus == "G")){		
             addErrorXHTML('',error);
            showPage('page2');
            statusCheck = false;
        }
        else if(statusOfPerson=="08" && !(panStatus == "A" || panStatus == "J" || panStatus == "G")){		
             addErrorXHTML('',error);
            showPage('page2');
            statusCheck = false;
        }
        else if(statusOfPerson=="09" && !(panStatus == "A" || panStatus == "B" || panStatus == "G")){		
             addErrorXHTML('',error);
            showPage('page2');
            statusCheck = false;
        }
        else if(statusOfPerson=="10" && !(panStatus == "L" || panStatus == "G")){		
             addErrorXHTML('',error);
            showPage('page2');
            statusCheck = false;
        }        
    
    return statusCheck;
  
}

function disableMATorAMT(){

	var statusOfPerson	= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0].value ;
	var panStatus		= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.panNumber')[0].value.substring(3,4);
	
	if(statusOfPerson==undefined || statusOfPerson =='' || statusOfPerson==null) {
		$('#itrScheduleAMT').find(":input[type!='hidden']").prop('value', '');
		$('#itrScheduleAMT').find(':input').prop('disabled', true);
		$('#itrScheduleAMTC').find(":input[type!='hidden']").prop('value', '');
		$('#itrScheduleAMTC').find(':input').prop('disabled', true);
		
		$('#itrScheduleMAT').find(":input[type!='hidden']").prop('value', '');
		$('#itrScheduleMAT').find(':input').prop('disabled', true);
		$('#itrScheduleMATC').find(":input[type!='hidden']").prop('value', '');
		$('#itrScheduleMATC').find(':input').prop('disabled', true);
	} else if(statusOfPerson=='3' || statusOfPerson=='4' ){
		$('#itrScheduleAMT').find(":input[type!='hidden']").prop('value', '');
		$('#itrScheduleAMT').find(':input').prop('disabled', true);
		$('#itrScheduleAMTC').find(":input[type!='hidden']").prop('value', '');
		$('#itrScheduleAMTC').find(':input').prop('disabled', true);

		$('#itrScheduleMAT').find(':input').prop('disabled', false);
		$('#itrScheduleMATC').find(':input').prop('disabled', false);
		 calcMATCFromTTI();
	}else{
		$('#itrScheduleMAT').find(":input[type!='hidden']").prop('value', '');
		$('#itrScheduleMAT').find(':input').prop('disabled', true);
		$('#itrScheduleMATC').find(":input[type!='hidden']").prop('value', '');
		$('#itrScheduleMATC').find(':input').prop('disabled', true);
		
		$('#itrScheduleAMT').find(':input').prop('disabled', false);
		$('#itrScheduleAMTC').find(':input').prop('disabled', false);
		
	}

}


function checkMATCandAMTCValue(minValueName,maxValueName,type){

	var minValue=minValueName.value;
	var maxValue=$('[name="' + maxValueName+ '"]')[0].value;
	
	if(eval(minValue)>eval(maxValue) && type=='GM'){
		
		minValueName.value=0;
		addErrorXHTML(minValueName,'Amount should be less than the Gross Amount',true);
		j.setFieldError(minValueName.name,'Amount should be less than the Gross Amount');
	}
	
	if(eval(minValue)>eval(maxValue) && type=='GMC'){

		minValueName.value=0;
		addErrorXHTML(minValueName,'MAT Credit Utilised during the Current Year should be less than Balance Brought forward',true);
		j.setFieldError(minValueName.name,'MAT Credit Utilised during the Current Year should be less than Balance Brought forward');
	}
	
	if(eval(minValue)>eval(maxValue) && type=='AMC'){

		minValueName.value=0;
		addErrorXHTML(minValueName,'AMT Credit Utilised during the Current Year should not be greater than Balance Brought forward',true);
		j.setFieldError(minValueName.name,'AMT Credit Utilised during the Current Year should not be greater than Balance Brought forward');

	}
	calcScheduleAMTC('scheduleAMTC');
	totAmtOfScheduleMATC('scheduleMATC');
	
}

function isMATCorAMTCValid(){

	var statusOfPerson	= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0].value ;
	var panStatus		= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.panNumber')[0].value.substring(3,4);
	
	var flag=true;

	if((panStatus=='C' || panStatus=='G') && (statusOfPerson=='3' || statusOfPerson=='4' )){
	
		var totMatCredUtilCurrYr=coalesce(document.getElementsByName('itr7.scheduleMATC.totMatCredUtilCurrYr')[0].value);
		var amtOfTaxWithCred=coalesce(document.getElementsByName('itr7.scheduleMATC.amtOfTaxWithCred')[0].value);
		
		if(eval(totMatCredUtilCurrYr) > eval(amtOfTaxWithCred)){
		
			flag=false;
			addErrorXHTML('','Sum of MAT credit utilized during the current year is subject to maximum of amount mentioned in 3 above and cannot exceed the sum of MAT Credit Brought Forward',true);
			j.setFieldError('itr7.scheduleMATC.amtOfTaxWithCred','Sum of MAT credit utilized during the current year is subject to maximum of amount mentioned in 3 above and cannot exceed the sum of MAT Credit Brought Forward');
			showPage('page19'); 
		}
		
   }else{
   
		var amtTaxCreditAvailable=coalesce(document.getElementsByName('itr7.itrScheduleAMTC.amtTaxCreditAvailable')[0].value);
		var totAmtCreditUtilisedCY=coalesce(document.getElementsByName('itr7.itrScheduleAMTC.totAmtCreditUtilisedCY')[0].value);
		
		if(eval(totAmtCreditUtilisedCY) > eval(amtTaxCreditAvailable)){
		
			flag=false;
			addErrorXHTML('','Sum of AMT credit utilized during the current year is subject to maximum of amount mentioned in 3 above and cannot exceed the sum of AMT Credit Brought Forward',true);
			j.setFieldError('itr7.itrScheduleAMTC.totAmtCreditUtilisedCY','Sum of AMT credit utilized during the current year is subject to maximum of amount mentioned in 3 above and cannot exceed the sum of AMT Credit Brought Forward.');
                        showPage('page21'); 
		}
   
   }
	
	return flag;

}

function schSIChangeIncome(B1eRemain,A1eRemain,B2eRemain,called) {

	var splRateInc1A = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[0].splRateInc')[0]; splRateInc1A.value = coalesce(splRateInc1A.value);
	var splRateInc22 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[1].splRateInc')[0]; splRateInc22.value = coalesce(splRateInc22.value);
	var splRateInc21 = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[2].splRateInc')[0]; splRateInc21.value = coalesce(splRateInc21.value);
	var exemptionUs111A = coalesce(document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0].value);
	 //splRateInc1A.readOnly=true;
	if((splRateInc1A.old1 !=  A1eRemain || splRateInc1A.old2 !=  exemptionUs111A) && (splRateInc1A.changed!=true|| exemptionUs111A==0)){
		splRateInc1A.old1 = zeroOrMore(A1eRemain);
                splRateInc1A.old2 = exemptionUs111A;
		splRateInc1A.value = zeroOrMore(A1eRemain);
		splRateInc1A.changed=false;
	}
	splRateInc22.value=zeroOrMore(B2eRemain);
	splRateInc21.value=zeroOrMore(B1eRemain);
			
		
if(exemptionUs111A > 0 && splRateInc1A.changed!=true) {
		splRateInc1A.value = '';		
		// and need to make filling up the splRateInc1A value is mandatory and need to put value as blank
	}
        scheduleSiIncome('scheduleSI');
        if(called!='titti') {
        	calculateTiTti('scheduleSI');
        }
}

function converToZeroIfPositive(fieldValue){

	if(eval(fieldValue)>0){
	
		fieldValue=0;
	}
	
	return fieldValue;
}
	
function validatePage(){

	var statusOfPerson	= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0].value ;
	var panStatus		= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.panNumber')[0].value.substring(3,4);
	var pan          	= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.panNumber')[0].value;
	var doi          	= document.getElementsByName('itr7.partAGEN1.orgFirmInfo.dateOFFormOrIncorp')[0].value;
        var resiStatus          = document.getElementsByName('itr7.partAGEN1.filingStatus.residentialStatus')[0].value ;
	var flag			= true;
       

	/*if(resiStatus==undefined || resiStatus =='' || statusOfPerson==undefined || statusOfPerson =='' || statusOfPerson==null || panStatus==undefined || panStatus =='' || panStatus==null || !pan.match('[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}') || doi=='' || doi==null || doi==undefined){
	
		addError('','Please enter the PAN, DOB/DOI, Residential Status and Status',true);
		
		showPage('page2'); 
		
		flag = false;
	}*/
        
        if(flag && panStatusCheck()){   
            
            disableMATorAMT();
            
            flag = isMATCorAMTCValid();

         }else{
             
             flag=false;
         }  
       return flag;
        
}



function addAuditDetails(){
	var b = $('#auditDetailsButton')[0];
	var v = eval($('.auditDetailsRow').last()[0].cells[0].innerHTML);
	var cl = $('.auditDetailsRow').last().clone();
	cl.find(':input').val('');
	var dates = cl.find('.hasDatepicker').removeClass('hasDatepicker');
	var ins = cl.find(':input');
	cl = cl[0];
	b.parentElement.insertBefore(cl,b);
	$('.auditDetailsRow').last()[0].cells[0].innerHTML = (v+1);
	for(var i=0;i<ins.length;i++){
		ins[i].name='itr7.partAGEN2.auditDetails[' + v + ']' + ins[i].name.substr(ins[i].name.lastIndexOf(']')+1);		
		ins[i].id=ins[i].name.replace(/([\.\[\]])/g,'_').replace(/(__)/g,'_');
		var blurAttr=ins[i].getAttribute('onblur');
		if(blurAttr!=null){
			blurAttr=blurAttr+";";
		}else{
			blurAttr="";
		}
		ins[i].setAttribute('onblur',blurAttr+'j.blur(this,this.name,this.value);');
	}
	dates.datepicker({	changeMonth : true,
						changeYear : true,
						yearRange: "-100:+5",
						dateFormat : "dd/mm/yy",
						buttonText : "Choose",
						showOtherMonths : true,
						selectOtherMonths : true
						});
	$('#deleteAuditBtnId').prop('disabled', false);
	var table=document.getElementById('AuditDetails');
	modifyRow(table);
	checkMaxLengthLimit();
}

function delAuditDetails(){
	if($('.auditDetailsRow').length>1){
		if($('.auditDetailsRow').length==2){
			$('#deleteAuditBtnId').prop('disabled', true);
		}
		$('.auditDetailsRow')[0].parentNode.deleteRow($('.auditDetailsRow').length);
	}else{
		$('#deleteAuditBtnId').prop('disabled', true);
	}
	var table=document.getElementById('AuditDetails');
	modifyRow(table);
}

function removeAuditAllDetails(elem){
	if(elem.value!='Y'){
		$('.auditDetailsRow:not(:first)').remove();
		$('.auditDetailsRow').find(':input').val('');
		$('.auditDetailsRow').find(':input').prop('disabled', true);
		$('#auditDetailsButton').find(':button').prop('disabled', true);
		
	}else{
		$('.auditDetailsRow').find(':input').prop('disabled', false);
		$('#auditDetailsButton').find(':button').prop('disabled', false);
		if($('.auditDetailsRow').length==1){
			$('#deleteAuditBtnId').prop('disabled', true);
		}
	}
	
}

/*function validateTCS(tableId){

    var tab = document.getElementById(tableId);
    var allInputTags = tab.getElementsByTagName('input');		
    var totalTCS = parseInt('0' ,10);
    var amtTCSClaimedThisYear = parseInt('0' ,10);
    var amtTCSClaimedThisYearObject = document.getElementsByName('itr7.scheduleTCS.tcsDetails[0].amtTCSClaimedThisYear')[0];

    for(var i = 0; i < allInputTags.length; i++) {
            if (allInputTags[i].name.match("totalTCS$")) {                                    
                    totalTCS =  parseInt( coalesce(allInputTags[i].value) ,10);
                    amtTCSClaimedThisYear =  parseInt( coalesce(allInputTags[i+1].value) ,10);
                    if(amtTCSClaimedThisYear > totalTCS) {
                        
                        allInputTags[i+1].value = (allInputTags[i].value);
                        addErrorXHTML(amtTCSClaimedThisYearObject,'The amount entered in column 5 cannot be greater than column 4',true);
						
                    }
            }
    }	
}*/
function populatePincode(state,pin){

	var stateId = document.getElementsByName(state)[0];
	var pinCode = document.getElementsByName(pin)[0];
	       
	if(stateId.value != '99' && stateId.value != '-1'){	          
		pinCode.value='';
	}else if(stateId.value == '99'){           
		pinCode.value='999999';
	}
}
/*function checkLimitA1eA4() {
    var exemptionUs111A =  document.getElementsByName('itr7.scheduleCG.shortTermCapGain.exemptionUs111A')[0]; exemptionUs111A.value = coalesce(exemptionUs111A.value);
    var balCG = document.getElementsByName('itr7.scheduleCG.shortTermCapGain.otherAsset111AApplicable.balCG')[0]; balCG.value = coalesce(balCG.value);
    
    var splRateInc1A = document.getElementsByName('itr7.scheduleSI.splCodeRateTax[0].splRateInc')[0]; splRateInc1A.value = coalesce(splRateInc1A.value);
    
    var limit = eval(parseInt(balCG.value ,10)) - eval(parseInt(exemptionUs111A.value ,10));
    if(eval(parseInt(splRateInc1A.value,10)) < limit) {
            addError(splRateInc1A, 'Value of Income under the section 111A cannot be less than ' + limit,true);
            //scheduleSiIncome('scheduleSI');
    } else {
        scheduleSiIncome('scheduleSI');
    }
 }*/

function getCurDate() {
	
	var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1;

    var yyyy = today.getFullYear();
    if(dd<10){dd='0'+dd} if(mm<10){mm='0'+mm} 
    
    var today = dd+'/'+mm+'/'+yyyy;
    
    return today;
}

function isFirstDateBeforeOrEqual(firstDate,secondDate) {
	if((firstDate != null && firstDate != '') && (secondDate != null && secondDate != '')){		
		if(eval(firstDate.substring(6,10)) < eval(secondDate.substring(6,10))){
			return true;
		} else if(eval(firstDate.substring(6,10)) == eval(secondDate.substring(6,10))){
			if(eval(firstDate.substring(3,5)) < eval(secondDate.substring(3,5))){
				return true;
			} else if(eval(firstDate.substring(3,5)) == eval(secondDate.substring(3,5))){
				if(eval(firstDate.substring(0,2)) < eval(secondDate.substring(0,2))){
					return true;
				} else {
					return false;
				}
			} else{
				return false;
			}
		} else {
			return false;
		}
	}else{
		return false;
	}
}

function checkSchFAMandatory() {
	if(document.getElementsByName('itr7.partBTTI.assetOutIndiaFlag')[0].value=='YES') {
		var table1 = checkRowBlank('schFADtlsFrignAssets', 2, 1);
		var table2 = checkRowBlank('schFADtlsFinIntrest', 2, 1);
		var table3 = checkRowBlank('schFADtlsImmvbleProp', 2, 1);
		var table4 = checkRowBlank('schFADtlsOtherAsset', 2, 1);
		var table5 = checkRowBlank('schFADtlsSigningAuth', 2, 1);
		var table6 = checkRowBlank('schFADtlsTrusts', 2, 1);
		var table7 = checkRowBlank('DetailsOthIncomeOutsideIndia', 2, 1);
		
		if(table1 && table2 && table3 && table4 && table5 && table6 && table7) {
			j.setFieldError('itr7.scheduleFA.detailsForiegnBank[0].countryCode','Please enter any one table in Schedule FA.');
			addErrorXHTML('','Please enter any one table in Schedule FA.',true);
		}
	}
}

function validateScheduleHP(){
	var tab = document.getElementById('scheduleHPMain');
	var allInputTags = tab.getElementsByTagName('select');
	var count = 0;
	for(var i=0; i<allInputTags.length; i++ ){
		if(allInputTags[i].name.match("ifLetOut$")){
			if(allInputTags[i].value=="N"){
				if(++count > 1){
					j.setFieldError(allInputTags[i].name,'Where there is more than one Self occupied House property(SOP) , one of them shall be treated as SOP and all other House properties shall be deemed to be let out');
					break;
				}
			}
		}
	}
	// To validate 30% of Annual value in Sch HP on Submit
	var totHp=eval(parseInt(document.getElementById('scheduleHPLast').cells[0].textContent)-1);
	var total=0;
    var thirtyPercentOfBalanceTemp = 0;
	var thirtyPercentOfBalance = 0; 
	
	for(var i=0;i<totHp;i++){
		
		thirtyPercentOfBalance = document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.thirtyPercentOfBalance')[0]; 
		
		document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.totalUnrealizedAndTax')[0].value=
			eval(parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.rentNotRealized')[0].value==""?0:coalesceSetRet('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.rentNotRealized'))
			+ parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.localTaxes')[0].value==""?0:coalesceSetRet('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.localTaxes')));
		
		document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.balanceALV')[0].value=
		eval(parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.annualLetableValue')[0].value==""?0:coalesceSetRet('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.annualLetableValue'))-parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.totalUnrealizedAndTax')[0].value==""?0:coalesceSetRet('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.totalUnrealizedAndTax')));
		
		
      	thirtyPercentOfBalanceTemp = zeroOrMore(coalesce(Math.round(eval(parseInt(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.balanceALV')[0].value==""?0:coalesceSetRet('itr7.scheduleHP.propertyDetails['+i+'].rentdetails.balanceALV')) * 0.3 ))));
      	if(coalesce(thirtyPercentOfBalance.value) > parseInt(thirtyPercentOfBalanceTemp ,10) ){
			addErrorXHTML(thirtyPercentOfBalance, 'Amount can not be more than 30% of Annual value i.e, '+thirtyPercentOfBalanceTemp+'.',true);
			j.setFieldError(thirtyPercentOfBalance,'Amount can not be more than 30% of Annual value i.e, '+thirtyPercentOfBalanceTemp+'.');
			
		}
	}
}




function validateTi(){

	
	var grossTotalIncome = document.getElementsByName('itr7.partBTI.grossTotalIncome')[0].value;
	var incChargeTaxSplRate111A112 = document.getElementsByName('itr7.partBTI.incChargeTaxSplRate111A112')[0].value;
	var deductionsUnderScheduleVIA = document.getElementsByName('itr7.partBTI.deductionsUnderScheduleVIA')[0].value;
	if(parseInt(deductionsUnderScheduleVIA, 0) > zeroOrMore(parseInt(grossTotalIncome, 0) - parseInt(incChargeTaxSplRate111A112, 0))){
			j.setFieldError('itr7.partBTI.deductionsUnderScheduleVIA','Deductions under chapter VIA is limited to (21-22)');
			addErrorXHTML(document.getElementsByName('itr7.partBTI.deductionsUnderScheduleVI')[0],'Deductions under chapter VIA is limited to (21-22)',true);
	}
}

function validateOnSubmit(){
	validateTi();
	checkUniqAuditSec();
	checkSchFAMandatory();
	validateScheduleHP();
	
	checkNatureBusFilled();
	checkClaimExMandatory();
	isMATCorAMTCValid();
	validateHPRent();
	calculateTDS();
	calculateTCS();
	validatePage();
	CheckHPShareProperty();
	validateFSI();
	checkUniqueOSSec();
	validateOSSI();
	checkUniqueTableCol('scheduleFSI', 'countryCode$','Same Country cannot be selected more than once.');
	ifscCodeUpperCase();
	schVCAmtCheck();
	setTaxStatusVal();
	checkNoOfRowsFilled();
	//Always keep alertItr7User() as the last method
	alertItr7User();
}

function setTaxStatusVal() {
	var  taxStatus = document.getElementsByName('itr7.partAGEN1.filingStatus.taxStatus')[0];
	
	if(document.getElementsByName('itr7.partBTTI.taxPaid.balTaxPayable')[0].value > 0){
		taxStatus.value = 'TP';
	}else if(document.getElementsByName('itr7.partBTTI.refund.refundDue')[0].value > 0){
		taxStatus.value = 'TR';
	}else{
		taxStatus.value = 'NT';
	}	
}

function validateOSSI(){
	var osmap = {'5BBE':0,'1':0};
	schedueOsCalc(osmap);
	var simap = {};
	getSIMap(simap);
	
	var osSections = Object.keys(osmap);
	var siSections = Object.keys(simap);
	if(osSections.length!=siSections.length){
		if(osSections.length > siSections.length) {
			for(var i=0;i<osSections.length; i++){
				if(!simap[osSections[i]]) {
					j.setFieldError(osmap[osSections[i]].name,"The sections added in Schedule OS must be present in Schedule SI.");
					addErrorXHTML(osmap[osSections[i]],"The sections added in Schedule OS must be present in Schedule SI.");
				}
			}
		} else {
			for(var i=0;i<siSections.length; i++){
				if(!osmap[siSections[i]] && osmap[siSections[i]] != 0) {
					j.setFieldError(simap[siSections[i]].name,"The sections added in Schedule SI must be present in Schedule OS.");
					addErrorXHTML(simap[siSections[i]],"The sections added in Schedule SI must be present in Schedule OS.");
				}
			}
		}
	}
	else{
		for(var i=0;i<osSections.length; i++){
			if(simap[osSections[i]]) {
				if(coalesce(osmap[osSections[i]].value) != coalesce(simap[osSections[i]].value)){
					j.setFieldError(simap[osSections[i]].name,"The special rate income of "+ osSections[i] +" shown in Schedule OS must be shown in Schedule SI or vice versa.");
					addErrorXHTML( simap[osSections[i]],"The special rate income of "+ osSections[i] +" shown in Schedule OS must be shown in Schedule SI or vice versa.");
				}
			} else {
				
					j.setFieldError(osmap[osSections[i]].name,"The special rate income of "+ osSections[i] +" shown in Schedule OS must be shown in Schedule SI or vice versa.");
					addErrorXHTML( osmap[osSections[i]],"The special rate income of "+ osSections[i] +" shown in Schedule OS must be shown in Schedule SI or vice versa.");
				
			}
		}
	}
}

var osSecs = ['5A1ai','5A1aii','5A1aiia','5A1aiiaa','5A1aiiab','5A1aiiac','5A1aiii','FA','5A1bA','5A1bB','5AC1ab','5ACA1a','5AD1i','5AD1iP','5BBA','5BBE','1','5Ea','5AB1a'];

function getSIMap(simap){
	var tabl = document.getElementById('scheduleSI');
	var length = tabl.rows.length-4;
	for(var i = 0; i < length; i++) {
		var sec = document.getElementsByName('itr7.scheduleSI.splCodeRateTax['+ i +'].secCode')[0];
		if(osSecs.indexOf(sec.value)!=-1){
			simap[sec.value] = document.getElementsByName('itr7.scheduleSI.splCodeRateTax['+i+'].splRateInc')[0];
		}
	}	
}

function setSerialNumber(element,header){
	try{
	
	 var tableId=element.getAttribute('onclick').substring(20,element.getAttribute('onclick').lastIndexOf('\''));

	  var index=tableId.substring(10);
	  
	  index=eval(index-1);

	var table = document.getElementById(tableId);
	var noOfRows = table.rows.length;

	for ( var i = 0; i < eval(parseInt(noOfRows, 10) - header); i++) {
	
		document.getElementsByName('itr7.scheduleHP.propertyDetails['+index+'].coOwners['+i+'].coOwnersSNo')[0].value=i+1;

		
	}
	}catch(e){
	alert('errror:' +e);
	}
	
}

function checkAMT(){
	if(document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0].value =="3" ||
		document.getElementsByName('itr7.partAGEN1.orgFirmInfo.statusOrCompanyType')[0].value =="4"){
		
		document.getElementsByName('itr7.itrScheduleAMT.adjustmentSec115JC.deductClaimSec6A')[0].value='0';
		document.getElementsByName('itr7.itrScheduleAMT.adjustmentSec115JC.deductClaimSec10AA')[0].value='0';
		
		document.getElementsByName('itr7.itrScheduleAMT.adjustmentSec115JC.deductClaimSec6A')[0].readOnly = true;
		document.getElementsByName('itr7.itrScheduleAMT.adjustmentSec115JC.deductClaimSec10AA')[0].readOnly = true;
	}else{
		document.getElementsByName('itr7.itrScheduleAMT.adjustmentSec115JC.deductClaimSec6A')[0].readOnly = false;
		document.getElementsByName('itr7.itrScheduleAMT.adjustmentSec115JC.deductClaimSec10AA')[0].readOnly = false;
	}
}

function prefixZero(){
	var tabl = document.getElementById('AuditDetails');
	var allInputTags = tabl.getElementsByTagName('input');
	
	for(i=0; i<allInputTags.length; i++) {
		if(document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value.length==5){
			document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value = 
				'0'+document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value ;
		} else if(document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value.length==4){
			document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value = 
				'00'+document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value ;
		} else if(document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value.length==3){
			document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value = 
				'000'+document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value ;
		} else if(document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value.length==2){
			document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value = 
				'0000'+document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value ;
		} else if(document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value.length==1){
			document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value = 
				'00000'+document.getElementsByName('itr7.partAGEN2.auditDetails['+i+'].auditorMemNo')[0].value ;
		}
	}
}

function checkNatureBusFilled(){
	var incUnderHBP=document.getElementsByName('itr7.partaoi.incUnHeadBPFlag')[0].value;
	var natBusFilled= checkNatureBusRowBlank('natOfBustTradeTableId', 1, 1);
	
	if(incUnderHBP=='Y' && natBusFilled){
		addErrorXHTML('','Please provide atleast one detail for nature of business or profession',true);
		j.setFieldError('itr7.partaoi.natOfBus.business[0].code','Please provide atleast one detail for nature of business or profession');
		
	}	
}

function checkNatureBusRowBlank(tableId, noOfRow, last){
	var tab = document.getElementById(tableId);
	var rowCount = tab.rows.length;

	var allSelectTags = tab.getElementsByTagName('select');
	var isRowBlank = true;

	for ( var i = 0; i < (parseInt(rowCount,10)-2); i++) {
		if(allSelectTags[i].name.match("code$")){

		if(isRowBlank && allSelectTags[i].value != '-1' && allSelectTags[i].value != ''){

			isRowBlank = false;

			break;
		}
		}
	}
	return isRowBlank;
}

function checkClaimExMandatory(){
	
	//var partBiFilled= checkRowBlank('otherDetailsUs10I', 2, 1);
	var partBiiFilled=checkRowBlank('otherDetailsUs10II', 2, 1);
	var exemptionUs10Flag=document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs10.exemptionUs10Flag')[0].value;

	if(exemptionUs10Flag=='Y' && partBiiFilled ){
		
		j.setFieldError('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs10.otherDetailsUs10II[0].section','Please provide details for either B(i) or B(ii)');
		addErrorXHTML('','Please provide details for either B(i)',true);
	}
	
}

function calculateTax(){
	clearOldValues();
	calculateTiTti('netAgricultureIncomeOrOtherIncomeForRate');
}

function validateHPRent(){
    
	var tab=document.getElementById('scheduleHPMain');
	var allInputTags = tab.getElementsByTagName('input');
	var selectTags=tab.getElementsByTagName('select');
		
	for(var i = 0; i < allInputTags.length; i++) {
		if (allInputTags[i].name.match("rentdetails.annualLetableValue$")) {
				if( parseInt(allInputTags[i+1].value,10) > parseInt(allInputTags[i].value ,10)) {
					
					addErrorXHTML(allInputTags[i+1],   
							'Rent not realized cannot exceed Annual Letable Value',true);
						j.setFieldError(allInputTags[i+1].name,'Rent not realized cannot exceed Annual Letable Value');
						break;
				}					
		}
	}
	
}


function getPan(){

var pan = document.getElementsByName('itr7.partAGEN1.orgFirmInfo.panNumber')[0].value;
return pan;
}

function isLetOutEnable() {
	var totHp = eval(parseInt(document.getElementById('scheduleHPLast').cells[0].textContent) - 1);
	for ( var i = 0; i < totHp; i++) {
		var tempName = 'itr7.scheduleHP.propertyDetails[' + i + '].ifLetOut';
		var val = document.getElementsByName(tempName)[0].value;

		if (val == 'Y') {

			$('#scheduleHPTenant' + eval(parseInt(i) + 1)).find(':input').prop(
					'disabled', false);
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].coTenants[0].coTenantsSNo')[0].value = 1;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.annualLetableValue')[0].disabled = false;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.rentNotRealized')[0].disabled = false;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.localTaxes')[0].disabled = false;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.incomeChargbleOwnHands')[0].disabled = true;
		} else if (val == 'D') {
			$('#scheduleHPTenant' + eval(parseInt(i) + 1)).find(
					'[type=\"checkbox\"]').attr('checked', 'checked');
			deleteRowTable('scheduleHPTenant' + eval(parseInt(i) + 1), 1, 1);
			$('#scheduleHPTenant' + eval(parseInt(i) + 1)).find(':input').prop(
					'disabled', true);
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.annualLetableValue')[0].disabled = false;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.rentNotRealized')[0].disabled = false;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.localTaxes')[0].disabled = false;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.incomeChargbleOwnHands')[0].disabled = true;
		} else {

			$('#scheduleHPTenant' + eval(parseInt(i) + 1)).find(
					'[type=\"checkbox\"]').attr('checked', 'checked');
			deleteRowTable('scheduleHPTenant' + eval(parseInt(i) + 1), 1, 1);
			$('#scheduleHPTenant' + eval(parseInt(i) + 1)).find(':input').prop(
					'disabled', true);

			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.annualLetableValue')[0].disabled = true;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.annualLetableValue')[0].value = '';
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.rentNotRealized')[0].disabled = true;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.rentNotRealized')[0].value = '';
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.localTaxes')[0].disabled = true;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.localTaxes')[0].value = '';
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.incomeChargbleOwnHands')[0].disabled = true;
			document.getElementsByName('itr7.scheduleHP.propertyDetails[' + i
					+ '].rentdetails.incomeChargbleOwnHands')[0].value = '';
		}

	}

}

function numberOfCoOwnersCheck(tableId,noRows){
	var tab = document.getElementById(tableId);
	var rowCount = tab.rows.length;
	if(rowCount > noRows) {
	addErrorXHTML('','Cannot insert more than 5 rows',true);
	return false;
	}
	return true;

}

function addRowToTableSchHp(tableId, noOfRow, last,elem) {
	
		addRowToTable(tableId,noOfRow,last);
		setSerialNumber(elem,2);
	
}

function calcScheduleFSI(){
	try{
		var table=document.getElementById('scheduleFSI');
	        var noOfRows=table.rows.length;
	        var indexValue=eval(((parseInt(noOfRows,10)-4)/5));
	      
	        for(var i=0;i<indexValue;i++){
	            
	            document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].totalCountryWise.incFrmOutsideInd")[0].value=
	                 eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromHP.incFrmOutsideInd")[0].value),10))+
	                     eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromBusiness.incFrmOutsideInd")[0].value),10))+
	                         eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incCapGain.incFrmOutsideInd")[0].value),10))+
	                         eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incOthSrc.incFrmOutsideInd")[0].value),10));
	                    
	                    
	                    
	                    
	              document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].totalCountryWise.taxPaidOutsideInd")[0].value=
	                 eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromHP.taxPaidOutsideInd")[0].value),10))+
	                     eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromBusiness.taxPaidOutsideInd")[0].value),10))+
	                         eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incCapGain.taxPaidOutsideInd")[0].value),10))+
	                         eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incOthSrc.taxPaidOutsideInd")[0].value),10));
	                    
	                    
	                    
	                    
	                   document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].totalCountryWise.taxPayableinInd")[0].value=
	                 eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromHP.taxPayableinInd")[0].value),10))+
	                     eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromBusiness.taxPayableinInd")[0].value),10))+
	                         eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incCapGain.taxPayableinInd")[0].value),10))+
	                        eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incOthSrc.taxPayableinInd")[0].value),10));
	                    
	                
	                   if(eval(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromHP.taxPaidOutsideInd")[0].value)<
	                    eval(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromHP.taxPayableinInd")[0].value)){
	                 document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromHP.taxReliefinInd")[0].value=
	                     document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromHP.taxPaidOutsideInd")[0].value;
	                    }else{
	                         document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromHP.taxReliefinInd")[0].value=
	                             document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromHP.taxPayableinInd")[0].value;
	                    }
	                    
	                    
	                         if(eval(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromBusiness.taxPaidOutsideInd")[0].value)<
	                    eval(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromBusiness.taxPayableinInd")[0].value)){
	                 document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromBusiness.taxReliefinInd")[0].value=
	                     document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromBusiness.taxPaidOutsideInd")[0].value;
	                    }else{
	                         document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromBusiness.taxReliefinInd")[0].value=
	                             document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromBusiness.taxPayableinInd")[0].value;
	                    }
	                    
	                    
	                         if(eval(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incCapGain.taxPaidOutsideInd")[0].value)<
	                    eval(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incCapGain.taxPayableinInd")[0].value)){
	                 document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incCapGain.taxReliefinInd")[0].value=
	                     document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incCapGain.taxPaidOutsideInd")[0].value;
	                    }else{
	                         document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incCapGain.taxReliefinInd")[0].value=
	                             document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incCapGain.taxPayableinInd")[0].value;
	                    }
	                    
	                       if(eval(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incOthSrc.taxPaidOutsideInd")[0].value)<
	                    eval(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incOthSrc.taxPayableinInd")[0].value)){
	                 document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incOthSrc.taxReliefinInd")[0].value=
	                     document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incOthSrc.taxPaidOutsideInd")[0].value;
	                    }else{
	                         document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incOthSrc.taxReliefinInd")[0].value=
	                             document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incOthSrc.taxPayableinInd")[0].value;
	                    }
	                    
	                    
	                    document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].totalCountryWise.taxReliefinInd")[0].value=
	                 eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromHP.taxReliefinInd")[0].value),10))+
	                     eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incFromBusiness.taxReliefinInd")[0].value),10))+
	                         eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incCapGain.taxReliefinInd")[0].value),10))+
	                         eval(parseInt(coalesce(document.getElementsByName("itrScheduleFSI.scheduleFSI["+i+"].incOthSrc.taxReliefinInd")[0].value),10));
	        }
	        populateTR();
		}catch(e){
			alert('error in calcScheduleFSI = '  +e.stack);
		}
}

function addRowSchedFSIFor2(nocheck){
	
	var mainTable=document.getElementById('scheduleFSI').rows;
	var noOfRows=mainTable.length;
	
	var tobeInsertBefore=document.getElementById('scheduleFSIAddRow');
	var flag=true;
	var checkFirst=true;
	var totRow=document.getElementById('scheduleFSIFirst').cells[0].textContent;
	
	var iterate=eval(parseInt(totRow,10));
	
	var indexValue=eval(((parseInt(noOfRows,10)-4)/5)+1);
	
	var isRowBlank = true;
	for(var i=0;i<6;i++){
		if(!checkRowBlank('scheduleFSI', (3+i), 0)){
			isRowBlank = false;
			break;
		}
	}
	
	if(!isRowBlank || nocheck){
	
	for(var i=2;i<mainTable.length;i++){
	var cloneNode=mainTable[i].cloneNode(true);
        if(flag){
		var cellsTot=cloneNode.cells;
		var newVal=eval(parseInt(totRow)+1);
		if(checkFirst){
		iterate=eval(indexValue-1);
		
		cloneNode.cells[0].innerHTML=indexValue;
		checkFirst=false;
		}
		
                //Numbering
		var inputTags=cloneNode.getElementsByTagName('input');
		for(var a=0;a<inputTags.length;a++){
			inputTags[a].name=inputTags[a].name.replace('[0]','['+iterate+']');
			
                        inputTags[a].id=inputTags[a].name.replace(/([\.\[\]])/g,'_').replace(/(__)/g,'_');
                        inputTags[a].value='';
                        var blurAttr=inputTags[a].getAttribute('onblur');
            			if(blurAttr!=null){
            				blurAttr=blurAttr+";";
            			}else{
            				blurAttr="";
            			}
            			inputTags[a].setAttribute('onblur',blurAttr+'j.blur(this,this.name,this.value);');
		}
		
		var selectTags=cloneNode.getElementsByTagName('select');
		for(var a=0;a<selectTags.length;a++){
			selectTags[a].name=selectTags[a].name.replace('[0]','['+iterate+']');
			selectTags[a].value='';
			
                        selectTags[a].id=selectTags[a].name.replace(/([\.\[\]])/g,'_').replace(/(__)/g,'_');
                        
                        var blurAttr=selectTags[a].getAttribute('onblur');
            			if(blurAttr!=null){
            				blurAttr=blurAttr+";";
            			}else{
            				blurAttr="";
            			}
            			selectTags[a].setAttribute('onblur',blurAttr+'j.blur(this,this.name,this.value);');
		}
		
	
		
		document.getElementById('scheduleFSI').getElementsByTagName('tr')[0].parentNode.insertBefore(cloneNode,tobeInsertBefore);
            }
            if(mainTable[i].id =='scheduleFSIEnd'){
		flag=false;
		break;
		}
        }
	if($('#scheduleFSIAddRow')[0].parentNode.children.length==10){
		$('#delFSIButtonId').prop('disabled', true);
	}else if($('#scheduleFSIAddRow')[0].parentNode.children.length>10){
		$('#delFSIButtonId').prop('disabled', false);
	}
	
	}else{
		addErrorXHTML('', 'Please fill in all the mandatory fields in the last row before adding another row.');
	}
       
}

function validateFSI(){
	var table=document.getElementById('scheduleFSI');
    var noOfRows=table.rows.length;
    var indexValue=eval(((parseInt(noOfRows,10)-4)/5));
    var empty2,empty3,empty4;
    for(var i=0;i<indexValue;i++){	
		if(document.getElementsByName('itr7.partAGEN1.filingStatus.claimUs9090A91Flag')[0].value=='YES' || document.getElementsByName('itrScheduleFSI.scheduleFSI['+i+'].countryCode')[0].value!=''){
		var empty = true;
			var errors = ['Income from outside India(included in PART B-TI) is required',
			              'Tax paid outside India is required',
						  'Tax payable on such income under normal provisions in India is required',
			              'Relevant article of DTAA if relief claimed u/s 90 or 90A is required'];
			empty2 = empty && !validateAllFilled(['itrScheduleFSI.scheduleFSI['+i+'].incFromHP.incFrmOutsideInd',
			                                     'itrScheduleFSI.scheduleFSI['+i+'].incFromHP.taxPaidOutsideInd',
			                                     'itrScheduleFSI.scheduleFSI['+i+'].incFromHP.taxPayableinInd',
			                                     'itrScheduleFSI.scheduleFSI['+i+'].incFromHP.dtaaReliefUs90or90A'],errors);
			empty3 = empty && !validateAllFilled(['itrScheduleFSI.scheduleFSI['+i+'].incCapGain.incFrmOutsideInd',
			                                     'itrScheduleFSI.scheduleFSI['+i+'].incCapGain.taxPaidOutsideInd',
			                                     'itrScheduleFSI.scheduleFSI['+i+'].incCapGain.taxPayableinInd',
			                                     'itrScheduleFSI.scheduleFSI['+i+'].incCapGain.dtaaReliefUs90or90A'],errors);
			empty4 = empty && !validateAllFilled(['itrScheduleFSI.scheduleFSI['+i+'].incOthSrc.incFrmOutsideInd',
			                                     'itrScheduleFSI.scheduleFSI['+i+'].incOthSrc.taxPaidOutsideInd',
			                                     'itrScheduleFSI.scheduleFSI['+i+'].incOthSrc.taxPayableinInd',
			                                     'itrScheduleFSI.scheduleFSI['+i+'].incOthSrc.dtaaReliefUs90or90A'],errors);
			empty5 = empty && !validateAllFilled(['itrScheduleFSI.scheduleFSI['+i+'].incFromBusiness.incFrmOutsideInd',
			                                     'itrScheduleFSI.scheduleFSI['+i+'].incFromBusiness.taxPaidOutsideInd',
			                                     'itrScheduleFSI.scheduleFSI['+i+'].incFromBusiness.taxPayableinInd',
			                                     'itrScheduleFSI.scheduleFSI['+i+'].incFromBusiness.dtaaReliefUs90or90A'],errors);
			if(empty2&&empty3&&empty4&&empty5){
	            j.setFieldError('itrScheduleFSI.scheduleFSI['+i+'].incFromHP.incFrmOutsideInd','Please fill atleast one income, as you have selected claim under section 90/90A/91');
	            addErrorXHTML(document.getElementsByName('itrScheduleFSI.scheduleFSI['+i+'].incFromHP.incFrmOutsideInd')[0],'Please fill atleast one income',true);
			}
		}
    }
}


function validateAllFilled(fieldNames,errors){
	var fields = [];
	var filled = 0;
	for(var i=0; i<fieldNames.length; i++){
		fields[i] = document.getElementsByName(fieldNames[i])[0];
		if(fields[i].value!='' && fields[i].value!=undefined){
			filled++;
		}
	}
	if(filled>0){
		for(var i=0; i<fieldNames.length; i++){
			if(fields[i].value=='' || fields[i].value==undefined){
				if(i==fieldNames.length-1){
					if(Math.min(coalesce(fields[1].value),coalesce(fields[2].value)) == parseInt(0)){
						continue;
					}
				}
	            j.setFieldError(fieldNames[i],errors[i]);
	            addErrorXHTML(fields[i],errors[i],true);
	            break;
			}
		}		
		return true;
	}
	return false;
}

function scheduleFSIAlert()
{
   var tableFSI = checkRowBlank('scheduleFSI', 8, 2);
   if(tableFSI==false){
   
   addErrorXHTML('','Please ensure that the incomes shown in Schedule FSI  are also reflected under respective income schedules.');
  
  }

}

function deleteRowFSI(tableId , noOfHeader , noOfFooter){
	try{
		var mytable = document.getElementById(tableId);
		var rowCount = mytable.rows.length;
		var itemCount = (rowCount - 4 )/ 5;
		noOfHeader = parseInt(noOfHeader , 10);
		var isChecked=false;
		var listOfCheckBox = mytable.getElementsByTagName('input');
		var totalChecked = 0;
		for(var z=0; z<listOfCheckBox.length; z++){
			if(listOfCheckBox[z].name.match(".chosenCheckBox$")){
				if(listOfCheckBox[z].checked==true){
					totalChecked = eval( parseInt(totalChecked,10) +1);
					isChecked=true;
				}
			}
		}
		if(!isChecked){
			addErrorXHTML('','Please select a checkbox for deleting row');
		}

		for(var j=1; j<=totalChecked ; j++){      // iterate for total number of checkboxes
			var totalNoOfInput = mytable.getElementsByTagName('input');

			for(var z=0; z<totalNoOfInput.length; z++){
				if(totalNoOfInput[z].name.match(".chosenCheckBox$")){		// if its a chosenCheckBox element

					var akhilIndex1 = eval(parseInt(totalNoOfInput[z].name.lastIndexOf('[') ,10)+1);
					var akhilIndex2 = eval(parseInt(totalNoOfInput[z].name.lastIndexOf(']') ,10));
					var rowNumber = totalNoOfInput[z].name.substring(akhilIndex1, akhilIndex2);
					rowNumber = parseInt(rowNumber ,10);
					
					var myCurrtable = document.getElementById(tableId);
					var rowCurrCount = myCurrtable.rows.length;

					
					if(totalNoOfInput[z].checked==true){
						if((rowNumber!=0) || (rowNumber==0 &&  parseInt(eval(rowCurrCount-noOfHeader-noOfFooter)/5)>1) ){
							rowNumber = eval(parseInt(rowNumber,10) * 5 + noOfHeader);
							for(var i=0;i<5;i++){
								mytable.deleteRow(rowNumber);
							}
							//To Do - reset the name of row for all input , textarea, select
							var newTrList = mytable.getElementsByTagName('tr');
							var newTrListLength = eval(parseInt(newTrList.length ,10)-noOfFooter);
							for( var q=rowNumber; q < newTrListLength ; q++ ){	//iterate over all rows from delete point to second last row
								var p = parseInt((q-noOfHeader) /5) + noOfHeader;
								//set the serial number;
								if((q-noOfHeader)%5==0){
									if(noOfHeader==2){
										newTrList[q].getElementsByTagName('td')[0].innerHTML = parseInt(p-1,10);
									}else if(noOfHeader==1){
										newTrList[q].getElementsByTagName('td')[0].innerHTML = parseInt(p,10);
									}else if(noOfHeader==3){
										newTrList[q].getElementsByTagName('td')[0].innerHTML = parseInt(p-2,10);
									}
								}
								var allInputTags = newTrList[q].getElementsByTagName('input');

								for(var zz=0; zz<allInputTags.length ; zz++ ){
									var index1= allInputTags[zz].name.lastIndexOf('[');
									var index2= allInputTags[zz].name.lastIndexOf(']');

									var str1 = allInputTags[zz].name.substring(0, index1);
									var str3 = allInputTags[zz].name.substring(index2 + 1, allInputTags[zz].name.length);

									allInputTags[zz].name = str1+'[' +eval(parseInt(p,10)-noOfHeader) +']'+str3;
								}

								var allSelectTags = newTrList[q].getElementsByTagName('select');

								for(var zz=0; zz<allSelectTags.length ; zz++ ){
									var index1= allSelectTags[zz].name.lastIndexOf('[');
									var index2= allSelectTags[zz].name.lastIndexOf(']');

									var str1 = allSelectTags[zz].name.substring(0, index1);
									var str3 = allSelectTags[zz].name.substring(index2 + 1, allSelectTags[zz].name.length);

									allSelectTags[zz].name = str1+'[' +eval(parseInt(p,10)-noOfHeader) +']'+str3;
								}

								var allTextAreaTags = newTrList[q].getElementsByTagName('textarea');

								for(var zz=0; zz<allTextAreaTags.length ; zz++ ){
									var index1= allTextAreaTags[zz].name.lastIndexOf('[');
									var index2= allTextAreaTags[zz].name.lastIndexOf(']');

									var str1 = allTextAreaTags[zz].name.substring(0, index1);
									var str3 = allTextAreaTags[zz].name.substring(index2 + 1, allTextAreaTags[zz].name.length);

									allTextAreaTags[zz].name = str1+'[' +eval(parseInt(p,10)-noOfHeader) +']'+str3;
								}
							}
							break;
						}else if((rowNumber==0)  && (parseInt(eval(rowCurrCount-noOfHeader-noOfFooter)/5)==1)){
							//Vacate the content if its first row

							for(var m=0; m<5; m++){ 
								var firstRow = mytable.getElementsByTagName('tr')[parseInt(noOfHeader) + m];
	
								var firstInputBox = firstRow.getElementsByTagName('input')[0];
								firstInputBox.checked = false;
	
								var allInputTags = firstRow.getElementsByTagName('input');
								for ( var i = 0; i < allInputTags.length; i++) {
									allInputTags[i].value = "";
								}
								var allSelectTags = firstRow.getElementsByTagName('select');
								for ( var i = 0; i < allSelectTags.length; i++) {
									var elem = allSelectTags[i];
									elem[0].selected = true;
								}
								var allTextAreaTags = firstRow.getElementsByTagName('textarea');
								for ( var i = 0; i < allTextAreaTags.length; i++) {
									allTextAreaTags[i].value = "";
								}
							}
						}
					}
				}
			}
		}
		//modifyRow(mytable);
	}catch(e){
		alert('exception caught in =' +e.stack );
	}
}

function populateTR() {
	try {
		deleteTRRow();
		var fsiTable = document.getElementById('scheduleFSI');
		var noRows = (fsiTable.rows.length-4)/5;
		var pos = document.getElementsByName('itrScheduleFSI.scheduleFSI[0].countryCode')[0].selectedIndex;
		
		document.getElementsByName('scheduleTR1.scheduleTR[0].countryCode')[0].value = document.getElementsByName('itrScheduleFSI.scheduleFSI[0].countryCode')[0].value;
		document.getElementsByName('scheduleTR1.scheduleTR[0].countryName')[0].value = document.getElementsByName('itrScheduleFSI.scheduleFSI[0].countryName')[0].value;
		
		if(document.getElementsByName('itrScheduleFSI.scheduleFSI[0].countryCode')[0].options[pos].text=="Select") {
			document.getElementsByName('scheduleTR1.scheduleTR[0].countryCodeName')[0].value = '';
		} else {
			document.getElementsByName('scheduleTR1.scheduleTR[0].countryCodeName')[0].value = document.getElementsByName('itrScheduleFSI.scheduleFSI[0].countryCode')[0].options[pos].text;
		}
		
		document.getElementsByName('scheduleTR1.scheduleTR[0].taxIdentificationNo')[0].value = document.getElementsByName('itrScheduleFSI.scheduleFSI[0].taxIdentificationNo')[0].value;
		document.getElementsByName('scheduleTR1.scheduleTR[0].taxPaidOutsideIndia')[0].value = document.getElementsByName('itrScheduleFSI.scheduleFSI[0].totalCountryWise.taxPaidOutsideInd')[0].value;
		document.getElementsByName('scheduleTR1.scheduleTR[0].taxReliefOutsideIndia')[0].value = document.getElementsByName('itrScheduleFSI.scheduleFSI[0].totalCountryWise.taxReliefinInd')[0].value;
		
		var firstSecCode = document.getElementsByName('scheduleTR1.scheduleTR[0].countryCodeName')[0].value+'_'+document.getElementsByName('scheduleTR1.scheduleTR[0].taxIdentificationNo')[0].value;
		
		document.getElementsByName('scheduleTR1.scheduleTR[0].relavantArticleDTAA')[0].value=sectionClaimed[firstSecCode];
		
		if(noRows>1) {
			
			var countryCodeName='';
			var taxIdentificationNo='';
			var taxPaidOutsideIndia='';
			var taxReliefOutsideIndia='';

			for(var i=1;i<noRows;i++) {
				var index = document.getElementsByName('itrScheduleFSI.scheduleFSI['+i+'].countryCode')[0].selectedIndex;
				
				countryCodeName = document.getElementsByName('itrScheduleFSI.scheduleFSI['+i+'].countryCode')[0].options[index].text;
				
				if(countryCodeName=="Select"){
					countryCodeName = '';
				}
				
				taxIdentificationNo = document.getElementsByName('itrScheduleFSI.scheduleFSI['+i+'].taxIdentificationNo')[0].value;
				taxPaidOutsideIndia = document.getElementsByName('itrScheduleFSI.scheduleFSI['+i+'].totalCountryWise.taxPaidOutsideInd')[0].value;
				taxReliefOutsideIndia = document.getElementsByName('itrScheduleFSI.scheduleFSI['+i+'].totalCountryWise.taxReliefinInd')[0].value;
				
				addSchTRRow(countryCodeName,taxIdentificationNo,taxPaidOutsideIndia,taxReliefOutsideIndia);
				
				var countryCode=document.getElementsByName('scheduleTR1.scheduleTR['+i+'].countryCode')[0];
				var countryName=document.getElementsByName('scheduleTR1.scheduleTR['+i+'].countryName')[0];
				
				countryCode.value = document.getElementsByName('itrScheduleFSI.scheduleFSI['+i+'].countryCode')[0].value;
				countryName.value = document.getElementsByName('itrScheduleFSI.scheduleFSI['+i+'].countryName')[0].value;
				
				
				document.getElementsByName('scheduleTR1.scheduleTR['+i+'].relavantArticleDTAA')[0].value = sectionClaimed[countryCodeName+'_'+taxIdentificationNo];
					
				
			}
			
		}
		
		totAmtOfSchedTR('scheduleTR');
	} catch (e) {
		alert('Error in populateTR:' + e);
	}

}
var sectionClaimed = {};
function deleteTRRow() {
	try {
		var trTable = document.getElementById('scheduleTR');
		var noRows = trTable.rows.length;
		
		if (parseInt(noRows, 10) > 4) {
			for ( var i = 2; i < parseInt(noRows, 10) - 3; i++) {
				var countryCode = document.getElementsByName('scheduleTR1.scheduleTR['+(i-1)+'].countryCodeName')[0];
				var taxIdentificationNo = document.getElementsByName('scheduleTR1.scheduleTR['+(i-1)+'].taxIdentificationNo')[0];
				sectionClaimed[countryCode.value+'_'+taxIdentificationNo.value] = document.getElementsByName('scheduleTR1.scheduleTR['+(i-1)+'].relavantArticleDTAA')[0].value;
				trTable.deleteRow(3);
			}
		}
		sectionClaimed[document.getElementsByName('scheduleTR1.scheduleTR[0].countryCodeName')[0].value+'_'+document.getElementsByName('scheduleTR1.scheduleTR[0].taxIdentificationNo')[0].value] = document.getElementsByName('scheduleTR1.scheduleTR[0].relavantArticleDTAA')[0].value;
		
		document.getElementsByName('scheduleTR1.scheduleTR[0].countryCode')[0].value='';
		document.getElementsByName('scheduleTR1.scheduleTR[0].taxIdentificationNo')[0].value='';
		document.getElementsByName('scheduleTR1.scheduleTR[0].taxPaidOutsideIndia')[0].value='';
		document.getElementsByName('scheduleTR1.scheduleTR[0].taxReliefOutsideIndia')[0].value='';
		 

	} catch (e) {
		alert('Error in deleteTRRow:' + e);
	}
}

function addSchTRRow(countryCodeName, taxIdentificationNo, taxPaidOutsideIndia,taxReliefOutsideIndia) {
	try {
		var tableId = document.getElementById('scheduleTR');
		var mainTable = document.getElementById('scheduleTR').rows;
		var noOfRows = tableId.rows.length;
		var toInsertBefore = document.getElementById('scheduleTRLastRow');

		var lastIndex = eval(parseInt(noOfRows, 10) - 3);

		var cloneNode = mainTable[lastIndex].cloneNode(true);
		var newSlNo = cloneNode.cells[0].textContent;

		var iterate = eval(parseInt(newSlNo, 10) - 1);

		cloneNode.cells[0].innerHTML = eval(parseInt(newSlNo, 10) + 1);
		var inputTags = cloneNode.getElementsByTagName('input');
		var selectTags = cloneNode.getElementsByTagName('select');
		for ( var a = 0; a < inputTags.length; a++) {
			inputTags[a].name = inputTags[a].name.replace('[' + iterate + ']','[' + (lastIndex - 1) + ']');

			inputTags[a].id = inputTags[a].name.replace(/([\.\[\]])/g, '_').replace(/(__)/g, '_');

			inputTags[0].value = countryCodeName;

			inputTags[3].value = taxIdentificationNo;

			inputTags[4].value = parseInt(taxPaidOutsideIndia, 10);
			inputTags[5].value = parseInt(taxReliefOutsideIndia, 10);

			var blurAttr = inputTags[a].getAttribute('onblur');
			if (blurAttr != null) {
				blurAttr = blurAttr + ";";
			} else {
				blurAttr = "";
			}
			inputTags[a].setAttribute('onblur', blurAttr+ 'j.blur(this,this.name,this.value);');
		}

		for ( var a = 0; a < selectTags.length; a++) {
			selectTags[a].name = selectTags[a].name.replace('[' + iterate + ']', '[' + (lastIndex - 1) + ']');
			selectTags[a].id = selectTags[a].name.replace(/([\.\[\]])/g, '_').replace(/(__)/g, '_');
			
			var blurAttr = inputTags[a].getAttribute('onblur');
			if (blurAttr != null) {
				blurAttr = blurAttr + ";";
			} else {
				blurAttr = "";
			}
			selectTags[a].setAttribute('onblur', blurAttr+ 'j.blur(this,this.name,this.value);');
		}
		document.getElementById('scheduleTR').getElementsByTagName('tr')[0].parentNode.insertBefore(cloneNode, toInsertBefore);
		
	} catch (e) {
		alert('addSchTRRow' + e);
	}
}

function schTRonLoad() {
	
	var fsiTable = document.getElementById('scheduleFSI');
	var noRows = (fsiTable.rows.length-4)/5;
	
	for(var i=0;i<noRows;i++) {
		var index = document.getElementsByName('itrScheduleFSI.scheduleFSI['+i+'].countryCode')[0].selectedIndex;
		var countryCodeName = document.getElementsByName('scheduleTR1.scheduleTR['+i+'].countryCodeName')[0];
		
		countryCodeName.value = document.getElementsByName('itrScheduleFSI.scheduleFSI['+i+'].countryCode')[0].options[index].text;
		
		if(countryCodeName.value == "Select"){
			countryCodeName.value = '';
		}
	}
	totAmtOfSchedTROnLoad();
}

function totAmtOfSchedTROnLoad(){
	
	var table=document.getElementById('scheduleTR');
    var noOfRows=table.rows.length;
    var totTaxPaidOutsideInd = parseInt('0' ,10);
	var totReliefAvailable = parseInt('0' ,10);
      
    for(var i=0;i<eval(parseInt(noOfRows,10)-4);i++){
        
        totTaxPaidOutsideInd = eval(parseInt(totTaxPaidOutsideInd,10) + parseInt(coalesce(document.getElementsByName('scheduleTR1.scheduleTR['+i+'].taxPaidOutsideIndia')[0].value,10)));
        totReliefAvailable = eval(parseInt(totReliefAvailable,10) + parseInt(coalesce(document.getElementsByName('scheduleTR1.scheduleTR['+i+'].taxReliefOutsideIndia')[0].value,10)));
    
    }
    
    document.getElementsByName('scheduleTR1.totTaxPaidDeclaredInFSI')[0].value = totTaxPaidOutsideInd;
    document.getElementsByName('scheduleTR1.totReliefClaimUs9090A')[0].value = totReliefAvailable;
    
}

function totAmtOfSchedTR(){
	
	var table=document.getElementById('scheduleTR');
    var noOfRows=table.rows.length;
    var totTaxPaidOutsideInd = parseInt('0' ,10);
	var totReliefAvailable = parseInt('0' ,10);
	var totReliefAvailable9090A = parseInt('0' ,10);
	var totReliefAvailable91 = parseInt('0' ,10);
      
    for(var i=0;i<eval(parseInt(noOfRows,10)-4);i++){
        if(document.getElementsByName('scheduleTR1.scheduleTR['+i+'].relavantArticleDTAA')[0].value=='91'){
        	totReliefAvailable91=eval(totReliefAvailable91+ parseInt(coalesce(document.getElementsByName('scheduleTR1.scheduleTR['+i+'].taxReliefOutsideIndia')[0].value),10));
        
        } else if(document.getElementsByName('scheduleTR1.scheduleTR['+i+'].relavantArticleDTAA')[0].value=='90' ||
	        document.getElementsByName('scheduleTR1.scheduleTR['+i+'].relavantArticleDTAA')[0].value=='90A'){
        	totReliefAvailable9090A=eval(totReliefAvailable9090A+parseInt(coalesce(document.getElementsByName('scheduleTR1.scheduleTR['+i+'].taxReliefOutsideIndia')[0].value),10));
        }
        
        totTaxPaidOutsideInd = eval(parseInt(totTaxPaidOutsideInd,10) + parseInt(coalesce(document.getElementsByName('scheduleTR1.scheduleTR['+i+'].taxPaidOutsideIndia')[0].value,10)));
        totReliefAvailable = eval(parseInt(totReliefAvailable,10) + parseInt(coalesce(document.getElementsByName('scheduleTR1.scheduleTR['+i+'].taxReliefOutsideIndia')[0].value,10)));
    
    }
    
    document.getElementsByName('scheduleTR1.totalIncomeOutIndia')[0].value = totReliefAvailable9090A;
    document.getElementsByName('scheduleTR1.totalIncomeOutIndiaDTAA')[0].value = totReliefAvailable91;
    document.getElementsByName('scheduleTR1.totTaxPaidDeclaredInFSI')[0].value = totTaxPaidOutsideInd;
    document.getElementsByName('scheduleTR1.totReliefClaimUs9090A')[0].value = totReliefAvailable;
    
    calculateTiTti();
}


function revisedSetFor7OnLoad(section,type){

	var fileSec = document.getElementsByName(section)[0].value;
	var fileType = document.getElementsByName(type)[0];

	if (fileSec == '17' && fileType.value != 'R') {
		document.getElementsByName(type)[0].value = 'R';
	} else if (fileSec != '17' && fileSec!='') {
		document.getElementsByName(type)[0].value = 'O';	
	}else if (fileSec == ''){
		document.getElementsByName(type)[0].value ='';
	}
	enableField('itr7.partAGEN1.filingStatus.returnFileSec.incomeTaxSec',[13,14,15,16,18,19],'itr7.partAGEN1.filingStatus.noticeDateUnderSec');
	enableField('itr7.partAGEN1.filingStatus.returnFileSec.incomeTaxSec',[18],'itr7.partAGEN1.filingStatus.returnFileSec.noticeNo');
	enableField('itr7.partAGEN1.filingStatus.returnFileSec.incomeTaxSec',[17,18,19],'itr7.partAGEN1.filingStatus.receiptNo','itr7.partAGEN1.filingStatus.origRetFiledDate');
}

function revisedSetFor7(section,type){
	
	var fileSec = document.getElementsByName(section)[0].value;
	var fileType = document.getElementsByName(type)[0];

	if (fileSec == '17' && fileType.value != 'R') {
		document.getElementsByName(type)[0].value = 'R';
	} else if (fileSec != '17' && fileSec!='') {
		document.getElementsByName(type)[0].value = 'O';	
	}else{
		document.getElementsByName(type)[0].value ='';
	}
	enableField('itr7.partAGEN1.filingStatus.returnFileSec.incomeTaxSec',[13,14,15,16,18,19],'itr7.partAGEN1.filingStatus.noticeDateUnderSec');
	enableField('itr7.partAGEN1.filingStatus.returnFileSec.incomeTaxSec',[18],'itr7.partAGEN1.filingStatus.returnFileSec.noticeNo');
	enableField('itr7.partAGEN1.filingStatus.returnFileSec.incomeTaxSec',[17,18,19],'itr7.partAGEN1.filingStatus.receiptNo','itr7.partAGEN1.filingStatus.origRetFiledDate');
}

function sectionSetFor7(section,type){
	 var fileSec = document.getElementsByName(section)[0];
	    var fileType=document.getElementsByName(type)[0].value;

	        if(fileType=='R' && fileSec.value!=17){
	            fileSec.value='17';
	        }
	        else {
	            fileSec.value='';
	        }
}


function CheckHPShareProperty(){
	var totHp=eval(parseInt(document.getElementById('scheduleHPLast').cells[0].textContent)-1);
		
	for(var i=0;i<totHp;i++){
		
		if(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].propCoOwnedFlg')[0].value=='YES') {
			var count = i;
			var AssessPerc = document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].asseseeShareProperty')[0];
			var tab = document.getElementById('scheduleHP'+(++count));
		
			var sumOfCoOwner = parseFloat('0');
			
			var rowCount = tab.rows.length;
			
			for(var k=0;k<rowCount-2;k++) {
				
				sumOfCoOwner = sumOfCoOwner + mulFloatBy100(document.getElementsByName('itr7.scheduleHP.propertyDetails['+i+'].coOwners['+k+'].percentShareProperty')[0].value);
			}
			
			if(checkHPShareSum((parseInt(sumOfCoOwner)+mulFloatBy100(AssessPerc.value))/100)){
				addErrorXHTML(AssessPerc,'Sum of Assessee Percentage and Co-owner(s) Percentage should be equal to 100 percent',true);
				j.setFieldError('itr7.scheduleHP.propertyDetails['+i+'].asseseeShareProperty','Sum of Assessee Percentage and Co-owner(s) Percentage should be equal to 100 percent');
			}
		}
	}
}

function checkHPShareSum(total) {
	if(total>=99.9 && total<=100) {
		return false;
	}
	return true;
}

function scheduleVCCalc(){
	document.getElementsByName('itr7.scheduleVC.local.voluntaryContribution')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleVC.local.corpusFundDonation')[0].value==""?0:document.getElementsByName('itr7.scheduleVC.local.corpusFundDonation')[0].value)+parseInt(document.getElementsByName('itr7.scheduleVC.local.otherThanCorpusFund')[0].value==""?0:document.getElementsByName('itr7.scheduleVC.local.otherThanCorpusFund')[0].value));
	document.getElementsByName('itr7.scheduleVC.foreign.foreignContribution')[0].value=eval(parseInt(document.getElementsByName('itr7.scheduleVC.foreign.corpusFundDonation')[0].value==""?0:document.getElementsByName('itr7.scheduleVC.foreign.corpusFundDonation')[0].value)+parseInt(document.getElementsByName('itr7.scheduleVC.foreign.otherThanCorpusFund')[0].value==""?0:document.getElementsByName('itr7.scheduleVC.foreign.otherThanCorpusFund')[0].value));
	document.getElementsByName('itr7.scheduleVC.totalContribution')[0].value=eval(parseInt(coalesceSetRet('itr7.scheduleVC.local.voluntaryContribution')==""?0:coalesceSetRet('itr7.scheduleVC.local.voluntaryContribution'))+parseInt(coalesceSetRet('itr7.scheduleVC.foreign.foreignContribution')==""?0:coalesceSetRet('itr7.scheduleVC.foreign.foreignContribution')));
	
	var totalContribution=document.getElementsByName('itr7.scheduleVC.totalContribution')[0].value;
	var annonyAgr = document.getElementsByName('itr7.scheduleVC.anonymousDonations.aggregateAnonymousDonation')[0].value;
	
	if(annonyAgr>0){
	if(zeroOrMore(coalesce(Math.round(eval(totalContribution)*0.05)))>100000){
		document.getElementsByName('itr7.scheduleVC.anonymousDonations.totalDonationsReceived')[0].value=zeroOrMore(coalesce(Math.round(eval(totalContribution)*0.05)));
	}
	else{
		document.getElementsByName('itr7.scheduleVC.anonymousDonations.totalDonationsReceived')[0].value=100000;
	} 
	} else {
		document.getElementsByName('itr7.scheduleVC.anonymousDonations.totalDonationsReceived')[0].value = parseInt('0' ,10);
	}
	
	if(coalesce(totalContribution)==0){
		
		document.getElementsByName('itr7.scheduleVC.anonymousDonations.totalDonationsReceived')[0].value=parseInt('0',10);
		
	}
	
	document.getElementsByName('itr7.scheduleVC.anonymousDonations.anonymousDonations115BBC')[0].value =zeroOrMore(coalesce(Math.round(eval(parseInt(document.getElementsByName('itr7.scheduleVC.anonymousDonations.aggregateAnonymousDonation')[0].value==""?0:document.getElementsByName('itr7.scheduleVC.anonymousDonations.aggregateAnonymousDonation')[0].value)-parseInt(document.getElementsByName('itr7.scheduleVC.anonymousDonations.totalDonationsReceived')[0].value==""?0:document.getElementsByName('itr7.scheduleVC.anonymousDonations.totalDonationsReceived')[0].value)))));
	
	/*if(eval(anonymousDonationUs115BBC.value)>0){
		document.getElementsByName('itr7.scheduleVC.anonymousDonations.anonymousDonations115BBC')[0].value=eval(anonymousDonationUs115BBC.value);
	}
	else{
		document.getElementsByName('itr7.scheduleVC.anonymousDonations.anonymousDonations115BBC')[0].value=0;
	}*/
}


function chkamtAccumulatedForCharitable(){
	var amtAccumulatedForCharitable = parseInt(document.getElementsByName('itr7.partBTI.tiDeductions.amtAccumulatedForCharitable')[0].value==""?0:document.getElementsByName('itr7.partBTI.tiDeductions.amtAccumulatedForCharitable')[0].value);
	
	var comparedValue = zeroOrMore(coalesce(Math.round(eval(parseInt(document.getElementsByName('itr7.partBTI.aggregateIncomeUs1112')[0].value==""?0:document.getElementsByName('itr7.partBTI.aggregateIncomeUs1112')[0].value)-parseInt(document.getElementsByName('itr7.partBTI.vcCorpusSec11')[0].value==""?0:document.getElementsByName('itr7.partBTI.vcCorpusSec11')[0].value))* 0.15 )));;
	
	if(amtAccumulatedForCharitable>comparedValue){
		
		document.getElementsByName('itr7.partBTI.tiDeductions.amtAccumulatedForCharitable')[0].value=comparedValue;
	}
}


function enableAggregateAnnualReceipts(){
	var activityNature215 =document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.activityNature215')[0].value;
	var activityRendering215 =document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.activityRendering215')[0].value;
	var table = document.getElementById('schedulePartAGEN2');
	var noOfRows = table.rows.length;
		if(activityRendering215=='Y' || activityNature215=='Y'){
			for ( var i = 0; i < eval(parseInt(noOfRows, 10) - 2); i++) {
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].nameOfTheInstitution')[0].disabled=false;
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].nameOfTheInstitution')[0].readOnly=false;
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].nameOfTheInstitution')[0].value='';
					
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].aggregateAnnualReceipts')[0].disabled=false;
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].aggregateAnnualReceipts')[0].readOnly=false;
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].aggregateAnnualReceipts')[0].value='';
				}
		} else {
			for ( var i = 0; i < eval(parseInt(noOfRows, 10) - 2); i++) {
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].nameOfTheInstitution')[0].disabled=true;
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].nameOfTheInstitution')[0].readOnly=true;
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].nameOfTheInstitution')[0].value='';
					
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].aggregateAnnualReceipts')[0].disabled=true;
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].aggregateAnnualReceipts')[0].readOnly=true;
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].aggregateAnnualReceipts')[0].value='';
				}
			}
	}



function populateClassificationCode(elem,subCatVal){
	
	var index = elem.selectedIndex - 1;
	var name = elem.name;
	var row = name.substring(name.indexOf('[')+1,name.indexOf(']'));
	var subCat = document.getElementsByName('itr7.partAGEN1.projectOrInstDtls[' + row + '].classificationCode')[0];

	var tempVal = subCat.value;
	if(subCatVal!=undefined || subCatVal!=null){
		tempVal=subCatVal;
	}
	subCat.options.length=0;
	subCat.options[0] =new Option('Select','-1');


	if(index==0){
		subCat.options[1]=new Option('Relief of the poor','iA');
		subCat.options[2]=new Option('Education','iB');
		subCat.options[3]=new Option('Medical Relief','iC');
		subCat.options[4]=new Option('Preservation of environment (including watersheds, forests and wildlife)','iD');
		subCat.options[5]=new Option('Preservation of monuments or places or objects of artistic or historic interest','iE');
		subCat.options[6]=new Option('Object of general public utility','iF');
		subCat.options[7]=new Option('Development of khadi or village industries','iG');
	}
	else if(index==1){
		subCat.options[1]=new Option('Religious','RELIGIOUS');
	}
	else if(index==2){
		subCat.options[1]=new Option('Scientific Research','iiiA');
		subCat.options[2]=new Option('Social Research','iiiB');
		subCat.options[3]=new Option('Statistical research','iiiC');
		subCat.options[4]=new Option('Any other research','iiiD');
	}
	else if(index==3){
		subCat.options[1]=new Option('News Agency','NEWSAGENCY');
	}
	else if(index==4){
		subCat.options[1]=new Option('Law','vA');
		subCat.options[2]=new Option('Medicine','vB');
		subCat.options[3]=new Option('Accountancy','vC');
		subCat.options[4]=new Option('Engineering','vD');
		subCat.options[5]=new Option('Architecture','vE');
		subCat.options[6]=new Option('Company secretaries','vF');
		subCat.options[7]=new Option('Chemistry','vG');
		subCat.options[8]=new Option('Materials management','vH');
		subCat.options[9]=new Option('Town planning','vI');
		subCat.options[10]=new Option('Any other profession','vJ');
		
	}
	else if(index==5){
		subCat.options[1]=new Option('Trade union','TRADEUNION');
	}
	else if(index==6){
		subCat.options[1]=new Option('Political party','POLITICAL_PARTY');
	}
	else if(index==7){
		subCat.options[1]=new Option('Electoral trust','ELECTORALTRUST');
	}
	else if(index==8){
		subCat.options[1]=new Option('Specified income arising to a body/authority/Board/Trust/Commission u/s 10(46)','ixA');
		subCat.options[2]=new Option('Infrastructure Debt fund u/s 10(47)','ixB');
		subCat.options[3]=new Option('Any other','ixC');
	}
	if(tempVal.length==0){
		subCat.value = "-1";
	}
	else{
	subCat.value = tempVal;
	}
}


function enableAggregateAnnualReceiptsOnLoad(activityNature215,activityRendering215){
	var table = document.getElementById('schedulePartAGEN2');
	var noOfRows = table.rows.length;
		if(activityNature215=='Y' || activityRendering215=='Y'){
			for ( var i = 0; i < eval(parseInt(noOfRows, 10) - 2); i++) {
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].nameOfTheInstitution')[0].disabled=false;
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].nameOfTheInstitution')[0].readOnly=false;
					
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].aggregateAnnualReceipts')[0].disabled=false;
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].aggregateAnnualReceipts')[0].readOnly=false;
					
				}
		} else {
			for ( var i = 0; i < eval(parseInt(noOfRows, 10) - 2); i++) {
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].nameOfTheInstitution')[0].disabled=true;
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].nameOfTheInstitution')[0].readOnly=true;
					
					
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].aggregateAnnualReceipts')[0].disabled=true;
					document.getElementsByName('itr7.partAGEN2.otherDetailsFor7.otherDetailsUs215.aggregateAnnualReceiptsofInstitution['+i+'].aggregateAnnualReceipts')[0].readOnly=true;
					
				}
			}
	}

function adjustOS() {
	var tabl = document.getElementById('schduleOsf');
	
	var allSelects = tabl.getElementsByTagName('SELECT');
	
	for(var i = 0; i < allSelects.length; i++) {	
			var name = allSelects[i].name;
			var index = name.substring(name.indexOf('[')+1, name.indexOf(']'));
			if(allSelects[i].value=='Others'){
				document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls['+ index +'].otherSourceDesc')[0].style.display='';
			} else {
				document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls['+ index +'].otherSourceDesc')[0].style.display='none';
				document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls['+ index +'].otherSourceDesc')[0].value='';
			}
	}
}

function enableScheduleOSOther(){
	var tabl = document.getElementById('schduleOsf');
		var allSelects = tabl.getElementsByTagName('SELECT'); 
		for(var i = 0; i < allSelects.length; i++) {	
				var name = allSelects[i].name;
				var index = name.substring(name.indexOf('[')+1, name.indexOf(']'));
				if(allSelects[i].value=='Others'){
					document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls['+ index +'].otherSourceDesc')[0].style.display='';
				} else {
					document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls['+ index +'].otherSourceDesc')[0].style.display='none';
					document.getElementsByName('itr7.scheduleOS.incOthThanOwnRaceHorse.othersGrossDtls['+ index +'].otherSourceDesc')[0].value='';
				}
		}
	}

function populateClassificationCodeHidden(){
	var tab = document.getElementById('projDetails');
	var len = tab.rows.length-2;
	for(var i=0;i<len;i++){
	 populateClassificationCode(document.getElementsByName('itr7.partAGEN1.projectOrInstDtls['+ i +'].activityNature')[0]);	
	 var classificationCodeHidden = document.getElementsByName('itr7.partAGEN1.projectOrInstDtls['+ i +'].classificationCodeHidden')[0].value;
	 if(classificationCodeHidden!=''){
		 document.getElementsByName('itr7.partAGEN1.projectOrInstDtls['+ i +'].classificationCode')[0].value = document.getElementsByName('itr7.partAGEN1.projectOrInstDtls['+i+'].classificationCodeHidden')[0].value;
	 }
	}
}



function checkUniqueOSSec(){
checkUniqueTableCol('schduleOsf', 'sourceDescription$');
}


function checkUniqueTableCol(tableId, colname,errorMesg){
	
	var tab = document.getElementById(tableId);
	var selects = tab.getElementsByTagName('SELECT');
	var arr = new Array();
	for(var i=0;i<selects.length;i++){
		if(selects[i].name.match(colname) && selects[i].value!=''){
			if(arr.indexOf(selects[i].value)==-1){
				arr.push(selects[i].value);
			}else if(selects[i].value!='Others'){
				var msg = errorMesg || 'A particular drop down cannot be selected twice';
				j.setFieldError(selects[i].name, msg);
				addErrorXHTML(selects[i], msg ,true);	
			}
		}
	}
}

function checkUniqAuditSec(){
	
	checkUniqueTableCol('AuditDetails', 'auditedSection$','A Particular Section cannot be selected twice');
}

function disableScheduleFA(){

	var resStatus=document.getElementsByName('itr7.partAGEN1.filingStatus.residentialStatus')[0].value;
	
	removeTableData('schFADtlsFrignAssets', resStatus);
	removeTableData('schFADtlsFinIntrest', resStatus);
	removeTableData('schFADtlsImmvbleProp', resStatus);
	removeTableData('schFADtlsOtherAsset', resStatus);
	removeTableData('schFADtlsSigningAuth', resStatus);
	removeTableData('schFADtlsTrusts', resStatus);
	removeTableData('DetailsOthIncomeOutsideIndia', resStatus);
}
//to remove table data
function removeTableData(tableID, resStatus) {

	var tab = document.getElementById(tableID);
	var asstFlag = document.getElementsByName('itr7.partBTTI.assetOutIndiaFlag')[0].value;

	if (!((resStatus == 'RES' || resStatus == 'NOR') && asstFlag == 'YES')) {
		$('#' + tableID + ' input').attr("checked", true);
		deleteRowTable(tableID, 3, 1);
		$('#' + tableID + ' input').attr("checked", false);
	}

	var allInputTags = tab.getElementsByTagName('input');
	var selectTags = tab.getElementsByTagName('select');

	for ( var i = 0; i < allInputTags.length; i++) {
		if ((resStatus == 'RES' || resStatus == 'NOR') && asstFlag == 'YES') {
			allInputTags[i].disabled = false;
			allInputTags[i].readOnly = false;

		} else {

			allInputTags[i].disabled = true;
			allInputTags[i].readOnly = true;
			allInputTags[i].value = "";
		}
	}
	for ( var i = 0; i < selectTags.length; i++) {
		if ((resStatus == 'RES' || resStatus == 'NOR') && asstFlag == 'YES') {
			selectTags[i].disabled = false;
		} else {
			selectTags[i].disabled = true;
			selectTags[i].value = "";

		}
	}
	if ((resStatus == 'RES' || resStatus == 'NOR') && asstFlag == 'YES') {
		main.enableTabs(29);
	}
}




function calcSchJ(){
	try{
		var tableB = document.getElementById('scheduleJB');
		var rowCount = tableB.rows.length;
		var sumTotalInvestmnt=0;
		var sumTotalMaturity=0;
		for(var i=0;i<rowCount-4;i++){
			sumTotalInvestmnt = eval(parseInt(sumTotalInvestmnt,10) + parseInt(coalesce(document.getElementsByName('itr7.itrScheduleJ.scheduleJUs115.scheduleJBDtls['+i+'].amtOfInvestment')[0].value),10));
			sumTotalMaturity = eval(parseInt(sumTotalMaturity,10) + parseInt(coalesce(document.getElementsByName('itr7.itrScheduleJ.scheduleJUs115.scheduleJBDtls['+i+'].maturityAmt')[0].value),10));
		}
		coalesceSetRet('itr7.itrScheduleJ.scheduleJUs115.totalInvestmentAmt');
		document.getElementsByName('itr7.itrScheduleJ.scheduleJUs115.totalInvestmentAmt')[0].value  = parseInt(coalesce(sumTotalInvestmnt),10);
		
		coalesceSetRet('itr7.itrScheduleJ.scheduleJUs115.maturityAmount');
		document.getElementsByName('itr7.itrScheduleJ.scheduleJUs115.maturityAmount')[0].value  = parseInt(coalesce(sumTotalMaturity),10);
		
		
		var tableC = document.getElementById('scheduleJC');
		var rowCount = tableC.rows.length;
		var sumShares=0;
		var sumNominalVal=0;
		var sumInvstInc=0;
		for(var i=0;i<rowCount-4;i++){
			sumShares = eval(parseInt(sumShares,10) + parseInt(coalesce(document.getElementsByName('itr7.itrScheduleJ.scheduleJUs133.scheduleJUs133Dtls['+i+'].noOfSharesHeld')[0].value),10));
			sumNominalVal = eval(parseInt(sumNominalVal,10) + parseInt(coalesce(document.getElementsByName('itr7.itrScheduleJ.scheduleJUs133.scheduleJUs133Dtls['+i+'].nominalaValueOfInvestment')[0].value),10));
			sumInvstInc = eval(parseInt(sumInvstInc,10) + parseInt(coalesce(document.getElementsByName('itr7.itrScheduleJ.scheduleJUs133.scheduleJUs133Dtls['+i+'].incFromInvestment')[0].value),10));
		}
		coalesceSetRet('itr7.itrScheduleJ.scheduleJUs133.totalNoOfShares');
		document.getElementsByName('itr7.itrScheduleJ.scheduleJUs133.totalNoOfShares')[0].value  = parseInt(coalesce(sumShares),10);
		
		coalesceSetRet('itr7.itrScheduleJ.scheduleJUs133.totalValueOfInvestment');
		document.getElementsByName('itr7.itrScheduleJ.scheduleJUs133.totalValueOfInvestment')[0].value  = parseInt(coalesce(sumNominalVal),10);
		
		coalesceSetRet('itr7.itrScheduleJ.scheduleJUs133.totalIncFromInvestment');
		document.getElementsByName('itr7.itrScheduleJ.scheduleJUs133.totalIncFromInvestment')[0].value  = parseInt(coalesce(sumInvstInc),10);
	
		var tableD = document.getElementById('scheduleJD');
		var rowCount = tableD.rows.length;
		var sumTotalShares=0;
		var sumTotalNomVal=0;
		for(var i=0;i<rowCount-4;i++){
			sumTotalShares = eval(parseInt(sumTotalShares,10) + parseInt(coalesce(document.getElementsByName('itr7.itrScheduleJ.scheduleJOtherInvstmts.scheduleJOtherInvstmtsDtls['+i+'].noOfSharesHeld')[0].value),10));
			sumTotalNomVal = eval(parseInt(sumTotalNomVal,10) + parseInt(coalesce(document.getElementsByName('itr7.itrScheduleJ.scheduleJOtherInvstmts.scheduleJOtherInvstmtsDtls['+i+'].nominalaValueOfInvestment')[0].value),10));
		}
		coalesceSetRet('itr7.itrScheduleJ.scheduleJOtherInvstmts.totalNoOfShares');
		document.getElementsByName('itr7.itrScheduleJ.scheduleJOtherInvstmts.totalNoOfShares')[0].value  = parseInt(coalesce(sumTotalShares),10);
		
		coalesceSetRet('itr7.itrScheduleJ.scheduleJOtherInvstmts.totalValueOfInvestment');
		document.getElementsByName('itr7.itrScheduleJ.scheduleJOtherInvstmts.totalValueOfInvestment')[0].value  = parseInt(coalesce(sumTotalNomVal),10);
		
		var tableE = document.getElementById('scheduleJE');
		var rowCount = tableE.rows.length;
		var sumValContribtn=0;
		var sumAmtInvest=0;
		var sumBalUs113=0;
		for(var i=0;i<rowCount-4;i++){
			sumValContribtn = eval(parseInt(sumValContribtn,10) + parseInt(coalesce(document.getElementsByName('itr7.itrScheduleJ.scheduleJVoluntaryContribution.scheduleJVoluntaryContributionDtls['+i+'].valueOfContribution')[0].value),10));
			sumAmtInvest = eval(parseInt(sumAmtInvest,10) + parseInt(coalesce(document.getElementsByName('itr7.itrScheduleJ.scheduleJVoluntaryContribution.scheduleJVoluntaryContributionDtls['+i+'].amtInvestedUs11')[0].value),10));
			sumBalUs113 = eval(parseInt(sumBalUs113,10) + parseInt(coalesce(document.getElementsByName('itr7.itrScheduleJ.scheduleJVoluntaryContribution.scheduleJVoluntaryContributionDtls['+i+'].balIncUs11')[0].value),10));
		}
		coalesceSetRet('itr7.itrScheduleJ.scheduleJVoluntaryContribution.totalValueOfContribution');
		document.getElementsByName('itr7.itrScheduleJ.scheduleJVoluntaryContribution.totalValueOfContribution')[0].value  = parseInt(coalesce(sumValContribtn),10);
		
		coalesceSetRet('itr7.itrScheduleJ.scheduleJVoluntaryContribution.totalAmtInvestedUs11');
		document.getElementsByName('itr7.itrScheduleJ.scheduleJVoluntaryContribution.totalAmtInvestedUs11')[0].value  = parseInt(coalesce(sumAmtInvest),10);
		
		coalesceSetRet('itr7.itrScheduleJ.scheduleJVoluntaryContribution.totalBalIncUs11');
		document.getElementsByName('itr7.itrScheduleJ.scheduleJVoluntaryContribution.totalBalIncUs11')[0].value  = parseInt(coalesce(sumBalUs113),10);
	
	}catch(e){
			alert(e.stack);
	}
}



function natureOfBusChck(tableId){
	var noRows=4;
	var tab = document.getElementById(tableId);
	var rowCount = tab.rows.length;
	if(rowCount > noRows) {
	addErrorXHTML('','Cannot insert more than 3 rows');
	return false;
	}
	return true;

}


function ifscCodeUpperCase(){

document.getElementsByName('itr.refund.depositToBankAccount.iFSCCode')[0].value=document.getElementsByName('itr.refund.depositToBankAccount.iFSCCode')[0].value.toUpperCase();
document.getElementsByName('itr.refund.bankAccountNumber')[0].value=document.getElementsByName('itr.refund.bankAccountNumber')[0].value.toUpperCase();

}


function checkAMTCCurAY(){
	try{
	var curAYGross=$('[name="itr7.scheduleAMTC.scheduleAMTCUtil.CYamtCreditFwd"]')[0];
	var taxSection115JC = $('[name="itr7.scheduleAMTC.taxSection115JC"]')[0];
	var taxOthProvisions = $('[name="itr7.scheduleAMTC.taxOthProvision"]')[0];
	var curAYGrossTemp;
	
	if(eval(parseInt(coalesce(taxOthProvisions.value),10)) < eval(parseInt(coalesce(taxSection115JC.value),10))){
		
		curAYGrossTemp=eval(parseInt(coalesce(taxSection115JC.value),10))-eval(parseInt(coalesce(taxOthProvisions.value),10));
	
		
	}else{
		curAYGross.value='0';
		curAYGrossTemp=parseInt('0',10);
	}
	
	
	
	if(curAYGross.value>curAYGrossTemp){
		
		addError(document.getElementsByName('itr7.scheduleAMTC.scheduleAMTCUtil.CYamtCreditFwd')[0],'Gross income for current AY cannot be greater than 1-2',true);
		j.setFieldError('itr7.scheduleAMTC.scheduleAMTCUtil.CYamtCreditFwd','Gross income for current AY cannot be greater than 1-2');
		
	
	}
	}catch(e){
		//alert('Error in checkAMTCCurAY:' +e);
	}
}



function schVCAmtCheck(){

var annonymsDon = document.getElementsByName('itr7.scheduleVC.anonymousDonations.aggregateAnonymousDonation')[0];
var totalContri = document.getElementsByName('itr7.scheduleVC.totalContribution')[0];

	if(parseInt(coalesce(annonymsDon.value),10)>parseInt(coalesce(totalContri.value),10)){
		j.setFieldError('itr7.scheduleVC.anonymousDonations.aggregateAnonymousDonation','The value entered in Di cannot exceed the value in C');
		addErrorXHTML(annonymsDon ,"The value entered in Di cannot exceed the value in C");
	}
}

function getIfscBankName(field) {
	
	document.getElementsByName('itr.refund.depositToBankAccount.bankName')[0].value = main.getBankName(field.value);
}

function getIfscBankDetails(elem) {
	
	var position = parseInt(elem.name.substring(elem.name.indexOf("[") + 1,elem.name.indexOf("]")));
	var ifscCode = document.getElementsByName('itr.scheduleBA[' + position + '].ifscCode')[0].value;
	document.getElementsByName('itr.scheduleBA[' + position + '].bankName')[0].value = main.getBankName(ifscCode);
}




function enableFieldsForPointE(tableId){
	
	var tab = document.getElementById(tableId);
	var rows = tab.getElementsByTagName('tr');
	var rowCount = rows.length;
	
	for(var  i = 0; i<rowCount - 4; i++){
		var selectedOptionId = document.getElementsByName('scheduleFA.detailsOfAccntsHvngSigningAuth['+i+'].taxableIncomeFlag')[0];
		var selectedOption = selectedOptionId.options[selectedOptionId.selectedIndex].value;
				
		if (selectedOption == 'Y'){
			document.getElementsByName('scheduleFA.detailsOfAccntsHvngSigningAuth['+i+'].interestInAccount')[0].disabled = false;
			document.getElementsByName('scheduleFA.detailsOfAccntsHvngSigningAuth['+i+'].amount')[0].disabled = false;
			document.getElementsByName('scheduleFA.detailsOfAccntsHvngSigningAuth['+i+'].scheduleOffered')[0].disabled = false;
			document.getElementsByName('scheduleFA.detailsOfAccntsHvngSigningAuth['+i+'].itemNo')[0].disabled = false;
		
		}else{
			document.getElementsByName('scheduleFA.detailsOfAccntsHvngSigningAuth['+i+'].interestInAccount')[0].disabled = true;
			document.getElementsByName('scheduleFA.detailsOfAccntsHvngSigningAuth['+i+'].amount')[0].disabled = true;
			document.getElementsByName('scheduleFA.detailsOfAccntsHvngSigningAuth['+i+'].scheduleOffered')[0].disabled = true;
			document.getElementsByName('scheduleFA.detailsOfAccntsHvngSigningAuth['+i+'].itemNo')[0].disabled = true;
			
			document.getElementsByName('scheduleFA.detailsOfAccntsHvngSigningAuth['+i+'].interestInAccount')[0].value='';
			document.getElementsByName('scheduleFA.detailsOfAccntsHvngSigningAuth['+i+'].amount')[0].value = '';
			document.getElementsByName('scheduleFA.detailsOfAccntsHvngSigningAuth['+i+'].scheduleOffered')[0].value= '';
			document.getElementsByName('scheduleFA.detailsOfAccntsHvngSigningAuth['+i+'].itemNo')[0].value = '';
			
		}
	}
}



//To enable point F fields
function enableFieldsForPointF(tableId) {

	var tab = document.getElementById(tableId);
	var rows = tab.getElementsByTagName('tr');
	var rowCount = rows.length;

	for ( var i = 0; i < rowCount - 4; i++) {
		var selectedOptionId = document
				.getElementsByName('scheduleFA.detailsOfTrustOutIndiaTrustee['
						+ i + '].trustIncomeFlag')[0];
		var selectedOption = selectedOptionId.options[selectedOptionId.selectedIndex].value;

		if (selectedOption == 'Y') {
			document
					.getElementsByName('scheduleFA.detailsOfTrustOutIndiaTrustee['
							+ i + '].trustIncome')[0].disabled = false;
			document
					.getElementsByName('scheduleFA.detailsOfTrustOutIndiaTrustee['
							+ i + '].amount')[0].disabled = false;
			document
					.getElementsByName('scheduleFA.detailsOfTrustOutIndiaTrustee['
							+ i + '].scheduleOffered')[0].disabled = false;
			document
					.getElementsByName('scheduleFA.detailsOfTrustOutIndiaTrustee['
							+ i + '].itemNo')[0].disabled = false;

		} else {
			document
					.getElementsByName('scheduleFA.detailsOfTrustOutIndiaTrustee['
							+ i + '].trustIncome')[0].disabled = true;
			document
					.getElementsByName('scheduleFA.detailsOfTrustOutIndiaTrustee['
							+ i + '].amount')[0].disabled = true;
			document
					.getElementsByName('scheduleFA.detailsOfTrustOutIndiaTrustee['
							+ i + '].scheduleOffered')[0].disabled = true;
			document
					.getElementsByName('scheduleFA.detailsOfTrustOutIndiaTrustee['
							+ i + '].itemNo')[0].disabled = true;

			document
					.getElementsByName('scheduleFA.detailsOfTrustOutIndiaTrustee['
							+ i + '].trustIncome')[0].value = '';
			document
					.getElementsByName('scheduleFA.detailsOfTrustOutIndiaTrustee['
							+ i + '].amount')[0].value = '';
			document
					.getElementsByName('scheduleFA.detailsOfTrustOutIndiaTrustee['
							+ i + '].scheduleOffered')[0].value = '';
			document
					.getElementsByName('scheduleFA.detailsOfTrustOutIndiaTrustee['
							+ i + '].itemNo')[0].value = '';

		}
	}
}

// /To enable point G fields
function enableFieldsForPointG(tableId) {

	var tab = document.getElementById(tableId);
	var rows = tab.getElementsByTagName('tr');
	var rowCount = rows.length;

	for ( var i = 0; i < rowCount - 4; i++) {
		var selectedOptionId = document
				.getElementsByName('scheduleFA.detailsOfOtherIncome[' + i
						+ '].trustIncomeFlag')[0];
		var selectedOption = selectedOptionId.options[selectedOptionId.selectedIndex].value;

		if (selectedOption == 'Y') {
			document.getElementsByName('scheduleFA.detailsOfOtherIncome[' + i
					+ '].amount')[0].disabled = false;
			document.getElementsByName('scheduleFA.detailsOfOtherIncome[' + i
					+ '].scheduleOffered')[0].disabled = false;
			document.getElementsByName('scheduleFA.detailsOfOtherIncome[' + i
					+ '].itemNo')[0].disabled = false;

		} else {

			document.getElementsByName('scheduleFA.detailsOfOtherIncome[' + i
					+ '].amount')[0].disabled = true;
			document.getElementsByName('scheduleFA.detailsOfOtherIncome[' + i
					+ '].scheduleOffered')[0].disabled = true;
			document.getElementsByName('scheduleFA.detailsOfOtherIncome[' + i
					+ '].itemNo')[0].disabled = true;

			document.getElementsByName('scheduleFA.detailsOfOtherIncome[' + i
					+ '].amount')[0].value = '';
			document.getElementsByName('scheduleFA.detailsOfOtherIncome[' + i
					+ '].scheduleOffered')[0].value = '';
			document.getElementsByName('scheduleFA.detailsOfOtherIncome[' + i
					+ '].itemNo')[0].value = '';
		}
	}
}

function calculateTotalTaxIT(tableId){
	
	var tab1 = document.getElementById('scheduleIT');
	var noOfRows=tab1.rows.length;
	var sum = 0;
	var amt = 0;
	
	for ( var i = 0; i < (noOfRows-4); i++) {
		amt = document.getElementsByName('itr7.scheduleIT.taxPayment['+i+'].amt')[0].value;
		sum = eval(parseInt(sum,10) + parseInt(coalesce(amt),10));
	}
	document.getElementsByName('scheduleIT.taxPayment.totalTaxPayments')[0].value = parseInt(sum,10);	
}

function display92CDVerification(type) {

	var fileSec=document.getElementsByName('itr7.partAGEN1.filingStatus.returnFileSec.incomeTaxSec')[0].value;
	
	if(fileSec=='19') {
		   document.getElementById('92cdVerification').style.display='';
	   } else {
		   document.getElementById('92cdVerification').style.display='none';
	   }
	
	if(type != 'onload' && fileSec == '20'){
		addErrorXHTML('','Return u/s 119(2)(b) for AY 2015-16 can be filed only after 31st March 2017.');
	}
}


//To alert user
function alertItr7User() {

	var errText="";
	var i=1;
	var amountPayable = document.getElementsByName('itr7.partBTTI.taxPaid.balTaxPayable')[0].value;
	var fileSec = document.getElementsByName('itr7.partAGEN1.filingStatus.returnFileSec.incomeTaxSec')[0].value;
	
	
	
	if(fileSec=='20'){
		errText+=(i++)+". Return u/s 119(2)(b) for AY 2015-16 can be filed only after 31st March 2017.\n\n";
	}
	if (amountPayable > 0){
		errText+=(i++)+". Please ensure that the taxes are paid before the submission of the return, else return shall be treated as defective.\n";
	}
	main.generateMsgDialogWithOk(errText,"");
}

//To open Save file dialog
function popupWithOk()
{
	  j.popup();
}

function checkNoOfRowsFilled() {
	var tab = document.getElementById('scheduleBA');
	var rowCount = tab.rows.length;
	var count = parseInt(0, 10);
	var noOfBankAccounts = document.getElementsByName('itr.scheduleBA.noOfBankAcc')[0].value;
	for ( var i = 0; i < (rowCount - 2); i++) {
		var IFSC = document.getElementsByName('itr.scheduleBA[' + i	+ '].ifscCode')[0].value;
		if (IFSC != "") {
			count = count + 1;
		}
	}
	if (noOfBankAccounts != '' && (noOfBankAccounts - 1) != count) {
		j.setFieldError('itr.scheduleBA.noOfBankAcc','Number of bank accounts held during the pervious year should be equal to number of rows entered in the below tables');
	}

}
